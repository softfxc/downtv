package com.kotatv

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class SportMatch(
    val id: String,
    val title: String,
    val sport: String,
    val league: String,
    val time: String,
    val isLive: Boolean,
    val posterUrl: String,
    val sources: List<SportSource>
)

data class SportSource(
    val source: String,
    val id: String,
    val streamUrl: String = ""
)

object SportsManager {
    private const val TAG = "SportsManager"
    private const val BASE = "https://streamed.su"
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    val SPORTS_ORDER = listOf("football", "basketball")

    fun fetchTodayMatches(): List<SportMatch> {
        return try {
            val json = fetchJson("$BASE/api/matches/all")
            parseMatches(json).filter { isAllowedSport(it.sport) }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching matches: ${e.message}", e)
            emptyList()
        }
    }

    fun fetchMatchesBySport(sport: String): List<SportMatch> {
        return try {
            val json = fetchJson("$BASE/api/matches/$sport")
            parseMatches(json).filter { isAllowedSport(it.sport) }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching $sport matches: ${e.message}", e)
            emptyList()
        }
    }

    private fun isAllowedSport(sport: String): Boolean {
        val clean = sport.lowercase()
        return clean == "football" || clean == "basketball" ||
            clean.contains("soccer") || clean.contains("futbol") ||
            clean.contains("basket") || clean.contains("nba")
    }

    fun fetchStreamUrl(source: String, id: String): String? {
        return try {
            val json = fetchJson("$BASE/api/stream/$source/$id")
            val arr = JSONArray(json)
            if (arr.length() == 0) return null
            val first = arr.getJSONObject(0)
            val embedUrl = first.optString("embedUrl").ifBlank { first.optString("url") }
            if (embedUrl.isBlank()) return null
            if (embedUrl.contains(".m3u8")) return embedUrl
            extractM3u8FromEmbed(embedUrl)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching stream for $source/$id: ${e.message}", e)
            null
        }
    }

    private fun extractM3u8FromEmbed(embedUrl: String): String? {
        return try {
            val html = fetchText(embedUrl)
            val patterns = listOf(
                Regex("""["']([^"']+\.m3u8[^"']*)["']"""),
                Regex("""source:\s*["']([^"']+\.m3u8[^"']*)["']"""),
                Regex("""file:\s*["']([^"']+\.m3u8[^"']*)["']"""),
                Regex("""src:\s*["']([^"']+\.m3u8[^"']*)["']""")
            )
            for (pattern in patterns) {
                val match = pattern.find(html)
                if (match != null) {
                    val url = match.groupValues[1]
                    if (url.startsWith("http")) return url
                }
            }
            null
        } catch (e: Exception) {
            Log.w(TAG, "Could not extract m3u8 from embed: ${e.message}")
            null
        }
    }

    private fun parseMatches(json: String): List<SportMatch> {
        return parseMatchesPublic(json)
    }

    fun parseMatchesPublic(json: String): List<SportMatch> {
        val result = mutableListOf<SportMatch>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id").ifBlank { continue.let { "" } }
                if (id.isBlank()) continue
                val title = obj.optString("title").ifBlank { obj.optString("name") }
                if (title.isBlank()) continue
                val sport = obj.optString("category").lowercase().ifBlank { "sport" }
                val league = obj.optString("league").ifBlank { obj.optString("competition", "") }
                val isLive = obj.optBoolean("popular", false) || obj.optString("status") == "live"
                val time = obj.optString("date").ifBlank { obj.optString("time", "") }
                val poster = obj.optString("poster").ifBlank { "" }
                val sourcesArr = obj.optJSONArray("sources") ?: JSONArray()
                val sources = mutableListOf<SportSource>()
                for (j in 0 until sourcesArr.length()) {
                    val s = sourcesArr.optJSONObject(j) ?: continue
                    val src = s.optString("source").ifBlank { continue.let { "" } }
                    val sid = s.optString("id").ifBlank { continue.let { "" } }
                    val streamUrl = s.optString("streamUrl")
                        .ifBlank { s.optString("url") }
                        .ifBlank { s.optString("embedUrl") }
                    if (src.isNotBlank() && (sid.isNotBlank() || streamUrl.isNotBlank())) {
                        sources.add(SportSource(src, sid, streamUrl))
                    }
                }
                result.add(SportMatch(id, title, sport, league, time, isLive, poster, sources))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing matches JSON: ${e.message}", e)
        }
        return result
    }

    private fun fetchJson(url: String): String {
        // Intentar directo primero y luego con varios proxies.
        try {
            Log.d(TAG, "fetchJson direct: $url")
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Accept", "application/json, */*")
            }
            
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                Log.d(TAG, "Direct success: ${body.length} bytes")
                return body
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.w(TAG, "Direct failed: ${e.message}")
        }
        
        // Proxy 1: corsproxy.io
        try {
            val proxyUrl = "https://corsproxy.io/?" + java.net.URLEncoder.encode(url, "UTF-8")
            Log.d(TAG, "fetchJson via corsproxy: $proxyUrl")
            
            val conn = (URL(proxyUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
            }
            
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                Log.d(TAG, "Corsproxy success: ${body.length} bytes")
                return body
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.w(TAG, "Corsproxy failed: ${e.message}")
        }
        
        // Proxy 2: thingproxy
        try {
            val proxyUrl = "https://thingproxy.freeboard.io/fetch/" + url
            Log.d(TAG, "fetchJson via thingproxy: $proxyUrl")
            
            val conn = (URL(proxyUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
            }
            
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                Log.d(TAG, "Thingproxy success: ${body.length} bytes")
                return body
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.w(TAG, "Thingproxy failed: ${e.message}")
        }
        
        // Proxy 3: allorigins.win
        try {
            val proxyUrl = "https://api.allorigins.win/raw?url=" + java.net.URLEncoder.encode(url, "UTF-8")
            Log.d(TAG, "fetchJson via allorigins: $proxyUrl")
            
            val conn = (URL(proxyUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
            }
            
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                Log.d(TAG, "Allorigins success: ${body.length} bytes")
                return body
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.w(TAG, "Allorigins failed: ${e.message}")
        }
        
        throw Exception("No se pudo obtener datos de $url (probado: directo, 3 proxies)")
    }

    private fun fetchText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "text/html,*/*")
        }
        val code = conn.responseCode
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw Exception("HTTP $code")
        return body
    }
}
