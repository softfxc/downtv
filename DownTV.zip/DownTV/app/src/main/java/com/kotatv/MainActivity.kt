package com.kotatv

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.system.Os
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.util.Base64
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media as VlcMedia
import org.videolan.libvlc.MediaPlayer as VlcMediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import org.chromium.net.CronetEngine
import org.chromium.net.CronetException
import org.chromium.net.UrlRequest
import org.chromium.net.UrlResponseInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : ComponentActivity() {

    private val aboutText: String = """
https://softfxc.github.io

Versión 2.0-release.

¿Qué se añadió en esta segunda versión nueva?

1. La primera mejoría grande consta de la integración IPTV de deportes en directo 24/7 (IPTV significa “Televisión por Protocolo de Internet”, sin necesidad de cable) y su repositorio concreto se encuentra en: 
https://iptv-org.github.io/iptv/categories/sports.m3u 

Algunos servicios ya fueron removidos y se encuentran disponibles con previo pago y son tales como, por ejemplo, NBA o LaLiga TV.

A pesar del intento de agregar streamed.su al catálogo deportivo no se obtuvo buen resultado y fue debido a que esa página no devolvía un vídeo reproducible válido, un error similar a los streams de audiovisuales que eran provocados durante el desarrollo de la versión anterior de esta aplicación.

2. También se agregó un catálogo de series reproducibles o descargables para los mayores cinéfilos, que aparece sin la categoría "- IMDB" en la sección HOME.

A pesar del intento de agregar https://grantorrent.wtf/inicio como catálogo adicional y, aunque sí se consiguió cargar su catálogo en DownTV gracias a Orbot (de The Tor Project:  https://play.google.com/store/apps/details?id=org.torproject.android  o  https://guardianproject.info/releases/orbot-latest.apk ) como aplicación adicional, no se obtuvo el gratificante resultado de reproducción con VLC y descarga automática por torrent ya que, aunque dicha web no hospeda publicidad repetitiva ni acortadores frustrantes para los enlaces de descargas, el culpable fue, al igual que en streamed.su: el Cloudflare que actúa como sistema anti-bots y anti-scraping, ocurriendo también con www.opensubtitles.com para libVLC con su opción '+'.

Ambos puntos tratan de tener filtrado de idioma al castellano o incluso inglés, evitando el español latino y otros derivados distintos.


*Sobre la versión anterior:*

DownTV (Download + TV) nace del capricho de querer ver gratuitamente contenido de pago. Las aplicaciones de streaming pirata convencionales acumulan servidores o el suyo propio, y lo que hacen es cargar desde ahí toda la multimedia, con su propio catálogo y su propia interfaz, básicamente como si fueran las aplicaciones del móvil como Netflix.

¿Qué ocurre? Siempre le suelen interponer troyanos o virus de por medio: MagisTV, Netfly, Betflix…

Por ello, surgió Down TV: una alternativa de código abierto, sin publicidad y sin necesidad de registro.

######### ######## 
Inconveniente: límite nativo. 
######## #########

Al no disponer de servidor local y, debido a que las webs de streaming pirata en línea, aparte de que éstas están llenas de publicidad y ventanas emergentes, bloquean a este tipo de aplicaciones construidas con WebView (vista web) y, a pesar de que se consiguió acabar bloqueando la gran mayoría de anuncios, la reproducción no daba fruto y se producía el constante pantallazo negro en su lugar.

Estas páginas web fueron visitadas desde https://fmhy.net que es un hospedador con actualizaciones y sin publicidad de enlaces públicos de, entre otras cosas, webs de stream de este tipo.

También surgió la idea de tratar de obtener los enlaces a los distintos servidores o hosts para la directa reproducción del contenido audiovisual, pensando que así no habría que pasar por la web principal, pero lamentablemente eso no resolvió el pantallazo negro o, en el caso de multistream.mov, el contenido estaba fijado con audio en inglés.

A pesar de que existen alternativas como Stremio
https://play.google.com/store/apps/details?id=com.stremio.one que permiten instalar extensiones o addons de terceros para reproducir contenido protegido, esa sigue siendo una aplicación que requiere registro previo y una determinada configuración.

Sin embargo, Down TV no requiere nada de eso y viene preinstalado con Torrentio y VLC más un catálogo obtenido directamente en línea desde IMDB.

También existen hosters premium como MediaFusion pero requieren tener agregada una cuenta de Real-Debrid, https://real-debrid.com que es un servicio de suscripción de pago que sirve para descargar o reproducir archivos desde muchos servidores de alojamiento con menos límites de velocidad y mejor estabilidad.
    """.trimIndent()

    private val embeddedVlcSubtitlePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            attachSubtitleToEmbeddedVlc(uri)
        }
    }

    private lateinit var rootView: FrameLayout
    private lateinit var catalogScroll: ScrollView
    private lateinit var catalogContent: LinearLayout
    private lateinit var searchBox: EditText
    private var searchHistoryContainer: LinearLayout? = null
    private var searchHintAnimator: ValueAnimator? = null
    private var currentNavTab = NavTab.HOME
    private var openSubtitlesWebView: WebView? = null
    private var openSubtitlesUseLegacy = false
    private var playbackWebView: WebView? = null
    private var torrentStreamManager: TorrentStreamManager? = null
    private var introPlayer: MediaPlayer? = null
    private var introSurface: Surface? = null
    private var hostPopup: PopupWindow? = null
    private var descriptionPopup: PopupWindow? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var currentScreen = Screen.INTRO
    private var playbackTopBar: View? = null
    private var playbackStatusBarCover: View? = null
    private var playbackVideoTopInsetPx = 0
    private var exitPlaybackDialog: android.app.AlertDialog? = null
    private var selectedHostIndex = 0
    private var autoHostSelection = true
    private val handler = Handler(Looper.getMainLooper())
    private var catalogItems: List<CatalogItem> = emptyList()
    private var homeCatalogItems: List<CatalogItem> = emptyList()
    private var catalogLoading = false
    private var catalogSearchLoading = false
    private var catalogSearchRunnable: Runnable? = null
    private var catalogSearchGeneration = 0
    private val translatedDescriptionCache = mutableMapOf<String, String>()
    private val posterCache = mutableMapOf<String, android.graphics.Bitmap>()
    private val continueWatchingItems = mutableListOf<CatalogItem>()
    private var currentSubtitlePlaybackKey: String? = null
    private var activeExternalSubtitleVtt: String? = null
    private var activeExternalSubtitleLabel: String = "Castellano"
    private var currentTorrentVideoUrl: String? = null
    private var torrentProgressOverlayEnabled = false
    private var torrentPlaybackActive = false
    private var vlcLib: LibVLC? = null
    private var vlcPlayer: VlcMediaPlayer? = null
    private var vlcVideoLayout: VLCVideoLayout? = null
    private var vlcControlsOverlay: FrameLayout? = null
    private var vlcStatusText: TextView? = null
    private var sportsLivePlayer: MediaPlayer? = null
    private var sportsLiveSurface: Surface? = null
    private var sportsLiveTexture: TextureView? = null
    private var sportsLiveVideoWidth = 0
    private var sportsLiveVideoHeight = 0
    private var isSportsPlayerLandscape = false
    private var sportsOrientationButton: TextView? = null
    private var vlcPlayPauseButton: TextView? = null
    private var vlcFullscreenButton: TextView? = null
    private var vlcSeekBar: SeekBar? = null
    private var vlcCurrentTimeText: TextView? = null
    private var vlcDurationText: TextView? = null
    private var vlcProgressRunnable: Runnable? = null
    private var isVlcSeekBarDragging = false
    private var isEmbeddedVlcFullscreen = false
    private var vlcHasRenderedVideo = false
    private var vlcSoftwareVolumePercent = 100
    private var vlcVolumeRepeatRunnable: Runnable? = null
    private var lastVolumeBeepAt = 0L
    private var progressUpdateRunnable: Runnable? = null
    private var isProgressUpdating = false
    private var torrentOverlayView: FrameLayout? = null

    // -- Deportes (streamed.su) ----------------------------------------------------
    private var sportsMatches: List<SportMatch> = emptyList()
    private var sportsLoading = false
    private var embedsportsFallbackIndex = 0
    // Solo interceptar streams del WebView de deportes si el usuario ha interactuado
    private var sportsWebViewUserInteracted = false
    private var sportsResolveGeneration = 0
    private val sportsResolvedStreamCache = mutableMapOf<String, SportsResolvedStream>()

    // -- MegaDescargas -------------------------------------------------------------
    private var megaSeriesList: List<com.kotatv.MegaSeries> = emptyList()
    private var megaLoading = false
    private var grantTorrentItems: List<GrantTorrentItem> = emptyList()
    private var grantTorrentLoading = false
    private var mega509RetryCount = 0

    private enum class Screen { INTRO, CATALOG, PLAYER }
    private enum class NavTab { HOME, CONTINUE_WATCHING, SETTINGS, ABOUT }

    private data class PlaybackHost(
        val key: String,
        val displayName: String,
        val shortLabel: String,
        val hostAliases: Set<String>,
        val labelAliases: Set<String> = emptySet()
    )

    private data class CatalogItem(
        val id: String,
        val title: String,
        val originalTitle: String,
        val type: String,
        val year: String,
        val runtime: String,
        val imdbId: String,
        val tmdbId: String,
        val rating: String,
        val overview: String,
        val genres: List<String>,
        val posterUrl: String,
        val backgroundUrl: String,
        val embeds: Map<String, String>,
        var lastWatchedPosition: Long = 0L,
        var lastWatchedTime: Long = 0L
    )

    private data class PlaybackChoice(
        val host: PlaybackHost,
        val url: String,
        val castellanoScore: Int
    )

    private data class CacheSummary(
        val totalCacheBytes: Long,
        val torrentCacheBytes: Long,
        val activeTorrentBytes: Long,
        val activeTorrentTotalBytes: Long,
        val activeTorrentSeeds: Int,
        val activeTorrentPeers: Int
    )

    private data class MegaDocLink(val start: Int, val end: Int, val url: String)
    private data class MegaFileLink(val id: String, val key: String)
    private data class MegaFolderLink(val id: String, val key: String)
    private data class MegaFolderVideo(val title: String, val url: String, val sizeBytes: Long, val order: Int)
    private data class MegaDownloadDialogChrome(val view: View, val titleText: TextView)
    private data class MegaDownloadInfo(
        val title: String,
        val sizeBytes: Long,
        val downloadUrl: String,
        val aesKey: ByteArray,
        val iv: ByteArray
    )

    private data class SportsResolvedStream(
        val url: String,
        val resolvedAtMs: Long
    )

    private companion object {
        private const val LOG_TAG = "DownTV"

        private const val CINEMETA_BASE_URL = "https://v3-cinemeta.strem.io"
        private const val AUTO_EMBED_BASE_URL = "https://multiembed.mov"
        private const val OPEN_SUBTITLES_STREMIO_BASE_URL = "https://opensubtitles-v3.strem.io"
        private const val OPEN_SUBTITLES_CURRENT_WEB_URL = "https://www.opensubtitles.com/es"
        private const val OPEN_SUBTITLES_LEGACY_WEB_URL = "https://www.opensubtitles.org/es/search2"
        private const val IMDB_SUGGESTION_BASE_URL = "https://v3.sg.media-imdb.com/suggestion"
        private const val GOOGLE_TRANSLATE_BASE_URL = "https://translate.googleapis.com/translate_a/single"
        private const val STREAMED_BASE_URL = "https://streamed.su"
        private const val PIRLOTV_BASE_URL = "https://pirlotv.io"
        private const val LA14HD_BASE_URL = "https://la14hd.com"
        private const val IPTV_ORG_SPORTS_M3U_URL = "https://iptv-org.github.io/iptv/categories/sports.m3u"
        private const val SPORTS_STREAM_CACHE_TTL_MS = 10 * 60 * 1000L
        private const val GRANTORRENT_BASE_URL = "https://grantorrent.wtf"
        private const val DONTORRENT_BASE_URL = "https://dontorrent.racing"
        private const val GRANTORRENT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; SAMSUNG SM-A165F) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) SamsungBrowser/27.0 Chrome/125.0.0.0 Mobile Safari/537.36"
        private const val MEGA_SERIES_CATALOG_URL = "https://megadescargas-new.blogspot.com"
        private val MEGA_SERIES_LINK_HOSTS = setOf(
            "mega-descargas-serie.blogspot.com",
            "megadescargas-new.blogspot.com",
            "megadescarga-gratis.blogspot.com",
            "megadescargas-series.blogspot.com",
            "megadescarga-series.blogspot.com",
            "tinyurl.com"
        )
        private val GRANTORRENT_LINK_HOSTS = setOf(
            "grantorrent.wtf"
        )
        private val CATALOG_TYPES = listOf("movie", "series")
        private val PREFERRED_IPTV_SPORTS_NAMES = listOf(
            "beIN Sports XTRA en Español",
            "Gol TV",
            "Gol Classics"
        )
        private val ALLOWED_IPTV_SPORTS_COUNTRIES = setOf("es", "us", "uk", "gb", "ca", "au", "nz", "ie")
        private val BLOCKED_IPTV_SPORTS_NAMES = listOf(
            "Billiard TV",
            "CBS Sports Golazo Network",
            "Strongman",
            "LaLiga Hypermotion"
        )
        private val CASTELLANO_HINTS = listOf("castellano", "espa\u00f1ol", "espanol", "es-es", "spa", "spanish")
        private val SPANISH_SUBTITLE_LANGS = setOf("spa", "esp", "es", "es-es")
        private val AUTO_EMBED_MAIN_HOSTS = setOf(
            "multiembed.mov",
            "www.multiembed.mov"
        )
        private val PLAYER_BRIDGE_HOSTS = setOf(
            "cloudnestra.com",
            "www.cloudnestra.com",
            "streamingnow.mov",
            "www.streamingnow.mov",
            "vsembed.ru",
            "www.vsembed.ru",
            "upstream.to",
            "www.upstream.to"
        )
        private val MEDIA_PROXY_HOSTS = setOf("x.iknowthatyourfatheris.gay")
        private val LOCAL_TORRENT_HOSTS = setOf("127.0.0.1", "localhost")
        private val EMBEDSPORTS_FALLBACK_SUBDOMAINS = listOf("admin", "delta", "echo")
        private val SPORTS_FALLBACK_CHANNELS = listOf(
            "golperu" to "GOLPERU",
            "laliga" to "LaLiga",
            "nba" to "NBA"
        )

        private const val COMPATIBLE_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

        private const val INTRO_ASSET = "intro.mp4"
        private const val SEARCH_HISTORY_PREF_KEY = "home_search_history"
        private const val MAX_SEARCH_HISTORY = 12

        private val PLAYBACK_HOSTS = listOf(
            PlaybackHost(
                key = "waaw",
                displayName = "Waaw / Latlat",
                shortLabel = "WAA",
                hostAliases = setOf("waaw.tv", "www.waaw.tv", "latlat.xyz", "www.latlat.xyz"),
                labelAliases = setOf("waaw", "latlat")
            ),
            PlaybackHost(
                key = "netu",
                displayName = "Netu / HQQ",
                shortLabel = "NET",
                hostAliases = setOf("netu.tv", "www.netu.tv", "netu.ac", "hqq.to", "hqq.tv", "www.hqq.to", "www.hqq.tv"),
                labelAliases = setOf("netu", "hqq")
            ),
            PlaybackHost(
                key = "streamwish",
                displayName = "StreamWish",
                shortLabel = "SWS",
                hostAliases = setOf("streamwish.to", "streamwish.com", "vidhide.com", "vidhidepro.com", "vidguard.to", "www.streamwish.to"),
                labelAliases = setOf("streamwish", "vidhide", "vidguard", "wish")
            ),
            PlaybackHost(
                key = "filemoon",
                displayName = "FileMoon",
                shortLabel = "FMN",
                hostAliases = setOf("filemoon.sx", "filemoon.to", "www.filemoon.sx", "www.filemoon.to"),
                labelAliases = setOf("filemoon", "moon")
            ),
            PlaybackHost(
                key = "streamtape",
                displayName = "StreamTape",
                shortLabel = "STP",
                hostAliases = setOf("streamtape.com", "streamtape.to", "www.streamtape.com", "www.streamtape.to"),
                labelAliases = setOf("streamtape", "tape")
            ),
            PlaybackHost(
                key = "dood",
                displayName = "DoodStream",
                shortLabel = "DOO",
                hostAliases = setOf("doodstream.com", "dood.video", "dood.wf", "dood.to", "www.doodstream.com"),
                labelAliases = setOf("dood", "doodstream")
            ),
            PlaybackHost(
                key = "uqload",
                displayName = "Uqload",
                shortLabel = "UQL",
                hostAliases = setOf("uqload.to", "uqload.com", "www.uqload.to", "www.uqload.com"),
                labelAliases = setOf("uqload")
            ),
            PlaybackHost(
                key = "mixdrop",
                displayName = "MixDrop",
                shortLabel = "MIX",
                hostAliases = setOf("mixdrop.co", "mixdrop.to", "mixdrop.ag", "www.mixdrop.co", "www.mixdrop.to"),
                labelAliases = setOf("mixdrop")
            ),
            PlaybackHost(
                key = "voe",
                displayName = "Voe",
                shortLabel = "VOE",
                hostAliases = setOf("voe.sx", "voeunblock.com", "voeunblock1.com", "www.voe.sx"),
                labelAliases = setOf("voe")
            )
        )
    }

    private val selectedHost: PlaybackHost
        get() = PLAYBACK_HOSTS[selectedHostIndex.coerceIn(0, PLAYBACK_HOSTS.lastIndex)]

    private val playbackHosts: Set<String>
        get() = PLAYBACK_HOSTS.flatMap { it.hostAliases }.map { it.lowercase().removePrefix("www.") }.toSet()

    private val blockedExternalSchemes = setOf(
        "intent", "market", "mailto", "tel", "sms", "smsto", "mms", "geo", "maps",
        "tg", "whatsapp", "viber", "fb", "instagram", "twitter", "x", "youtube", "magnet"
    )

    private val internalSchemes = setOf("about", "blob", "data", "android-webview-video-poster")

    private val suspiciousHostParts = listOf(
        // Redes publicitarias genéricas
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "googletagmanager.com", "adservice", "adserver", "adsrvr.org", "taboola.com",
        "outbrain.com", "popads", "popcash", "popunder", "propellerads", "adsterra", "exoclick",
        "mgid.com", "onesignal.com", "tracker", "tracking", "analytics", "telemetry", "hotjar.com",
        "clarity.ms", "facebook.net", "connect.facebook.net", "analytics.tiktok.com", "cryptominer",
        "adsco.re", "adscore.com",
        // Identificados directamente en el HTML de multiembed.mov y hosts de reproducción
        "synedawtit.com",           // popunder/push de multiembed
        "cdn4ads.com",              // red de anuncios (base64 en script popunder)
        "sfbyctnfokzd.com",         // red de anuncios (base64 en script popunder)
        "rxqtuwahzmb.com",          // red de anuncios (base64 en script popunder)
        "cloudfront.net/QPct",      // CDN de salac.min.js (popunder)
        "hilltopads", "hilltop-ads",
        "trafficjunky", "juicyads", "plugrush", "clickadu",
        "adcash.com", "adcash",
        "revcontent.com", "revcontent",
        "contentad.net", "contentad",
        "zeropark.com", "zeropark",
        "pushground.com", "pushground",
        "richpush.co", "richpush",
        "evadav.com", "evadav",
        "adpushup.com", "adpushup",
        "monetag.com", "monetag",
        "adnium.com", "adnium",
        "trafficstars.com", "trafficstars",
        "popads.net", "popcash.net",
        "adspyglass.com", "adspyglass",
        "bidvertiser.com", "bidvertiser",
        "yllix.com", "yllix",
        "juicyads.com",
        "fuckingfast.co",           // CDN de anuncios usado por algunos hosts
        "go.oclasrv.com", "oclasrv",
        "adbull.com", "adbull",
        "coinzilla.io", "coinzilla",
        "a-ads.com", "adbtc.top", "cpx.to",
        "tpc.googlesyndication.com",
        "pagead2.googlesyndication.com",
        "securepubads.g.doubleclick.net",
        "imasdk.googleapis.com",    // Google IMA SDK (anuncios en video)
        "pubads.g.doubleclick.net",
        "galaksion.com", "cdn.galaksion",  // red de anuncios de Nupload
        "realpikashowapk.com", "pikashow", // anuncio pre-roll visto en captura
        "1xbet", "xbet.com", "1xbet.com", "1xbet.mobi", "1xbet.tv", // anuncios 1xbet (Vidoza, Nupload)
        "xbet", "1x-bet", "1xstavka", "1xbet-", "-1xbet",          // variantes de 1xbet
        "adnxs.com", "rubiconproject.com", "openx.net",
        "spotxchange.com", "springserve.com", "adform.net",
        "smartadserver.com", "pubmatic.com", "appnexus.com",
        "lkqd.net", "lijit.com", "sovrn.com",
        "sharethrough.com", "triplelift.com",
        "criteo.com", "criteo.net",
        "amazon-adsystem.com",
        "media.net", "media-net",
        "vidazoo.com", "vidazoo",
        "undertone.com", "undertone",
        "yieldmo.com", "yieldmo",
        // Patrones específicos de Nupload para bloquear anuncios
        "nupload.me/ad", "ap.nupload.me/ad",
        "nupload.me/preroll", "nupload.me/vast",
        "nupload.me/player/ad", "nupload.me/player/preroll",
        "nupcdn.com", "nupcdn.net",  // CDN de anuncios de Nupload
        "nuads.net", "nupload-ads",  // Posibles dominios de anuncios de Nupload
        // Patrones específicos de Vidoza para bloquear anuncios 1xbet
        "vidoza.net/ad", "vidoza.net/preroll", "vidoza.net/vast",
        "vidozacdn.com", "vidoza-ads"
    )

    private val suspiciousUrlParts = listOf(
        "/ads/", "/adserver", "/advert", "/banner", "/prebid", "/vast", "/vpaid", "/ima3",
        "/popunder", "/popup", "runpop", "zoneid=", "/push/", "/notification", "/tracker",
        "/tracking", "/analytics", "/metrics", "/telemetry", "/collector", "/fingerprint", "gclid=",
        "fbclid=", "msclkid=", "aff_id=", "affiliate=", "adtag=", "adunit=", "adsco",
        "/rhk5", "/lBacon", "/cBacon", "/YuuMHk", "/palac", "/salac", // scripts de popunder vistos en HTML
        "popundersPerIP", "topmostLayer", "minBid",
        "/ima/", "/adsense/", "/pagead/", "/adx/",
        "prebid.js", "prebid.min.js",
        "/push-notification", "/sw.js", "/service-worker",
        "/preroll", "/pre-roll", "/midroll", "/postroll",  // anuncios en video
        "realpikashowapk", "pikashow",                     // visto en captura
        "1xbet", "xbet", "1x-bet", "1xstavka",             // anuncios 1xbet (Vidoza, Nupload)
        "/vast.xml", "/vast2", "/vast3", "/vmap",
        "ad_type=", "ad_unit=", "adzone=", "adslot=",
        "galaksion",                                       // red de anuncios de Nupload
        // Patrones específicos de Nupload
        "nupload.me/ad", "nupload.me/preroll", "nupload.me/player/ad",
        "/nupcdn/", "/nuads/", "nupload-ad",
        // Patrones específicos de Vidoza
        "vidoza.net/ad", "vidoza.net/preroll", "/vidozacdn/", "vidoza-ad"
    )

    private val blockedFileExtensions = setOf(
        ".apk", ".aab", ".exe", ".msi", ".bat", ".cmd", ".com", ".scr", ".ps1", ".vbs",
        ".jar", ".dmg", ".pkg", ".deb", ".rpm", ".zip", ".rar", ".7z", ".iso", ".torrent"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(
            (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.keepScreenOn = true
        applyWindowBars()
        rootView = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(rootView)

        // Solicitar permiso de notificaciones (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        // Cargar preferencias
        val prefs = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
        autoHostSelection = prefs.getBoolean("auto_host_selection", true)
        selectedHostIndex = prefs.getInt("selected_host_index", 0)

        loadContinueWatching()
        loadAutomaticCatalog()
        loadSportsMatches()
        loadMegaSeriesCatalog()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fullscreenView != null -> exitFullscreenVideo()
                    currentScreen == Screen.PLAYER -> confirmExitPlayback()
                    currentScreen == Screen.INTRO -> showCatalog()
                    else -> finish()
                }
            }
        })

        if (!handlePlaybackIntent(intent)) {
            playIntroIfAvailable()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePlaybackIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post {
            resizeSportsLiveTextureToVideo()
            vlcPlayer?.updateVideoSurfaces()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        searchHintAnimator?.cancel()
        searchHintAnimator = null
        posterCache.clear()
        saveContinueWatching()
        releaseIntroPlayer()
        releaseSportsLivePlayer()
        destroyOpenSubtitlesWebView()
        destroyPlayerWebView()
    }

    private fun handlePlaybackIntent(intent: Intent?): Boolean {
        val torrentUrl = intent?.getStringExtra("torrent_url")?.trim().orEmpty()
        if (torrentUrl.isNotBlank()) {
            intent?.removeExtra("torrent_url")
            intent?.removeExtra("auto_play")
            val title = intent?.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: "Torrent"
            val item = CatalogItem(
                id = "intent:${torrentUrl.hashCode()}",
                title = title,
                originalTitle = title,
                type = "movie",
                year = "",
                runtime = "",
                imdbId = "",
                tmdbId = "",
                rating = "",
                overview = "",
                genres = listOf("Torrent"),
                posterUrl = "",
                backgroundUrl = "",
                embeds = emptyMap()
            )
            proceedWithTorrentDownload(
                addon = "Torrent",
                magnetUri = torrentUrl,
                fileIdx = null,
                quality = "Torrent",
                size = "",
                seeders = "?",
                item = item,
                useVlcPlayer = true
            )
            return true
        }

        val megaUrl = intent?.getStringExtra("mega_url")?.trim().orEmpty()
        if (megaUrl.isNotBlank()) {
            intent?.removeExtra("mega_url")
            openMegaEpisode(megaUrl)
            return true
        }

        // Manejar enlaces de shon.xyz desde MegaSeriesViewerActivity
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            val url = intent.data.toString()
            if (url.contains("shon.xyz", ignoreCase = true) || 
                url.contains("ouo.io", ignoreCase = true) ||
                url.contains("ouo.press", ignoreCase = true)) {
                intent.data = null
                openMegaEpisode(url)
                return true
            }
        }

        return false
    }


    private fun playIntroIfAvailable() {
        // Verificar preferencia de reproducir intro
        val prefs = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
        val playIntro = prefs.getBoolean("play_intro", true)
        
        if (!playIntro || !assetExists(INTRO_ASSET)) {
            showCatalog()
            return
        }

        currentScreen = Screen.INTRO
        releaseIntroPlayer()
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        val introLayer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val topSafeBar = View(this).apply { setBackgroundColor(STATUS_BAR_COLOR) }
        val videoView = TextureView(this).apply {
            isOpaque = true
        }
        val skip = TextView(this).apply {
            text = "›"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable().apply {
                setColor(Color.BLACK); setStroke(dp(1), Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener { showCatalog() }
        }

        introLayer.addView(videoView, FrameLayout.LayoutParams(-1, -1))
        introLayer.addView(
            skip,
            FrameLayout.LayoutParams(-2, dp(42), Gravity.TOP or Gravity.END).apply {
                topMargin = statusBarHeight() + dp(8)
                rightMargin = dp(20)
            }
        )
        rootView.addView(introLayer, FrameLayout.LayoutParams(-1, -1))
        rootView.addView(topSafeBar, FrameLayout.LayoutParams(-1, statusBarHeight() + dp(4), Gravity.TOP))

        try {
            val target = File(cacheDir, INTRO_ASSET)
            assets.open(INTRO_ASSET).use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }

            fun start(surfaceTexture: SurfaceTexture) {
                releaseIntroPlayer()
                val surface = Surface(surfaceTexture)
                introSurface = surface
                introPlayer = MediaPlayer().apply {
                    setDataSource(target.absolutePath)
                    setSurface(surface)
                    setOnCompletionListener { showCatalog() }
                    setOnErrorListener { _, _, _ ->
                        showCatalog()
                        true
                    }
                    setOnPreparedListener { player ->
                        player.isLooping = false
                        player.setVolume(0f, 0f)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            player.seekTo(280L, MediaPlayer.SEEK_CLOSEST)
                        } else {
                            @Suppress("DEPRECATION")
                            player.seekTo(280)
                        }
                        player.start()
                        handler.postDelayed({
                            if (introPlayer == player && currentScreen == Screen.INTRO) player.setVolume(1f, 1f)
                        }, 650)
                    }
                    prepareAsync()
                }
            }

            videoView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                    start(surface)
                }

                override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) = Unit

                override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                    releaseIntroPlayer()
                    return true
                }

                override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
            }

            videoView.surfaceTexture?.let { start(it) }
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "No se pudo reproducir la intro", error)
            showCatalog()
        }
    }

    private fun releaseIntroPlayer() {
        try {
            introPlayer?.stop()
        } catch (_: Throwable) {
        }
        try {
            introPlayer?.release()
        } catch (_: Throwable) {
        }
        try {
            introSurface?.release()
        } catch (_: Throwable) {
        }
        introPlayer = null
        introSurface = null
    }

    private fun releaseSportsLivePlayer() {
        try {
            sportsLivePlayer?.stop()
        } catch (_: Throwable) {
        }
        try {
            sportsLivePlayer?.release()
        } catch (_: Throwable) {
        }
        try {
            sportsLiveSurface?.release()
        } catch (_: Throwable) {
        }
        sportsLivePlayer = null
        sportsLiveSurface = null
        sportsLiveTexture = null
        sportsLiveVideoWidth = 0
        sportsLiveVideoHeight = 0
        sportsOrientationButton = null
    }

    private fun showCatalog() {
        currentScreen = Screen.CATALOG
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        isSportsPlayerLandscape = false
        applyWindowBars()
        sportsWebViewUserInteracted = false  // resetear al volver al catálogo
        releaseIntroPlayer()
        releaseSportsLivePlayer()
        descriptionPopup?.dismiss()
        destroyOpenSubtitlesWebView()
        destroyPlayerWebView()
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        catalogScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.BLACK)
            isFocusable = false
        }
        catalogContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Padding ajustado para evitar choque con barra de estado
            val topPadding = if (isWideLayout()) dp(12) else dp(4)
            val bottomPadding = if (isWideLayout()) dp(34) else dp(20)
            setPadding(dp(20), topPadding, dp(20), bottomPadding)
        }
        catalogScroll.addView(catalogContent, ViewGroup.LayoutParams(-1, -2))
        
        // Barra azul oscura superior — cubre la barra de estado del sistema
        val sbHeight = statusBarHeight()
        val topBar = View(this).apply {
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, sbHeight + dp(4), Gravity.TOP))
        rootView.addView(catalogScroll, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = sbHeight + dp(4)
        })

        buildNavigationBar()
        // Solo mostrar búsqueda en HOME
        if (currentNavTab == NavTab.HOME) {
            buildSearchRow()
        } else {
            searchHintAnimator?.cancel()
            searchHintAnimator = null
        }
        renderCurrentTab()
        refreshCatalogLayout()
    }

    private fun buildNavigationBar() {
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }

        val tabs = listOf(
            NavTab.HOME to "HOME",
            NavTab.SETTINGS to "AJUSTES",
            NavTab.ABOUT to "ABOUT"
        )

        tabs.forEachIndexed { index, (tab, label) ->
            val button = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                letterSpacing = 0.05f
                setPadding(dp(16), dp(8), dp(16), dp(8))
                
                val isSelected = currentNavTab == tab
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(Color.BLACK)
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.WHITE)
                    alpha = if (isSelected) 255 else 110
                }
                
                setOnClickListener {
                    currentNavTab = tab
                    showCatalog()
                }
            }
            navBar.addView(button, LinearLayout.LayoutParams(-2, -2).apply {
                if (index < tabs.lastIndex) rightMargin = dp(8)
            })
        }

        catalogContent.addView(navBar, LinearLayout.LayoutParams(-1, -2).apply { 
            bottomMargin = dp(16)
        })
    }

    private fun buildSearchRow() {
        searchHintAnimator?.cancel()
        searchBox = EditText(this).apply {
            hint = "BUSCAR"
            setHintTextColor(Color.WHITE)
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(18), 0, dp(18), 0)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            setOnFocusChangeListener { _, _ -> refreshSearchHistoryUI() }
            setOnEditorActionListener { _, _, _ ->
                rememberHomeSearch(text?.toString().orEmpty())
                false
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val query = s?.toString().orEmpty()
                    if (currentNavTab == NavTab.HOME) {
                        refreshSearchHistoryUI()
                        renderCatalogItems(query)
                        scheduleCatalogSearch(query)
                    }
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        searchHintAnimator = ValueAnimator.ofInt(255, 70).apply {
            duration = 1800L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { animator ->
                val alpha = animator.animatedValue as Int
                if (::searchBox.isInitialized) {
                    searchBox.setHintTextColor(Color.argb(alpha, 255, 255, 255))
                }
            }
            start()
        }

        catalogContent.addView(searchBox, LinearLayout.LayoutParams(-1, dp(50)).apply {
            bottomMargin = dp(8)
        })

        searchHistoryContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        catalogContent.addView(searchHistoryContainer, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })
        refreshSearchHistoryUI()
    }

    private fun loadHomeSearchHistory(): MutableList<String> {
        val raw = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
            .getString(SEARCH_HISTORY_PREF_KEY, "[]")
            .orEmpty()
        val result = mutableListOf<String>()
        try {
            val array = JSONArray(raw)
            for (index in 0 until array.length()) {
                val value = array.optString(index).trim()
                if (value.isNotBlank()) result += value
            }
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo leer el historial de busqueda", error)
        }
        return result.distinctBy { it.lowercase() }.take(MAX_SEARCH_HISTORY).toMutableList()
    }

    private fun persistHomeSearchHistory(history: List<String>) {
        val array = JSONArray()
        history.take(MAX_SEARCH_HISTORY).forEach { array.put(it) }
        getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
            .edit()
            .putString(SEARCH_HISTORY_PREF_KEY, array.toString())
            .apply()
    }

    private fun rememberHomeSearch(query: String) {
        val clean = query.trim()
        if (clean.length < 2) return
        val history = loadHomeSearchHistory()
        history.removeAll { it.equals(clean, ignoreCase = true) }
        history.add(0, clean)
        persistHomeSearchHistory(history)
        refreshSearchHistoryUI()
    }

    private fun clearHomeSearchHistory() {
        persistHomeSearchHistory(emptyList())
        refreshSearchHistoryUI()
    }

    private fun refreshSearchHistoryUI() {
        if (currentNavTab != NavTab.HOME) return
        val container = searchHistoryContainer ?: return
        container.removeAllViews()
        val history = loadHomeSearchHistory()
        if (history.isEmpty()) {
            container.visibility = View.GONE
            return
        }
        container.visibility = View.VISIBLE
        history.take(8).forEach { query ->
            val row = TextView(this).apply {
                text = query
                setTextColor(Color.WHITE)
                textSize = 13f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                background = GradientDrawable().apply {
                    setColor(Color.BLACK)
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.WHITE)
                }
                setOnClickListener {
                    searchBox.setText(query)
                    searchBox.setSelection(searchBox.text?.length ?: 0)
                    rememberHomeSearch(query)
                }
            }
            container.addView(row, LinearLayout.LayoutParams(-1, dp(38)).apply {
                bottomMargin = dp(6)
            })
        }
    }

    private fun renderCurrentTab() {
        when (currentNavTab) {
            NavTab.HOME -> {
                // Asegurar que searchBox existe antes de usarlo
                val query = if (::searchBox.isInitialized) searchBox.text?.toString().orEmpty() else ""
                renderCatalogItems(query)
            }
            NavTab.SETTINGS -> renderSettingsTab()
            NavTab.ABOUT -> renderAboutTab()
            else -> {
                val query = if (::searchBox.isInitialized) searchBox.text?.toString().orEmpty() else ""
                renderCatalogItems(query)
            }
        }
    }

    private fun currentSearchQuery(): String =
        if (::searchBox.isInitialized) searchBox.text?.toString().orEmpty() else ""

    private fun renderAboutTab() {
        while (catalogContent.childCount > 1) {
            catalogContent.removeViewAt(catalogContent.childCount - 1)
        }

        val cleanText = aboutText.trim()
        if (cleanText.isBlank()) return

        val aboutBox = TextView(this).apply {
            text = buildClickableAboutText(cleanText)
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.create("casual", Typeface.NORMAL)
            gravity = Gravity.START
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            includeFontPadding = true
            movementMethod = LinkMovementMethod.getInstance()
            highlightColor = Color.TRANSPARENT
            setLineSpacing(dp(5).toFloat(), 1.08f)
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }

        catalogContent.addView(aboutBox, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(8)
        })
    }

    private fun buildClickableAboutText(rawText: String): SpannableString {
        val spannable = SpannableString(rawText)
        val urlRegex = Regex("""https?://[^\s<>\"']+""")

        urlRegex.findAll(rawText).forEach { match ->
            var start = match.range.first
            var end = match.range.last + 1

            while (end > start && rawText[end - 1] in charArrayOf('.', ',', ';', ':', ')', ']', '}')) {
                end--
            }

            val url = rawText.substring(start, end)
            spannable.setSpan(
                object : ClickableSpan() {
                    override fun onClick(widget: View) {
                        openAboutUrl(url)
                    }

                    override fun updateDrawState(ds: TextPaint) {
                        super.updateDrawState(ds)
                        ds.color = Color.rgb(120, 220, 255)
                        ds.isUnderlineText = true
                        ds.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    }
                },
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        return spannable
    }

    private fun openAboutUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
            }
            startActivity(intent)
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo abrir el enlace del ABOUT: $url", error)
            showToast("No se pudo abrir el enlace")
        }
    }

    private fun renderOpenSubtitlesTab() {
        while (catalogContent.childCount > 1) {
            catalogContent.removeViewAt(catalogContent.childCount - 1)
        }
        destroyOpenSubtitlesWebView()

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(10))
        }
        val currentButton = openSubtitlesModeButton("Actual")
        val legacyButton = openSubtitlesModeButton("Historico")
        fun refreshModeButtons() {
            styleOpenSubtitlesModeButton(currentButton, !openSubtitlesUseLegacy)
            styleOpenSubtitlesModeButton(legacyButton, openSubtitlesUseLegacy)
        }
        currentButton.setOnClickListener {
            openSubtitlesUseLegacy = false
            refreshModeButtons()
            openSubtitlesWebView?.loadUrl(openSubtitlesUrlForQuery(""))
        }
        legacyButton.setOnClickListener {
            openSubtitlesUseLegacy = true
            refreshModeButtons()
            openSubtitlesWebView?.loadUrl(openSubtitlesUrlForQuery(""))
        }
        modeRow.addView(currentButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(8) })
        modeRow.addView(legacyButton, LinearLayout.LayoutParams(0, dp(40), 1f))
        refreshModeButtons()

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val subtitleSearch = EditText(this).apply {
            hint = "Buscar subtitulos"
            setHintTextColor(0xFF888888.toInt())
            setTextColor(Color.WHITE)
            textSize = 13f
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), 0, dp(12), 0)
            background = GradientDrawable().apply {
                setColor(0xFF111111.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            setOnEditorActionListener { _, _, _ ->
                openSubtitlesWebView?.loadUrl(openSubtitlesUrlForQuery(text?.toString().orEmpty()))
                false
            }
        }
        val searchButton = TextView(this).apply {
            text = "BUSCAR"
            setTextColor(Color.BLACK)
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener {
                openSubtitlesWebView?.loadUrl(openSubtitlesUrlForQuery(subtitleSearch.text?.toString().orEmpty()))
            }
        }
        searchRow.addView(subtitleSearch, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(8) })
        searchRow.addView(searchButton, LinearLayout.LayoutParams(dp(92), dp(42)))

        val webHeight = (resources.displayMetrics.heightPixels - statusBarHeight() - dp(170)).coerceAtLeast(dp(460))
        val wv = buildOpenSubtitlesWebView(openSubtitlesUrlForQuery(""))
        openSubtitlesWebView = wv

        catalogContent.addView(modeRow, LinearLayout.LayoutParams(-1, -2))
        catalogContent.addView(searchRow, LinearLayout.LayoutParams(-1, -2))
        catalogContent.addView(wv, LinearLayout.LayoutParams(-1, webHeight))
        refreshCatalogLayout()
    }

    private fun openSubtitlesModeButton(label: String): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun styleOpenSubtitlesModeButton(button: TextView, selected: Boolean) {
        button.setTextColor(Color.WHITE)
        button.background = GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), if (selected) Color.WHITE else 0xFF333333.toInt())
        }
        button.alpha = if (selected) 1f else 0.7f
    }

    private fun openSubtitlesUrlForQuery(rawQuery: String): String {
        val query = rawQuery.trim()
        val base = if (openSubtitlesUseLegacy) OPEN_SUBTITLES_LEGACY_WEB_URL else OPEN_SUBTITLES_CURRENT_WEB_URL
        if (query.isBlank()) return base
        val encoded = Uri.encode(query)
        return if (openSubtitlesUseLegacy) {
            "$OPEN_SUBTITLES_LEGACY_WEB_URL/sublanguageid-all/moviename-$encoded"
        } else {
            "$OPEN_SUBTITLES_CURRENT_WEB_URL/search2/sublanguageid-all/moviename-$encoded"
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildOpenSubtitlesWebView(startUrl: String): WebView {
        return WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = COMPATIBLE_USER_AGENT
                loadWithOverviewMode = true
                useWideViewPort = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = false
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val reqUrl = request.url.toString()
                    val host = request.url.host?.lowercase().orEmpty()
                    return if (isOpenSubtitlesBlockedRequest(host, reqUrl)) emptyResponse() else null
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val reqUrl = request.url.toString()
                    val uri = request.url
                    val scheme = uri.scheme?.lowercase().orEmpty()
                    val host = uri.host?.lowercase().orEmpty()
                    if (scheme !in setOf("http", "https", "about", "data")) return true
                    if (isOpenSubtitlesBlockedRequest(host, reqUrl)) return true
                    if (request.isForMainFrame && !isOpenSubtitlesAllowedHost(host)) {
                        Log.d(LOG_TAG, "OpenSubtitles popup/navigation blocked: $reqUrl")
                        return true
                    }
                    return false
                }

                override fun onPageFinished(view: WebView, url: String) {
                    injectOpenSubtitlesCleanerJs(view)
                }

                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    handler.proceed()
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                    return false
                }

                override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                    result.cancel()
                    return true
                }

                override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                    result.cancel()
                    return true
                }
            }
            loadUrl(startUrl)
        }
    }

    private fun isOpenSubtitlesAllowedHost(host: String): Boolean {
        val h = host.lowercase().removePrefix("www.")
        return h == "opensubtitles.com" ||
            h == "opensubtitles.org" ||
            h.endsWith(".opensubtitles.com") ||
            h.endsWith(".opensubtitles.org") ||
            h == "osdb.link"
    }

    private fun isOpenSubtitlesBlockedRequest(host: String, url: String): Boolean {
        if (host.isBlank()) return false
        val h = host.lowercase().removePrefix("www.")
        if (isOpenSubtitlesAllowedHost(h)) return false
        return isSportsAdRequest(h, url)
    }

    private fun injectOpenSubtitlesCleanerJs(view: WebView) {
        val js = """
            (function() {
                if (window.__kotaSubtitleClean) return;
                window.__kotaSubtitleClean = true;
                window.open = function(url) {
                    if (typeof url === 'string') {
                        try {
                            var h = new URL(url, location.href).hostname.replace(/^www\./, '');
                            if (h === 'opensubtitles.com' || h === 'opensubtitles.org' || h.endsWith('.opensubtitles.com') || h.endsWith('.opensubtitles.org')) {
                                location.href = url;
                            }
                        } catch(e) {}
                    }
                    return null;
                };
                window.alert = function(){};
                window.confirm = function(){ return false; };
                window.prompt = function(){ return null; };
                function clean() {
                    var selectors = [
                        '[class*="popup"]','[class*="pop-up"]','[class*="advert"]','[class*="ads"]',
                        '[id*="popup"]','[id*="advert"]','[id*="ads"]','iframe[src*="doubleclick"]',
                        'iframe[src*="googlesyndication"]','[class*="push"]','[id*="push"]',
                        '[class*="newsletter"]','[id*="newsletter"]','[target="_blank"]'
                    ];
                    selectors.forEach(function(sel) {
                        try {
                            document.querySelectorAll(sel).forEach(function(el) {
                                if (sel === '[target="_blank"]') el.removeAttribute('target');
                                else el.remove();
                            });
                        } catch(e) {}
                    });
                }
                clean();
                new MutationObserver(clean).observe(document.documentElement, {childList:true, subtree:true});
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun destroyOpenSubtitlesWebView() {
        val view = openSubtitlesWebView ?: return
        openSubtitlesWebView = null
        try { view.stopLoading() } catch (_: Throwable) {}
        try { view.loadUrl("about:blank") } catch (_: Throwable) {}
        try { view.destroy() } catch (_: Throwable) {}
    }

    private fun renderContinueWatchingTab() {
        // Limpiar vistas anteriores (mantener solo navegación y búsqueda si existe)
        val keepViews = if (::searchBox.isInitialized) 2 else 1
        while (catalogContent.childCount > keepViews) {
            catalogContent.removeViewAt(catalogContent.childCount - 1)
        }
        
        if (continueWatchingItems.isEmpty()) {
            catalogContent.addView(emptyState("No has visto nada aún.\nReproducir contenido para que aparezca aquí."))
            return
        }
        
        addSectionTitle("Seguir viendo")
        addCatalogGrid(continueWatchingItems)
    }


    private fun renderSettingsTab() {
        // Limpiar vistas anteriores (mantener solo navegación)
        while (catalogContent.childCount > 1) {
            catalogContent.removeViewAt(catalogContent.childCount - 1)
        }
        
        // Asegurar que el fondo sea visible
        catalogContent.setBackgroundColor(Color.BLACK)
        catalogScroll.setBackgroundColor(Color.BLACK)
        
        // Opción de reproducir intro
        val introSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }
        
        val introLabel = TextView(this).apply {
            text = "Reproducir vídeo de introducción"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(8))
        }
        introSection.addView(introLabel)
        
        val introDescription = TextView(this).apply {
            text = "Mostrar el vídeo de introducción al abrir la aplicación."
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(12))
        }
        introSection.addView(introDescription)
        
        val prefs = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
        val playIntro = prefs.getBoolean("play_intro", true)
        
        val introRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        
        val yesButton = TextView(this).apply {
            text = "Sí"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), if (playIntro) Color.WHITE else Color.BLACK)
            }
        }
        
        val noButton = TextView(this).apply {
            text = "No"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), if (!playIntro) Color.WHITE else Color.BLACK)
            }
        }
        
        yesButton.setOnClickListener {
            prefs.edit().putBoolean("play_intro", true).apply()
            yesButton.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            noButton.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.BLACK)
            }
        }
        
        noButton.setOnClickListener {
            prefs.edit().putBoolean("play_intro", false).apply()
            yesButton.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.BLACK)
            }
            noButton.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        
        introRow.addView(yesButton, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        introRow.addView(noButton, LinearLayout.LayoutParams(0, -2, 1f))
        introSection.addView(introRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })
        
        catalogContent.addView(introSection)
        
        // Borrar historial de "Seguir viendo"
        val clearHistorySection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }
        
        val clearHistoryLabel = TextView(this).apply {
            text = "Historial de reproducción"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(8))
        }
        clearHistorySection.addView(clearHistoryLabel)
        
        val clearHistoryDescription = TextView(this).apply {
            text = "Elimina todo el historial de \"Seguir viendo\"."
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(12))
        }
        clearHistorySection.addView(clearHistoryDescription)
        
        val clearButton = TextView(this).apply {
            text = "Borrar historial"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            
            setOnClickListener {
                // Mostrar diálogo de confirmación
                val dialog = android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Borrar historial")
                    .setMessage("¿Estás seguro de que quieres borrar todo el historial de \"Seguir viendo\"? Esta acción no se puede deshacer.")
                    .setPositiveButton("Borrar") { _, _ ->
                        continueWatchingItems.clear()
                        saveContinueWatching()
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Historial borrado",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                    .setNegativeButton("Cancelar", null)
                    .create()
                dialog.show()
            }
        }
        clearHistorySection.addView(clearButton, LinearLayout.LayoutParams(-1, -2))
        
        catalogContent.addView(clearHistorySection)

        val clearSearchHistorySection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }

        clearSearchHistorySection.addView(TextView(this).apply {
            text = "Historial de búsqueda"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(8))
        })

        clearSearchHistorySection.addView(TextView(this).apply {
            text = "Elimina las búsquedas guardadas."
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(12))
        })

        val clearSearchButton = TextView(this).apply {
            text = "Borrar historial de búsqueda"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Borrar historial de búsqueda")
                    .setMessage("¿Quieres borrar todas las búsquedas guardadas?")
                    .setPositiveButton("Borrar") { _, _ ->
                        clearHomeSearchHistory()
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Historial de búsqueda borrado",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
        clearSearchHistorySection.addView(clearSearchButton, LinearLayout.LayoutParams(-1, -2))
        catalogContent.addView(clearSearchHistorySection)
        
        // Borrar caché de torrents
        val clearCacheSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(24), 0, dp(16))
        }
        
        val clearCacheLabel = TextView(this).apply {
            text = "Caché de torrents"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(8))
        }
        clearCacheSection.addView(clearCacheLabel)
        
        // Calcular tamaño del caché en segundo plano
        val clearCacheDescription = TextView(this).apply {
            text = "Los torrents descargados ocupan espacio. Calculando tamaño..."
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(12))
        }
        clearCacheSection.addView(clearCacheDescription)
        
        val clearCacheButton = TextView(this).apply {
            text = "Borrar caché"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            isEnabled = false
            alpha = 0.5f
        }
        clearCacheSection.addView(clearCacheButton, LinearLayout.LayoutParams(-1, -2))

        val openDownloadsButton = TextView(this).apply {
            text = "Abrir carpeta de descargas"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            setOnClickListener { openDownloadsFolder() }
        }
        clearCacheSection.addView(
            openDownloadsButton,
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        )
        
        catalogContent.addView(clearCacheSection)
        
        // Calcular tamaño en segundo plano. Los torrents completos e incompletos
        // se mantienen hasta que el usuario los borre desde Ajustes.
        Thread {
            val cacheSummary = buildCacheSummary()
            val cacheSizeText = formatFileSize(cacheSummary.totalCacheBytes)
            
            handler.post {
                clearCacheDescription.text = cacheSummaryText(cacheSummary)
                clearCacheButton.text = "Borrar caché ($cacheSizeText)"
                clearCacheButton.isEnabled = true
                clearCacheButton.alpha = 1.0f
                
                clearCacheButton.setOnClickListener {
                    // Mostrar diálogo de confirmación
                    val dialog = android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Borrar caché")
                        .setMessage("¿Estás seguro de que quieres borrar toda la caché de la app ($cacheSizeText), incluyendo torrents completos e incompletos?")
                        .setPositiveButton("Borrar") { _, _ ->
                            Thread {
                                try {
                                    val freedSpace = clearTotalAppCache()
                                    handler.post {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Caché borrado: ${formatFileSize(freedSpace)} liberados",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                        // Refrescar la pantalla de ajustes
                                        renderCurrentTab()
                                    }
                                } catch (e: Exception) {
                                    handler.post {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Error: ${e.message}",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            }.start()
                        }
                        .setNegativeButton("Cancelar", null)
                        .create()
                    dialog.show()
                }
            }
        }.start()
    }
    
    private fun calculateDirectorySize(directory: File): Long {
        if (!directory.exists()) return 0L
        var size = 0L
        try {
            directory.walkTopDown().forEach { file ->
                if (file.isFile) {
                    size += fileStorageBytes(file)
                }
            }
        } catch (e: Exception) {
            Log.e(LOG_TAG, "Error calculando tamaño de directorio", e)
        }
        return size
    }

    private fun fileStorageBytes(file: File): Long {
        return try {
            (Os.stat(file.absolutePath).st_blocks * 512L).coerceAtLeast(0L)
        } catch (_: Throwable) {
            file.length()
        }
    }

    private fun buildCacheSummary(): CacheSummary {
        val activeStats = torrentStreamManager?.getDownloadStats()
        val downloadRoot = appDownloadRootDir()
        val legacyTorrentCache = File(cacheDir, "torrents")
        val legacyExternalRoot = legacyExternalDownloadRootDir()

        val cacheBytes = calculateDirectorySize(cacheDir)
        val downloadBytes = calculateDirectorySize(downloadRoot)
        val legacyTorrentCacheBytes = if (sameOrChild(downloadRoot, legacyTorrentCache)) {
            0L
        } else {
            calculateDirectorySize(legacyTorrentCache)
        }
        val legacyExternalBytes = legacyExternalRoot
            ?.takeUnless { sameOrChild(downloadRoot, it) || sameOrChild(cacheDir, it) }
            ?.let { calculateDirectorySize(it) }
            ?: 0L

        val totalBytes = if (sameOrChild(cacheDir, downloadRoot)) {
            cacheBytes + legacyExternalBytes
        } else {
            cacheBytes + downloadBytes + legacyExternalBytes
        }

        return CacheSummary(
            totalCacheBytes = totalBytes,
            torrentCacheBytes = downloadBytes + legacyTorrentCacheBytes + legacyExternalBytes,
            activeTorrentBytes = activeStats?.totalWantedDone ?: 0L,
            activeTorrentTotalBytes = activeStats?.totalWanted ?: 0L,
            activeTorrentSeeds = activeStats?.numSeeds ?: 0,
            activeTorrentPeers = activeStats?.numPeers ?: 0
        )
    }

    private fun cacheSummaryText(summary: CacheSummary): String {
        val totalText = "Caché total de la app: ${formatFileSize(summary.totalCacheBytes)}."
        val torrentText = "Torrents y videos: ${formatFileSize(summary.torrentCacheBytes)}."
        if (summary.activeTorrentTotalBytes <= 0L) {
            return "$totalText $torrentText"
        }

        val percent = if (summary.activeTorrentTotalBytes > 0L) {
            ((summary.activeTorrentBytes * 100L) / summary.activeTorrentTotalBytes).coerceIn(0L, 100L)
        } else {
            0L
        }
        val peersText = if (summary.activeTorrentSeeds > 0 || summary.activeTorrentPeers > 0) {
            " · ${summary.activeTorrentSeeds} seeders · ${summary.activeTorrentPeers} peers"
        } else {
            ""
        }
        return "$totalText $torrentText Torrent activo: ${formatFileSize(summary.activeTorrentBytes)} de ${formatFileSize(summary.activeTorrentTotalBytes)} ($percent%)$peersText."
    }

    private fun clearTotalAppCache(): Long {
        val before = buildCacheSummary().totalCacheBytes
        torrentStreamManager?.stopStreaming()
        torrentStreamManager = null
        stopProgressUpdater()
        cancelTorrentDownloadNotification()

        deleteChildren(cacheDir)
        deleteChildren(appDownloadRootDir())
        legacyExternalDownloadRootDir()?.let { deleteChildren(it) }
        cacheDir.mkdirs()
        appDownloadRootDir().mkdirs()
        return before
    }

    private fun appDownloadRootDir(): File {
        // Ruta actual: almacenamiento interno privado.
        // Evita que vold interrumpa el proceso por ficheros torrent grandes/sparse
        // abiertos en /storage/emulated/0/Android/data/...
        return File(filesDir, "DownTV").apply { mkdirs() }
    }

    private fun legacyExternalDownloadRootDir(): File? {
        val externalDownloads = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return null
        return File(externalDownloads, "DownTV")
    }

    private fun appTorrentDownloadDir(): File {
        return File(appDownloadRootDir(), "torrents").apply { mkdirs() }
    }

    private fun deleteChildren(directory: File) {
        directory.listFiles()?.forEach { file ->
            try {
                file.deleteRecursively()
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "No se pudo borrar ${file.absolutePath}", error)
            }
        }
    }

    private fun sameOrChild(parent: File, candidate: File): Boolean {
        return try {
            val parentPath = parent.canonicalPath.trimEnd(File.separatorChar)
            val candidatePath = candidate.canonicalPath
            candidatePath == parentPath || candidatePath.startsWith(parentPath + File.separator)
        } catch (_: Throwable) {
            false
        }
    }

    private fun openDownloadsFolder() {
        val folder = appDownloadRootDir()
        appTorrentDownloadDir()

        try {
            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                folder
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "resource/folder")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                clipData = ClipData.newUri(contentResolver, "DownTV downloads", uri)
                putExtra("android.content.extra.SHOW_ADVANCED", true)
            }
            startActivity(Intent.createChooser(intent, "Abrir carpeta de descargas"))
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo abrir carpeta de descargas", error)
            showDownloadsFolderFallback(folder)
        }
    }

    private fun showDownloadsFolderFallback(folder: File) {
        val files = folder.walkTopDown()
            .filter { it.isFile }
            .sortedByDescending { it.lastModified() }
            .toList()

        if (files.isEmpty()) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Carpeta de descargas")
                .setMessage("Android no permite abrir esta carpeta directamente en este dispositivo.\n\n${folder.absolutePath}\n\nNo hay archivos descargados todavía.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        val labels = files
            .take(50)
            .map { file ->
                "${file.relativeTo(folder).path} · ${formatFileSize(fileStorageBytes(file))} en disco"
            }
            .toList()

        val message = buildString {
            append("Android no permite abrir esta carpeta directamente en este dispositivo.\n\n")
            append(folder.absolutePath)
            append("\n\nToca un archivo para abrirlo. Si tu gestor no puede entrar en la carpeta, exporta todo como ZIP.")
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("Descargas de DownTV")
            .setMessage(message)
            .setItems(labels.toTypedArray()) { _, which ->
                openDownloadFile(files[which])
            }
            .setPositiveButton("OK", null)
            .setNeutralButton("Exportar ZIP") { _, _ ->
                exportDownloadsAsZip(folder)
            }
            .show()
    }

    private fun openDownloadFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeTypeForDownload(file))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newUri(contentResolver, file.name, uri)
            }
            startActivity(Intent.createChooser(intent, "Abrir archivo"))
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo abrir archivo descargado ${file.absolutePath}", error)
            showToast("No se pudo abrir este archivo")
        }
    }

    private fun exportDownloadsAsZip(folder: File) {
        Thread {
            try {
                val files = folder.walkTopDown().filter { it.isFile }.toList()
                if (files.isEmpty()) {
                    handler.post { showToast("No hay descargas para exportar") }
                    return@Thread
                }

                val exportDir = File(cacheDir, "exports").apply { mkdirs() }
                val zipFile = File(exportDir, "downtv-descargas.zip")
                ZipOutputStream(zipFile.outputStream().buffered()).use { zip ->
                    files.forEach { file ->
                        val entryName = file.relativeTo(folder).path.replace('\\', '/')
                        zip.putNextEntry(ZipEntry(entryName))
                        file.inputStream().buffered().use { input -> input.copyTo(zip) }
                        zip.closeEntry()
                    }
                }

                handler.post { shareDownloadZip(zipFile) }
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "No se pudo exportar descargas como ZIP", error)
                handler.post { showToast("No se pudo exportar el ZIP") }
            }
        }.apply {
            name = "KotaDownloadsZipExport"
            start()
        }
    }

    private fun shareDownloadZip(zipFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                zipFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newUri(contentResolver, zipFile.name, uri)
            }
            startActivity(Intent.createChooser(intent, "Compartir descargas"))
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo compartir ZIP ${zipFile.absolutePath}", error)
            showToast("ZIP creado, pero no se pudo compartir")
        }
    }

    private fun mimeTypeForDownload(file: File): String {
        return when (file.extension.lowercase()) {
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "ts", "m2ts" -> "video/mp2t"
            "wmv" -> "video/x-ms-wmv"
            "flv" -> "video/x-flv"
            "zip" -> "application/zip"
            "torrent" -> "application/x-bittorrent"
            else -> "application/octet-stream"
        }
    }
    
    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            bytes < 1024 * 1024 * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
            else -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
        }
    }

    private fun renderCatalogItems(filter: String) {
        if (!::catalogContent.isInitialized) return

        val keepViews = if (::searchBox.isInitialized && currentNavTab == NavTab.HOME) 3 else 1
        while (catalogContent.childCount > keepViews) catalogContent.removeViewAt(keepViews)
        refreshSearchHistoryUI()

        val cleanFilter = filter.trim().lowercase()
        val isSearchMode = cleanFilter.isNotBlank()
        Log.d(
            LOG_TAG,
            "Render HOME filter='$filter' loading=$catalogLoading items=${catalogItems.size} home=${homeCatalogItems.size} sportsLoading=$sportsLoading sports=${sportsMatches.size} mega=${megaSeriesList.size}"
        )

        if (!isSearchMode && catalogLoading && catalogItems.isEmpty()) {
            addHomeLiveSectionsWithoutImdb()
            addSectionTitle("Tendencias - IMDB")
            catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            Log.d(LOG_TAG, "Render HOME branch=loading-empty children=${catalogContent.childCount}")
            refreshCatalogLayout()
            return
        }

        if (isSearchMode && catalogSearchLoading && catalogItems === homeCatalogItems) {
            catalogContent.addView(emptyState("Loading..."))
            Log.d(LOG_TAG, "Render HOME branch=search-loading children=${catalogContent.childCount}")
            refreshCatalogLayout()
            return
        }

        // Si hay búsqueda activa y catalogItems ya son resultados remotos (? home),
        // no aplicar filtro local — los resultados ya vienen filtrados por la API.
        // Solo filtrar localmente cuando estamos en el catálogo home.
        val isShowingHomeItems = catalogItems === homeCatalogItems

        val filtered = if (!isSearchMode || !isShowingHomeItems) {
            // Búsqueda remota ya filtrada, o catálogo home sin búsqueda: mostrar todo
            if (isSearchMode && !isShowingHomeItems) {
                catalogItems // resultados remotos: no re-filtrar
            } else {
                catalogItems // home sin filtro
            }
        } else {
            // Filtro local sobre el catálogo home mientras llega la búsqueda remota
            catalogItems.filter { item ->
                listOf(item.title, item.originalTitle, item.year, item.imdbId, item.tmdbId, item.genres.joinToString(" "))
                    .joinToString(" ").lowercase().contains(cleanFilter)
            }
        }

        if (filtered.isEmpty()) {
            if (isSearchMode) {
                catalogContent.addView(emptyState(if (catalogSearchLoading) "Loading..." else "No hay resultados."))
                Log.d(LOG_TAG, "Render HOME branch=empty-search children=${catalogContent.childCount}")
            } else {
                addHomeLiveSectionsWithoutImdb()
                Log.d(LOG_TAG, "Render HOME branch=empty-home children=${catalogContent.childCount}")
            }
            refreshCatalogLayout()
            return
        }

        if (!isSearchMode) {
            // Vista home: continue watching + featured + rails + deportes + megadescargas

            // Seccion "Seguir viendo" — solo IMDB, NO deportes
            if (continueWatchingItems.isNotEmpty()) {
                addSectionTitle("Seguir viendo")
                catalogContent.addView(contentRail(continueWatchingItems), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            }

            // Deportes: API directa cuando está disponible; WebView limpio como respaldo.
            addSectionTitle("Deportes en directo")
            when {
                sportsLoading -> catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
                sportsMatches.isNotEmpty() -> catalogContent.addView(sportsRail(sportsMatches.take(24)), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
                else -> {
                    handler.postDelayed({ loadSportsMatches() }, 15_000L)
                    catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
                }
            }

            val featured = filtered.first()
            catalogContent.addView(
                featuredCard(featured),
                LinearLayout.LayoutParams(-1, if (isWideLayout()) dp(430) else dp(440)).apply { bottomMargin = dp(26) }
            )

            val featuredId = featured.id
            val trending = filtered.drop(1).filter { it.id != featuredId }.take(18)
            addSectionTitle("Tendencias — IMDB")
            catalogContent.addView(contentRail(trending), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })

            val series = catalogItems.filter { it.type.equals("series", ignoreCase = true) && it.id != featuredId }.take(16)
            if (series.isNotEmpty()) {
                addSectionTitle("Series — IMDB")
                catalogContent.addView(contentRail(series), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            }

            val movies = catalogItems.filter { it.type.equals("movie", ignoreCase = true) && it.id != featuredId }.drop(1).take(16)
            if (movies.isNotEmpty()) {
                addSectionTitle("Películas — IMDB")
                catalogContent.addView(contentRail(movies), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            }

            // Seccion Mega al final del HOME
            if (megaSeriesList.isNotEmpty()) {
                addSectionTitle("Series")
                catalogContent.addView(megaSeriesRail(megaSeriesList.take(20)), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            } else if (megaLoading) {
                addSectionTitle("Series")
                catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            }

            Log.d(LOG_TAG, "Render HOME branch=home children=${catalogContent.childCount}")
            logCatalogChildren("home")
            refreshCatalogLayout()

        } else {
            // Vista busqueda global: IMDB + deportes + Mega
            // Siempre mostramos las secciones con etiqueta, aunque esten vacias o cargando
            val imdbResults = filtered
            val megaResults = megaSeriesList.filter { s ->
                s.title.lowercase().contains(cleanFilter)
            }.take(8)

            var anyResult = false

            // IMDB — siempre mostrar la seccion aunque este cargando
            addSectionTitle("IMDB")
            when {
                imdbResults.isNotEmpty() -> {
                    addCatalogGrid(imdbResults)
                    anyResult = true
                }
                catalogLoading -> catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
                else -> catalogContent.addView(emptyState("Sin resultados en IMDB"), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
            }

            // Deportes — mostrar WebView embebido si hay busqueda de deporte
            val sportKeywords = listOf("futbol", "football", "basket", "tenis", "nba", "nfl", "ufc", "mma", "formula", "f1", "rugby", "cricket", "deporte", "sport", "liga", "champions", "premier")
            val isSportsSearch = sportKeywords.any { cleanFilter.contains(it) }
            if (isSportsSearch) {
                addSectionTitle("Deportes en directo")
                val searchUrl = "$STREAMED_BASE_URL/"
                val sportsWv = buildAntiDetectionWebView(searchUrl)
                catalogContent.addView(sportsWv, LinearLayout.LayoutParams(-1, dp(280)).apply { bottomMargin = dp(28) })
                anyResult = true
            }

            // Mega: mostrar si hay catalogo o esta cargando
            if (megaSeriesList.isNotEmpty() || megaLoading) {
                addSectionTitle("Series")
                when {
                    megaResults.isNotEmpty() -> {
                        catalogContent.addView(megaSeriesRail(megaResults), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
                        anyResult = true
                    }
                    megaLoading -> catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
                    else -> catalogContent.addView(emptyState("Sin series para \"$cleanFilter\""), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
                }
            }

            refreshCatalogLayout()
        }
    }

    private fun refreshCatalogLayout() {
        if (!::catalogContent.isInitialized) return
        fun kickLayout() {
            catalogContent.requestLayout()
            catalogContent.forceLayout()
            catalogContent.invalidate()
            if (::catalogScroll.isInitialized) {
                catalogScroll.requestLayout()
                catalogScroll.forceLayout()
                catalogScroll.invalidate()
                catalogScroll.scrollTo(0, 0)
            }
            rootView.requestLayout()
            rootView.invalidate()
        }
        kickLayout()
        catalogContent.post { kickLayout() }
        handler.postDelayed({
            if (currentScreen == Screen.CATALOG && ::catalogContent.isInitialized) {
                kickLayout()
            }
        }, 120L)
    }

    private fun logCatalogChildren(where: String) {
        if (!::catalogContent.isInitialized) return
        catalogContent.post {
            val pieces = mutableListOf<String>()
            for (i in 0 until catalogContent.childCount) {
                val child = catalogContent.getChildAt(i)
                val text = (child as? TextView)?.text?.toString()?.take(18).orEmpty()
                pieces += "$i:${child.javaClass.simpleName}:v=${child.visibility}:t=${child.top}:b=${child.bottom}:h=${child.height}:$text"
            }
            Log.d(LOG_TAG, "Catalog children $where -> ${pieces.joinToString(" | ")}")
        }
    }

    private fun addSectionTitle(label: String) {
        val sectionTitle = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            letterSpacing = 0.12f
            includeFontPadding = false
        }
        catalogContent.addView(sectionTitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun addHomeLiveSectionsWithoutImdb() {
        addSectionTitle("Deportes en directo")
        when {
            sportsLoading -> catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            sportsMatches.isNotEmpty() -> catalogContent.addView(sportsRail(sportsMatches.take(24)), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            else -> {
                handler.postDelayed({ loadSportsMatches() }, 3_000L)
                catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
            }
        }

        if (megaSeriesList.isNotEmpty()) {
            addSectionTitle("Series")
            catalogContent.addView(megaSeriesRail(megaSeriesList.take(20)), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
        } else if (megaLoading) {
            addSectionTitle("Series")
            catalogContent.addView(emptyState("Loading..."), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })
        }

    }

    private fun contentRail(items: List<CatalogItem>): View {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val tileWidth = if (isWideLayout()) dp(190) else dp(142)
        items.forEach { item ->
            row.addView(catalogCard(item), LinearLayout.LayoutParams(tileWidth, -2).apply { rightMargin = dp(14) })
        }
        scroll.addView(row, FrameLayout.LayoutParams(-2, -2))
        return scroll
    }

    private fun sportsRail(matches: List<SportMatch>): View {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tileWidth = if (isWideLayout()) dp(200) else dp(160)
        matches.forEach { match ->
            row.addView(sportCard(match), LinearLayout.LayoutParams(tileWidth, -2).apply { rightMargin = dp(14) })
        }
        scroll.addView(row, FrameLayout.LayoutParams(-2, -2))
        return scroll
    }

    private fun sportCard(match: SportMatch): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            setOnClickListener { playSportMatch(match) }
        }
        val posterFrame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xFF0D1117.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), if (match.isLive) Color.RED else Color.WHITE)
            }
        }
        // Badge LIVE o deporte
        val badge = TextView(this).apply {
            text = if (match.isLive) "\uD83D\uDD34 LIVE" else match.sport.uppercase().take(8)
            setTextColor(Color.WHITE)
            textSize = 10f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(6), dp(3), dp(6), dp(3))
            background = GradientDrawable().apply {
                setColor(if (match.isLive) Color.RED else 0xFF333333.toInt())
                cornerRadius = dp(4).toFloat()
            }
        }
        val sportIcon = TextView(this).apply {
            text = when (match.sport.lowercase()) {
                "football" -> "\uD83C\uDFC6"
                "basketball" -> "\uD83C\uDFC0"
                "tennis" -> "\uD83C\uDFBE"
                "baseball" -> "\u26BE"
                "hockey" -> "\uD83C\uDFD2"
                "mma", "boxing" -> "\uD83E\uDD4A"
                "motorsport" -> "\uD83C\uDFCE"
                "rugby" -> "\uD83C\uDFC9"
                "cricket" -> "\uD83C\uDFCF"
                else -> "\uD83C\uDFC6"
            }
            setTextColor(0xFFFFD700.toInt())
            textSize = 36f
            gravity = Gravity.CENTER
        }
        posterFrame.addView(sportIcon, FrameLayout.LayoutParams(-1, -1))
        posterFrame.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            topMargin = dp(6); leftMargin = dp(6)
        })
        val title = TextView(this).apply {
            text = match.title
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 2
            setPadding(0, dp(6), 0, 0)
        }
        val meta = TextView(this).apply {
            text = sportsGuideText(match).take(48)
            setTextColor(Color.WHITE)
            textSize = 10f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setPadding(0, dp(2), 0, 0)
        }
        card.addView(posterFrame, LinearLayout.LayoutParams(-1, if (isWideLayout()) dp(120) else dp(100)))
        card.addView(title)
        card.addView(meta)
        return card
    }

    private fun sportsGuideText(match: SportMatch): String {
        val delivery = if (match.sources.any { it.source == "iptv-org" || it.streamUrl.contains(".m3u8", ignoreCase = true) }) {
            "IPTV m3u8"
        } else {
            match.league
                .replace(Regex("""^(Fútbol|Futbol|Baloncesto)\s*[-/]\s*""", RegexOption.IGNORE_CASE), "")
                .ifBlank { "Directo" }
        }
        return delivery
    }

    private fun megaSeriesRail(series: List<com.kotatv.MegaSeries>): View {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tileWidth = if (isWideLayout()) dp(190) else dp(142)
        series.forEach { s ->
            row.addView(megaSeriesCard(s), LinearLayout.LayoutParams(tileWidth, -2).apply { rightMargin = dp(14) })
        }
        scroll.addView(row, FrameLayout.LayoutParams(-2, -2))
        return scroll
    }

    private fun megaSeriesCard(series: com.kotatv.MegaSeries): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnClickListener { showMegaSeriesSelector(series) }
            setOnLongClickListener {
                showMegaSeriesActions(series)
                true
            }
        }
        val posterFrame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xFF0D1117.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            clipToOutline = true
            setOnClickListener { showMegaSeriesSelector(series) }
            setOnLongClickListener {
                showMegaSeriesActions(series)
                true
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
            setOnClickListener { showMegaSeriesSelector(series) }
            setOnLongClickListener {
                showMegaSeriesActions(series)
                true
            }
        }
        // Cargar poster si está disponible, sino buscar en IMDB
        if (series.posterUrl.isNotBlank()) {
            loadPosterAsync(image, series.posterUrl)
        } else {
            loadMegaSeriesPosterAsync(image, series.title)
        }
        posterFrame.addView(image, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = series.title
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 2
            setPadding(0, dp(6), 0, 0)
        }
        card.addView(posterFrame, LinearLayout.LayoutParams(-1, if (isWideLayout()) dp(270) else dp(216)))
        card.addView(title)
        return card
    }

    private fun loadMegaSeriesPosterAsync(imageView: ImageView, title: String) {
        Thread {
            try {
                val slug = title.trim().lowercase()
                    .replace(Regex("[^a-z0-9]+"), "_").trim('_')
                if (slug.length < 2) return@Thread
                val json = fetchJson("$IMDB_SUGGESTION_BASE_URL/${slug.first()}/$slug.json")
                val arr = JSONObject(json).optJSONArray("d") ?: return@Thread
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val imgUrl = obj.optJSONObject("i")?.optString("imageUrl").orEmpty()
                    if (imgUrl.isNotBlank()) {
                        loadPosterAsync(imageView, imgUrl)
                        return@Thread
                    }
                }
            } catch (_: Throwable) {}
        }.start()
    }

    private fun playMegaSeriesTrailer(series: com.kotatv.MegaSeries) {
        val query = "${series.title} trailer"
        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            showToast("No se pudo abrir YouTube")
        }
    }

    private fun showMegaSeriesActions(series: com.kotatv.MegaSeries) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        container.addView(TextView(this).apply {
            text = series.title
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 2
            setPadding(0, 0, 0, dp(12))
        })
        container.addView(actionSheetButton("Ver trailer") {
            descriptionPopup?.dismiss()
            playMegaSeriesTrailer(series)
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        container.addView(actionSheetButton("Ver sinopsis") {
            descriptionPopup?.dismiss()
            showMegaSeriesDescription(series)
        }, LinearLayout.LayoutParams(-1, dp(44)))

        val width = if (isWideLayout()) dp(420) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        descriptionPopup = PopupWindow(container, width, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }
    }

    private fun showMegaSeriesDescription(series: com.kotatv.MegaSeries) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(24))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        val titleView = TextView(this).apply {
            text = series.title
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 3
        }
        val descView = TextView(this).apply {
            text = if (series.description.isNotBlank()) {
                series.description
            } else {
                "Serie disponible. Mantén pulsado para ver esta descripción. Toca para ver los episodios disponibles."
            }
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setLineSpacing(dp(4).toFloat(), 1f)
            setPadding(0, dp(10), 0, 0)
        }
        container.addView(titleView)
        container.addView(descView)

        // Buscar sinopsis en background si no hay descripción
        if (series.description.isBlank()) {
            Thread {
                try {
                    val slug = series.title.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
                    if (slug.length >= 2) {
                        val json = fetchJson("$IMDB_SUGGESTION_BASE_URL/${slug.first()}/$slug.json")
                        val arr = JSONObject(json).optJSONArray("d") ?: return@Thread
                        val imdbId = arr.optJSONObject(0)?.optString("id").orEmpty()
                        if (imdbId.startsWith("tt")) {
                            val meta = loadCinemetaMeta("series", imdbId)
                            if (meta != null && meta.overview.isNotBlank()) {
                                val desc = spanishDescriptionFor(meta)
                                handler.post { descView.text = desc }
                            }
                        }
                    }
                } catch (_: Throwable) {}
            }.start()
        }

        val scrollContainer = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(container, FrameLayout.LayoutParams(-1, -2))
        }
        val maxHeight = (resources.displayMetrics.heightPixels * 0.65).toInt()
        val width = if (isWideLayout()) dp(520) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        descriptionPopup = PopupWindow(scrollContainer, width, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            scrollContainer.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val measuredH = scrollContainer.measuredHeight
            if (measuredH > maxHeight) update(width, maxHeight)
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }
    }

    private fun grantTorrentRail(items: List<GrantTorrentItem>): View {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tileWidth = if (isWideLayout()) dp(190) else dp(142)
        items.forEach { item ->
            row.addView(grantTorrentCard(item), LinearLayout.LayoutParams(tileWidth, -2).apply { rightMargin = dp(14) })
        }
        scroll.addView(row, FrameLayout.LayoutParams(-2, -2))
        return scroll
    }

    private fun grantTorrentCard(item: GrantTorrentItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnClickListener { showGrantTorrentSelector(item) }
            setOnLongClickListener {
                showGrantTorrentActions(item)
                true
            }
        }
        val posterFrame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xFF0D1117.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            clipToOutline = true
            setOnClickListener { showGrantTorrentSelector(item) }
            setOnLongClickListener {
                showGrantTorrentActions(item)
                true
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
            setOnClickListener { showGrantTorrentSelector(item) }
            setOnLongClickListener {
                showGrantTorrentActions(item)
                true
            }
        }
        loadGrantTorrentPosterAsync(image, item.title)
        posterFrame.addView(image, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 11.5f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 3
            setPadding(0, dp(6), 0, 0)
        }
        val meta = TextView(this).apply {
            text = listOf(item.category, item.date).filter { it.isNotBlank() }.joinToString(" · ")
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 1
        }
        val quality = TextView(this).apply {
            text = item.quality.ifBlank { item.category }
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 1
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setPadding(0, dp(2), 0, 0)
        }
        card.addView(posterFrame, LinearLayout.LayoutParams(-1, if (isWideLayout()) dp(270) else dp(216)))
        card.addView(title)
        card.addView(meta)
        card.addView(quality)
        return card
    }

    private fun loadGrantTorrentPosterAsync(imageView: ImageView, title: String) {
        Thread {
            try {
                val slug = title.trim().lowercase()
                    .replace(Regex("[^a-z0-9]+"), "_").trim('_')
                if (slug.length < 2) return@Thread
                val json = fetchJson("$IMDB_SUGGESTION_BASE_URL/${slug.first()}/$slug.json")
                val arr = JSONObject(json).optJSONArray("d") ?: return@Thread
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val imgUrl = obj.optJSONObject("i")?.optString("imageUrl").orEmpty()
                    if (imgUrl.isNotBlank()) {
                        loadPosterAsync(imageView, imgUrl)
                        return@Thread
                    }
                }
            } catch (_: Throwable) {}
        }.start()
    }

    private fun playGrantTorrentTrailer(item: GrantTorrentItem) {
        val query = "${item.title} trailer"
        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            showToast("No se pudo abrir YouTube")
        }
    }

    private fun showGrantTorrentActions(item: GrantTorrentItem) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        container.addView(TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 2
            setPadding(0, 0, 0, dp(12))
        })
        container.addView(actionSheetButton("Ver trailer") {
            descriptionPopup?.dismiss()
            playGrantTorrentTrailer(item)
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        container.addView(actionSheetButton("Ver sinopsis") {
            descriptionPopup?.dismiss()
            showGrantTorrentDescription(item)
        }, LinearLayout.LayoutParams(-1, dp(44)))

        val width = if (isWideLayout()) dp(420) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        descriptionPopup = PopupWindow(container, width, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }
    }

    private fun showGrantTorrentDescription(item: GrantTorrentItem) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(24))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        val titleView = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 3
        }
        val metaView = TextView(this).apply {
            text = listOf(item.category, item.quality, item.date).filter { it.isNotBlank() }.joinToString(" · ")
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setPadding(0, dp(6), 0, dp(10))
        }
        val descView = TextView(this).apply {
            text = "Loading..."
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        container.addView(titleView)
        container.addView(metaView)
        container.addView(descView)

        Thread {
            try {
                val type = if (item.category.equals("Serie", ignoreCase = true)) "series" else "movie"
                val slug = item.title.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
                if (slug.length >= 2) {
                    val json = fetchJson("$IMDB_SUGGESTION_BASE_URL/${slug.first()}/$slug.json")
                    val arr = JSONObject(json).optJSONArray("d") ?: return@Thread
                    val imdbId = arr.optJSONObject(0)?.optString("id").orEmpty()
                    if (imdbId.startsWith("tt")) {
                        val meta = loadCinemetaMeta(type, imdbId)
                        if (meta != null && meta.overview.isNotBlank()) {
                            val desc = spanishDescriptionFor(meta)
                            handler.post { descView.text = desc }
                            return@Thread
                        }
                    }
                }
                handler.post { descView.text = "Sin sinopsis disponible." }
            } catch (_: Throwable) {
                handler.post { descView.text = "Sin sinopsis disponible." }
            }
        }.start()

        val scrollContainer = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(container, FrameLayout.LayoutParams(-1, -2))
        }
        val maxHeight = (resources.displayMetrics.heightPixels * 0.65).toInt()
        val width = if (isWideLayout()) dp(520) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        descriptionPopup = PopupWindow(scrollContainer, width, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            scrollContainer.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val measuredH = scrollContainer.measuredHeight
            if (measuredH > maxHeight) update(width, maxHeight)
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }
    }

    private fun addCatalogGrid(items: List<CatalogItem>) {
        val columns = if (isWideLayout()) 4 else 2
        items.chunked(columns).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEachIndexed { index, item ->
                row.addView(catalogCard(item), LinearLayout.LayoutParams(0, -2, 1f).apply {
                    if (index > 0) leftMargin = dp(10)
                })
            }
            repeat(columns - rowItems.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { leftMargin = dp(10) })
            }
            catalogContent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        }
    }

    private fun featuredCard(item: CatalogItem): View {
        val card = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.BLACK)).apply {
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            elevation = dp(8).toFloat()
            setOnClickListener { playItem(item) }
            setOnLongClickListener {
                showCatalogItemActions(item)
                true
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.82f
            setBackgroundColor(Color.BLACK)
            setOnClickListener { playItem(item) }
            setOnLongClickListener {
                showCatalogItemActions(item)
                true
            }
        }
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(color("#00000000"), color("#EE000000")))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(20), 0, dp(20), dp(22))
        }
        val title = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = if (isWideLayout()) 32f else 28f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 2
            includeFontPadding = false
        }
        val meta = TextView(this).apply {
            text = itemMetaText(item, includeGenres = true)
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setPadding(0, dp(8), 0, 0)
        }
        val play = TextView(this).apply {
            text = "▶"
            gravity = Gravity.CENTER
            textSize = 16f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            setOnClickListener { playItem(item) }
        }
        content.addView(title)
        content.addView(meta)
        content.addView(play, LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(16) })
        card.addView(image, FrameLayout.LayoutParams(-1, -1))
        card.addView(shade, FrameLayout.LayoutParams(-1, -1))
        card.addView(content, FrameLayout.LayoutParams(-1, -1))
        loadHeroBackdropAsync(image, item)
        return card
    }

    private fun catalogCard(item: CatalogItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            setOnClickListener { playItem(item) }
            setOnLongClickListener {
                showCatalogItemActions(item)
                true
            }
        }

        val posterFrame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.BLACK)).apply {
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
            clipToOutline = false
            setOnClickListener { playItem(item) }
            setOnLongClickListener {
                showCatalogItemActions(item)
                true
            }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
            setOnClickListener { playItem(item) }
            setOnLongClickListener {
                showCatalogItemActions(item)
                true
            }
        }
        posterFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
        if (item.posterUrl.isNotBlank()) loadPosterAsync(image, item.posterUrl)

        val title = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 12.5f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            maxLines = 2
            includeFontPadding = false
            setPadding(0, dp(8), 0, 0)
        }
        val meta = TextView(this).apply {
            text = itemMetaText(item, includeGenres = false)
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setPadding(0, dp(4), 0, 0)
        }

        card.addView(posterFrame, LinearLayout.LayoutParams(-1, if (isWideLayout()) dp(270) else dp(216)))
        card.addView(title)
        card.addView(meta)
        return card
    }

    private fun showCatalogItemActions(item: CatalogItem) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        container.addView(TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 2
            setPadding(0, 0, 0, dp(12))
        })
        container.addView(actionSheetButton("Ver trailer") {
            descriptionPopup?.dismiss()
            playTrailer(item)
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        container.addView(actionSheetButton("Ver sinopsis") {
            descriptionPopup?.dismiss()
            showDescriptionSheet(item)
        }, LinearLayout.LayoutParams(-1, dp(44)))

        val width = if (isWideLayout()) dp(420) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        descriptionPopup = PopupWindow(container, width, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }
    }

    private fun actionSheetButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.BLACK)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener { onClick() }
        }
    }

    private fun showDescriptionSheet(item: CatalogItem) {
        descriptionPopup?.dismiss()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(24))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        val titleView = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            includeFontPadding = false
            maxLines = 3
        }
        val meta = TextView(this).apply {
            text = itemMetaText(item, includeGenres = true)
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setPadding(0, dp(6), 0, dp(10))
        }
        val description = TextView(this).apply {
            text = cachedSpanishDescription(item)
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            setLineSpacing(dp(4).toFloat(), 1f)
            isSingleLine = false
            maxLines = Int.MAX_VALUE
        }
        container.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        container.addView(meta, LinearLayout.LayoutParams(-1, -2))
        container.addView(description, LinearLayout.LayoutParams(-1, -2))

        // ScrollView para que la descripción larga no quede cortada
        val scrollContainer = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(container, FrameLayout.LayoutParams(-1, -2))
        }

        val maxHeight = (resources.displayMetrics.heightPixels * 0.65).toInt()
        val width = if (isWideLayout()) dp(520) else (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(280))
        scrollContainer.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val popupHeight = scrollContainer.measuredHeight.takeIf { it > 0 }?.coerceAtMost(maxHeight)
            ?: ViewGroup.LayoutParams.WRAP_CONTENT
        descriptionPopup = PopupWindow(scrollContainer, width, popupHeight, true).apply {
            elevation = dp(20).toFloat()
            isOutsideTouchable = true
            showAtLocation(rootView, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(24))
        }

        if (!translatedDescriptionCache.containsKey(item.id)) {
            Thread {
                val translated = spanishDescriptionFor(item)
                handler.post {
                    if (descriptionPopup?.contentView == scrollContainer) {
                        description.text = translated
                    }
                }
            }.start()
        }
    }

    private fun cachedSpanishDescription(item: CatalogItem): String {
        translatedDescriptionCache[item.id]?.let { return it }
        return if (item.overview.isBlank()) "Sin sinopsis disponible en español." else item.overview
    }

    private fun spanishDescriptionFor(item: CatalogItem): String {
        translatedDescriptionCache[item.id]?.let { return it }
        val original = item.overview.trim()
        
        // Si está vacío, devolver mensaje
        if (original.isBlank()) {
            val result = "Sin sinopsis disponible."
            translatedDescriptionCache[item.id] = result
            return result
        }
        
        // Si ya está en español, devolverlo tal cual
        if (looksSpanish(original)) {
            translatedDescriptionCache[item.id] = original
            return original
        }
        
        // Si no está en español, intentar traducir
        val translated = translateToSpanish(original)
        
        // Si la traducción falla o está vacía, devolver el original (idioma original)
        val result = if (translated.isBlank()) original else translated
        translatedDescriptionCache[item.id] = result
        return result
    }

    private fun translateToSpanish(text: String): String {
        return try {
            val url = Uri.parse(GOOGLE_TRANSLATE_BASE_URL).buildUpon()
                .appendQueryParameter("client", "gtx")
                .appendQueryParameter("sl", "auto")
                .appendQueryParameter("tl", "es")
                .appendQueryParameter("dt", "t")
                .appendQueryParameter("q", text)
                .build()
                .toString()
            val body = fetchText(url, "application/json")
            val root = JSONArray(body)
            val sentences = root.optJSONArray(0) ?: return ""
            buildString {
                for (i in 0 until sentences.length()) {
                    val part = sentences.optJSONArray(i)?.optString(0).orEmpty()
                    if (part.isNotBlank()) append(part)
                }
            }.trim()
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo traducir descripcion", error)
            ""
        }
    }

    private fun looksSpanish(text: String): Boolean {
        val clean = text.lowercase()
        val hits = listOf(" el ", " la ", " los ", " las ", " de ", " que ", " una ", " para ", " con ", " por ")
            .count { clean.contains(it) }
        return hits >= 3 || clean.any { it in "áéíóúñ¿¡" }
    }

    private fun itemMetaText(item: CatalogItem, includeGenres: Boolean): String {
        return listOf(
            item.year,
            if (includeGenres) item.genres.take(2).joinToString(" / ") { genreLabel(it) } else "",
            if (item.rating.isNotBlank()) "IMDb ${item.rating}" else ""
        )
            .filter { it.isNotBlank() }
            .joinToString("  ")
    }

    private fun genreLabel(genre: String): String {
        return when (genre.lowercase()) {
            "action" -> "Acción"
            "adventure" -> "Aventura"
            "animation" -> "Animación"
            "biography" -> "Biografía"
            "comedy" -> "Comedia"
            "crime" -> "Crimen"
            "documentary" -> "Documental"
            "drama" -> "Drama"
            "family" -> "Familiar"
            "fantasy" -> "Fantasía"
            "history" -> "Historia"
            "horror" -> "Terror"
            "music" -> "Música"
            "mystery" -> "Misterio"
            "romance" -> "Romance"
            "sci-fi", "science fiction" -> "Ciencia ficción"
            "thriller" -> "Suspense"
            "war" -> "Bélica"
            "western" -> "Western"
            else -> genre
        }
    }

    private fun playItem(item: CatalogItem) {
        // Si es una serie, mostrar selector de temporada/episodio
        if (item.type.equals("series", ignoreCase = true)) {
            showEpisodeSelector(item)
            return
        }

        playItemWithSeasonEpisode(item, season = 1, episode = 1)
    }
    
    private fun playTrailer(item: CatalogItem) {
        // Construir URL de búsqueda de YouTube directamente
        val searchQuery = "${item.title} ${item.year} trailer"
        val youtubeSearchUrl = "https://www.youtube.com/results?search_query=${Uri.encode(searchQuery)}"
        
        // Abrir búsqueda de YouTube en el navegador del sistema
        try {
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(youtubeSearchUrl))
            startActivity(intent)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "No se pudo abrir YouTube", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun showEpisodeSelector(item: CatalogItem) {
        // Obtener información real de temporadas/episodios desde Cinemeta
        Thread {
            try {
                val json = fetchJson("$CINEMETA_BASE_URL/meta/${item.type}/${item.imdbId}.json")
                val meta = JSONObject(json).optJSONObject("meta")
                val videos = meta?.optJSONArray("videos")
                
                // Calcular número de temporadas y episodios
                var maxSeason = 1
                val episodesPerSeason = mutableMapOf<Int, Int>()
                
                if (videos != null) {
                    for (i in 0 until videos.length()) {
                        val video = videos.optJSONObject(i)
                        val season = video?.optInt("season", 1) ?: 1
                        val episode = video?.optInt("episode", 1) ?: 1
                        
                        if (season > maxSeason) maxSeason = season
                        
                        val currentMax = episodesPerSeason[season] ?: 0
                        if (episode > currentMax) {
                            episodesPerSeason[season] = episode
                        }
                    }
                }
                
                // Si no hay datos, usar valores por defecto
                if (maxSeason == 0) maxSeason = 10
                if (episodesPerSeason.isEmpty()) {
                    for (s in 1..maxSeason) {
                        episodesPerSeason[s] = 20
                    }
                }
                
                handler.post {
                    showEpisodeSelectorDialog(item, maxSeason, episodesPerSeason)
                }
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Error obteniendo info de serie: ${e.message}")
                // Fallback a valores por defecto
                handler.post {
                    val defaultEpisodes = mutableMapOf<Int, Int>()
                    for (s in 1..10) defaultEpisodes[s] = 20
                    showEpisodeSelectorDialog(item, 10, defaultEpisodes)
                }
            }
        }.start()
    }
    
    private fun showEpisodeSelectorDialog(item: CatalogItem, maxSeasons: Int, episodesPerSeason: Map<Int, Int>) {
        val dialog = android.app.AlertDialog.Builder(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }
        
        val title = TextView(this).apply {
            text = "Seleccionar episodio"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(16))
        }
        container.addView(title)
        
        // Selector de temporada
        val seasonLabel = TextView(this).apply {
            text = "Temporada"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(8))
        }
        container.addView(seasonLabel)
        
        val seasonPicker = android.widget.NumberPicker(this).apply {
            minValue = 1
            maxValue = maxSeasons.coerceAtLeast(1)
            value = 1
            wrapSelectorWheel = false
        }
        container.addView(seasonPicker)
        
        // Selector de episodio
        val episodeLabel = TextView(this).apply {
            text = "Episodio"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(0, dp(16), 0, dp(8))
        }
        container.addView(episodeLabel)
        
        val episodePicker = android.widget.NumberPicker(this).apply {
            minValue = 1
            maxValue = episodesPerSeason[1] ?: 20
            value = 1
            wrapSelectorWheel = false
        }
        container.addView(episodePicker)
        
        // Actualizar episodios cuando cambia la temporada
        seasonPicker.setOnValueChangedListener { _, _, newSeason ->
            val maxEpisodes = episodesPerSeason[newSeason] ?: 20
            episodePicker.maxValue = maxEpisodes
            if (episodePicker.value > maxEpisodes) {
                episodePicker.value = maxEpisodes
            }
        }
        
        dialog.setView(container)
        dialog.setPositiveButton("Reproducir") { _, _ ->
            val season = seasonPicker.value
            val episode = episodePicker.value
            playItemWithSeasonEpisode(item, season, episode)
        }
        dialog.setNegativeButton("Cancelar", null)
        dialog.show()
    }

    private fun playItemWithSeasonEpisode(item: CatalogItem, season: Int, episode: Int) {
        Log.d(LOG_TAG, "?? playItemWithSeasonEpisode - autoHostSelection: $autoHostSelection, selectedHostIndex: $selectedHostIndex, selectedHost: ${selectedHost.displayName} (${selectedHost.key})")
        Log.d(LOG_TAG, "Buscando torrents en castellano para reproducir con libtorrent + VLC")
        searchAndShowTorrentOptions(item, season, episode)
        return
        
        // Intentar encontrar embed directo primero
        val embedUrl = findEmbedForHost(item, selectedHost, season, episode)
        
        if (embedUrl.isNotBlank()) {
            // Hay embed directo, reproducir normalmente
            Log.d(LOG_TAG, "?? Embed directo encontrado: $embedUrl")
            showPlayer(item, embedUrl, selectedHost)
            loadExternalSpanishSubtitles(item, season, episode)
            
            // Añadir a "Seguir viendo" cuando empiece a reproducir
            addToContinueWatching(item)
            
            // Si el usuario ha seleccionado manualmente un host, NO buscar alternativas
            if (!autoHostSelection) {
                Log.d(LOG_TAG, "? Manual host selection active - NOT searching for alternatives")
                return
            }

            // Solo en modo automático: resolver el mejor host en background
            Thread {
                Log.d(LOG_TAG, "?? Auto mode: searching for best host...")
                val choice = findPlaybackChoice(item, season, episode) ?: return@Thread
                handler.post {
                    val newHostIndex = PLAYBACK_HOSTS.indexOf(choice.host).coerceAtLeast(0)
                    Log.d(LOG_TAG, "?? Best host found: ${choice.host.displayName} (score: ${choice.castellanoScore})")
                    if (choice.url != embedUrl || newHostIndex != selectedHostIndex) {
                        selectedHostIndex = newHostIndex
                        if (currentScreen == Screen.PLAYER) {
                            Log.d(LOG_TAG, "?? Switching to better host: ${choice.host.displayName}")
                            playbackWebView?.loadUrl(choice.url, mapOf("Accept-Language" to "es-ES,es;q=0.9"))
                        }
                    }
                }
            }.start()
        } else {
            // No hay embed directo, buscar en Torrentio
            Log.d(LOG_TAG, "?? No hay embed directo, buscando en Torrentio...")
            searchAndShowTorrentOptions(item, season, episode)
        }
    }
    
    private fun searchAndShowTorrentOptions(item: CatalogItem, season: Int, episode: Int) {
        val imdbId = item.imdbId.trim()
        if (imdbId.isBlank()) {
            showToast("No se puede buscar streams: ID inválido")
            return
        }
        
        // Mostrar diálogo de carga
        val loadingDialog = android.app.AlertDialog.Builder(this)
            .setTitle("Buscando streams")
            .setMessage("Consultando Torrentio...")
            .setCancelable(false)
            .create()
        loadingDialog.show()
        
        // Buscar en Torrentio
        Thread {
            try {
                val type = if (item.type.equals("series", ignoreCase = true)) "series" else "movie"
                val streams = StremioAddons.getStreamsFromTorrentio(
                    type = type,
                    imdbId = imdbId,
                    season = if (type == "series") season else null,
                    episode = if (type == "series") episode else null
                )
                
                Log.d(LOG_TAG, "?? Torrentio: ${streams.size} streams encontrados")
                
                handler.post {
                    loadingDialog.dismiss()
                    
                    if (streams.isEmpty()) {
                        // Mostrar diálogo con opciones alternativas en lugar de solo un toast
                        android.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Sin streams disponibles")
                            .setMessage("Torrentio no encontró streams para este contenido ahora mismo.\n\nPuede que:\n• El contenido sea muy reciente\n• No haya seeders activos\n• El ID de IMDB no coincida\n\n¿Qué quieres hacer?")
                            .setPositiveButton("Reintentar") { _, _ ->
                                searchAndShowTorrentOptions(item, season, episode)
                            }
                            .setNegativeButton("Cancelar", null)
                            .show()
                        return@post
                    }
                    
                    // Mostrar diálogo con opciones
                    showTorrentSelectionDialog(streams, item)
                }
            } catch (e: Exception) {
                Log.e(LOG_TAG, "? Error buscando streams: ${e.message}", e)
                handler.post {
                    loadingDialog.dismiss()
                    showToast("Error: ${e.message}")
                }
            }
        }.start()
    }

    private fun findEmbedForSelectedHost(item: CatalogItem, season: Int = 1, episode: Int = 1): String {
        return findEmbedForHost(item, selectedHost, season, episode)
    }

    private fun findEmbedForHost(item: CatalogItem, host: PlaybackHost, season: Int = 1, episode: Int = 1): String {
        item.embeds[host.key]?.let { if (it.isNotBlank()) return it }
        host.labelAliases.forEach { alias ->
            item.embeds[alias]?.let { if (it.isNotBlank()) return it }
        }
        host.hostAliases.forEach { alias ->
            item.embeds[alias.removePrefix("www.")]?.let { if (it.isNotBlank()) return it }
        }
        // No hay embed directo, retornar vacío
        return ""
    }

    private fun findPlaybackChoice(item: CatalogItem, season: Int = 1, episode: Int = 1): PlaybackChoice? {
        // Siempre se prueban todos los hosts. Si hay uno seleccionado manualmente
        // se le da prioridad poniéndolo primero, pero si no tiene contenido o su
        // score es 0 se sigue buscando el mejor disponible.
        val orderedHosts = if (autoHostSelection) {
            PLAYBACK_HOSTS
        } else {
            listOf(selectedHost) + PLAYBACK_HOSTS.filter { it != selectedHost }
        }

        var bestChoice: PlaybackChoice? = null

        for (host in orderedHosts) {
            val embed = normalizeEmbedUrl(findEmbedForHost(item, host, season, episode))
            if (embed.isBlank() || !embed.startsWith("https://")) continue
            val choice = resolvePlaybackChoice(host, embed) ?: continue

            // Si el host manual tiene contenido (score >= 0) lo usamos directamente
            // solo si no estamos en auto y es el primero de la lista
            if (!autoHostSelection && host == selectedHost && choice.castellanoScore >= 0) {
                return choice
            }

            if (bestChoice == null || choice.castellanoScore > bestChoice.castellanoScore) {
                bestChoice = choice
            }

            // Score alto: castellano confirmado, no hace falta seguir buscando
            if (choice.castellanoScore >= 4) return choice
        }

        return bestChoice
    }

    
    private data class TorrentWebCompatibility(
        val score: Int,
        val label: String,
        val isPlayable: Boolean
    )

    /**
     * Detecta el idioma de un stream de Torrentio a partir de su título.
     * Torrentio suele incluir banderas y/o texto en las líneas secundarias.
     */
    private fun torrentLanguageInfo(stream: StremioStream): Pair<String, Int> {
        val title = (stream.title ?: stream.name ?: "").lowercase()
        val lines = title.split("\n")
        val langLine = lines.drop(1).joinToString(" ")

        val spainFlag = "\uD83C\uDDEA\uD83C\uDDF8"
        val latamFlags = listOf(
            "\uD83C\uDDF2\uD83C\uDDFD",
            "\uD83C\uDDE6\uD83C\uDDF7",
            "\uD83C\uDDE8\uD83C\uDDF4",
            "\uD83C\uDDE8\uD83C\uDDF1",
            "\uD83C\uDDF5\uD83C\uDDEA",
            "\uD83C\uDDFB\uD83C\uDDEA"
        )
        val englishFlags = listOf(
            "\uD83C\uDDFA\uD83C\uDDF8",
            "\uD83C\uDDEC\uD83C\uDDE7"
        )
        val hasSpainFlag = title.contains(spainFlag) || langLine.contains(spainFlag)
        val hasLatamFlag = latamFlags.any { title.contains(it) || langLine.contains(it) }
        val hasEnglishFlag = englishFlags.any { title.contains(it) || langLine.contains(it) }

        // Palabras clave en el texto
        val hasCastellano  = listOf("castellano", "español", "espanol", "spa", "es-es", "es_es").any { title.contains(it) }
        val hasLatino      = listOf("latino", "latin", "es-419", "es-mx", "es-lat").any { title.contains(it) }
        val hasSpanish     = listOf("spanish", " es ", "[es]", "(es)").any { title.contains(it) }

        val label = buildString {
            when {
                hasSpainFlag && hasCastellano -> append("Castellano")
                hasSpainFlag                  -> append("Español")
                hasCastellano                 -> append("Castellano")
                hasLatamFlag && hasLatino     -> append("Latino")
                hasLatamFlag                  -> append("Lat/Esp")
                hasLatino                     -> append("Latino")
                hasSpanish                    -> append("Español")
                hasEnglishFlag                -> append("Inglés")
                else                          -> append("Idioma sin confirmar")
            }
            // Añadir inglés si también lo tiene
            if ((hasSpainFlag || hasCastellano || hasLatino || hasSpanish) && hasEnglishFlag) {
                append(" + Inglés")
            }
        }

        val score = when {
            hasSpainFlag && hasCastellano -> 100   // Castellano confirmado con bandera
            hasCastellano                 -> 90    // Castellano por texto
            hasSpainFlag                  -> 80    // Bandera española (probable castellano)
            hasSpanish                    -> 60    // "Spanish" genérico
            hasLatamFlag && hasLatino     -> 30    // Latino explícito
            hasLatamFlag                  -> 20    // Bandera latinoamericana
            hasLatino                     -> 25    // Latino por texto
            hasEnglishFlag                -> -10   // Solo inglés
            else                          -> 0     // Sin info
        }

        return label to score
    }

    private fun torrentWebCompatibility(stream: StremioStream, title: String): TorrentWebCompatibility {
        val text = listOf(
            title,
            stream.name.orEmpty(),
            stream.behaviorHints?.bingeGroup.orEmpty()
        ).joinToString(" ").lowercase()

        val unsupportedContainer = listOf(
            ".avi", " avi ", ".mkv", " mkv ", "matroska", ".wmv", " wmv ",
            ".flv", " flv ", ".mov", " mov ", ".ts", " m2ts "
        ).any { text.contains(it) }
        val unsupportedCodec = listOf("xvid", "divx", "mpeg-2", "mpeg2").any { text.contains(it) }
        val externalOnlyCodec = listOf(
            "h.265", "h265", "x265", "hevc", "av1", "dts", "ac3", "e-ac3", "eac3", "truehd"
        ).any { text.contains(it) }

        if (unsupportedContainer || unsupportedCodec || stream.behaviorHints?.notWebReady == true) {
            return TorrentWebCompatibility(
                score = -100,
                label = "VLC interno",
                isPlayable = false
            )
        }

        if (externalOnlyCodec) {
            return TorrentWebCompatibility(
                score = -50,
                label = "mejor con VLC interno",
                isPlayable = false
            )
        }

        return when {
            listOf(".mp4", " mp4 ", ".m4v", " m4v ").any { text.contains(it) } ->
                TorrentWebCompatibility(100, "MP4", true)
            listOf(".webm", " webm ").any { text.contains(it) } ->
                TorrentWebCompatibility(90, "WebM", true)
            listOf("h.264", "h264", "x264", "avc").any { text.contains(it) } ->
                TorrentWebCompatibility(40, "H.264 probable", true)
            else ->
                TorrentWebCompatibility(10, "compatibilidad sin confirmar", true)
        }
    }

    private fun torrentQualityScore(quality: String): Int {
        return when (quality) {
            "4K" -> 4
            "1080p" -> 3
            "720p" -> 2
            "480p" -> 1
            else -> 0
        }
    }

    private fun showTorrentSelectionDialog(streams: List<Pair<String, StremioStream>>, item: CatalogItem) {
        // Filtrar solo torrents
        val torrents = streams.filter { (_, stream) ->
            stream.infoHash != null || (stream.url != null && stream.url.startsWith("magnet:"))
        }

        if (torrents.isEmpty()) {
            showToast("No hay torrents disponibles")
            return
        }

        // Parsear información de cada torrent
        data class TorrentInfo(
            val displayText: String,
            val quality: String,
            val size: String,
            val seeders: String,
            val tracker: String,
            val addon: String,
            val stream: StremioStream,
            val seederCount: Int,
            val compatibility: TorrentWebCompatibility,
            val languageLabel: String,
            val languageScore: Int
        )

        val rawTorrentInfos = torrents.map { (addon, stream) ->
            val title = stream.title ?: stream.name ?: "Torrent"

            // Parsear información del título de Torrentio
            // Formato típico: "Título\n?? seeders ?? size ?? tracker\n???? / ????"
            val lines = title.split("\n")
            val mainTitle = lines.getOrNull(0) ?: "Torrent"
            val infoLine = lines.getOrNull(1) ?: ""

            // Extraer calidad del título principal (4K, 1080p, 720p, etc.)
            val quality = when {
                mainTitle.contains("4K", ignoreCase = true) || mainTitle.contains("2160p", ignoreCase = true) -> "4K"
                mainTitle.contains("1080p", ignoreCase = true) -> "1080p"
                mainTitle.contains("720p", ignoreCase = true) -> "720p"
                mainTitle.contains("480p", ignoreCase = true) -> "480p"
                else -> "SD"
            }

            val sizeMatch = Regex("""(?i)\b(\d+(?:[.,]\d+)?)\s*([GM]B)\b""").find(infoLine)
                ?: Regex("""(?i)\b(\d+(?:[.,]\d+)?)\s*([GM]B)\b""").find(title)
            val size = sizeMatch
                ?.let { "${it.groupValues[1].replace(',', '.')} ${it.groupValues[2].uppercase()}" }
                ?: "?"

            val infoWithoutSize = sizeMatch?.let { infoLine.replace(it.value, " ") } ?: infoLine
            val seeders = listOf(
                Regex("""(?i)\b(?:seeders?|seeds?)\D{0,12}(\d{1,6})\b""").find(title)?.groupValues?.getOrNull(1),
                Regex("""(?i)\b(\d{1,6})\s*(?:seeders?|seeds?)\b""").find(title)?.groupValues?.getOrNull(1),
                Regex("""\b(\d{1,6})\b""").find(infoWithoutSize)?.groupValues?.getOrNull(1)
            ).firstOrNull { !it.isNullOrBlank() } ?: "?"
            val seederCount = seeders.toIntOrNull() ?: -1
            val tracker = infoLine
                .replace(sizeMatch?.value.orEmpty(), " ")
                .replace(Regex("""(?i)\b(?:seeders?|seeds?)\b"""), " ")
                .replace(Regex("""\b\d{1,6}\b"""), " ")
                .replace(Regex("""\s+"""), " ")
                .trim()
                .ifBlank { "Torrentio" }
            val compatibility = torrentWebCompatibility(stream, title)
            val (languageLabel, languageScore) = torrentLanguageInfo(stream)

            // Crear texto para mostrar — idioma siempre visible al inicio
            val displayText = buildString {
                append(languageLabel)
                append("  ")
                append(quality)
                if (mainTitle.contains("HDR", ignoreCase = true)) append(" HDR")
                if (mainTitle.contains("BluRay", ignoreCase = true)) append(" BluRay")
                else if (mainTitle.contains("WEB", ignoreCase = true)) append(" WEB")
                append(" • ")
                append(size)
                append(" • ")
                append("Seeders $seeders")
                append(" • ")
                append(compatibility.label)
            }

            TorrentInfo(
                displayText = displayText,
                quality = quality,
                size = size,
                seeders = seeders,
                tracker = tracker,
                addon = addon,
                stream = stream,
                seederCount = seederCount,
                compatibility = compatibility,
                languageLabel = languageLabel,
                languageScore = languageScore
            )
        }

        // Ordenar: castellano de España primero, luego compatibilidad con VLC, seeders y calidad.
        val torrentInfos = rawTorrentInfos
            .sortedWith(
                compareByDescending<TorrentInfo> { it.languageScore }
                    .thenByDescending { it.compatibility.score }
                    .thenByDescending { it.seederCount }
                    .thenByDescending { torrentQualityScore(it.quality) }
            )

        // Crear array de opciones para el diálogo
        val options = torrentInfos.map { it.displayText }.toTypedArray()

        // Título del diálogo con info de castellano disponible
        val spanishCount = torrentInfos.count { it.languageScore > 0 }
        val dialogTitle = when {
            spanishCount > 0 ->
                "Torrents ($spanishCount en castellano/español)"
            else ->
                "Torrents"
        }

        // Mostrar diálogo de selección
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(dialogTitle)
            .setItems(options) { _, which ->
                val info = torrentInfos[which]
                startTorrentDownload(info.addon, info.stream, item, info.quality, info.size, info.seeders, useVlcPlayer = true)
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }

    private fun startTorrentDownload(
        addon: String, 
        stream: StremioStream, 
        item: CatalogItem,
        quality: String,
        size: String,
        seeders: String,
        useVlcPlayer: Boolean = true
    ) {
        val magnetUri = stream.url ?: "magnet:?xt=urn:btih:${stream.infoHash}"
        val fileIdx = stream.fileIdx
        
        Log.d(LOG_TAG, "?? Iniciando descarga de torrent desde $addon")
        Log.d(LOG_TAG, "?? Calidad: $quality | Tamaño: $size | Seeders: $seeders")
        Log.d(LOG_TAG, "?? InfoHash: ${stream.infoHash}")
        Log.d(LOG_TAG, "?? FileIdx: $fileIdx")
        
        // Advertir si hay pocos seeders
        val seederCount = seeders.toIntOrNull() ?: -1
        if (seederCount in 0 until 5) {
            val warningDialog = android.app.AlertDialog.Builder(this)
                .setTitle("Pocos seeders")
                .setMessage("Este torrent tiene solo $seeders seeders. Puede tardar mucho o no funcionar.\n\n¿Continuar de todos modos?")
                .setPositiveButton("Continuar") { _, _ ->
                    proceedWithTorrentDownload(addon, magnetUri, fileIdx, quality, size, seeders, item, useVlcPlayer)
                }
                .setNegativeButton("Cancelar", null)
                .create()
            warningDialog.show()
        } else {
            proceedWithTorrentDownload(addon, magnetUri, fileIdx, quality, size, seeders, item, useVlcPlayer)
        }
    }
    
    private fun proceedWithTorrentDownload(
        addon: String,
        magnetUri: String,
        fileIdx: Int?,
        quality: String,
        size: String,
        seeders: String,
        item: CatalogItem,
        useVlcPlayer: Boolean = true
    ) {
        showToast(
            if (useVlcPlayer) {
                "Preparando VLC: $quality ($size)"
            } else {
                "Descargando $quality ($size) - $seeders seeders"
            }
        )
        currentTorrentVideoUrl = null
        
        // Mostrar player nativo con notificación de descarga.
        if (useVlcPlayer) {
            showTorrentPlayerShell(item)
        } else {
            showPlayer(item, "", selectedHost)
        }
        showTorrentDownloadNotification()
        
        // Iniciar streaming de torrent
        torrentStreamManager?.stopStreaming()
        val torrentManager = TorrentStreamManager(this@MainActivity)
        torrentStreamManager = torrentManager
        
        // Iniciar actualizador de progreso
        startProgressUpdater(torrentManager)
        
        torrentManager.startStreaming(
            magnetUri,
            fileIdx,
            requireWebViewCompatible = !useVlcPlayer
        ) { result ->
            result.onSuccess { videoUrl ->
                handler.post {
                    if (torrentStreamManager !== torrentManager) return@post
                    if (currentScreen != Screen.PLAYER) return@post
                    if (!useVlcPlayer && playbackWebView == null) return@post
                    val directVideoUrl = localTorrentVideoUrl(videoUrl)
                    currentTorrentVideoUrl = directVideoUrl
                    
                    Log.d(LOG_TAG, "? Torrent listo para reproducir")
                    Log.d(LOG_TAG, "?? Video URL: $videoUrl")
                    Log.d(LOG_TAG, "?? Direct Video URL: $directVideoUrl")

                    torrentProgressOverlayEnabled = false
                    torrentPlaybackActive = true
                    torrentOverlayView?.visibility = View.GONE
                    updateTorrentProgress(torrentManager.getDownloadStats())
                    addToContinueWatching(item)

                    if (useVlcPlayer) {
                        showEmbeddedVlcTorrentPlayer(directVideoUrl)
                        return@post
                    }

                    showToast("Reproduciendo desde torrent")
                    
                    // Ocultar overlay nativo y cargar el video
                    playbackWebView?.loadUrl(videoUrl)
                }
            }
            result.onFailure { error ->
                handler.post {
                    if (torrentStreamManager !== torrentManager) return@post
                    torrentStreamManager = null
                    
                    // Cancelar notificación y actualizador de progreso
                    stopProgressUpdater()
                    cancelTorrentDownloadNotification()
                    
                    val errorMessage = error.message ?: "Error desconocido"
                    Log.e(LOG_TAG, "? Error con torrent: $errorMessage")
                    val unsupportedFormatError = !useVlcPlayer && (
                        errorMessage.contains("no es compatible", ignoreCase = true) ||
                            errorMessage.contains("MP4, M4V o WEBM", ignoreCase = true)
                    )
                    
                    // Mostrar diálogo de error con opciones
                    val errorDialogBuilder = android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Error con el torrent")
                        .setMessage(when {
                            unsupportedFormatError ->
                                "Este torrent no contiene un archivo compatible con WebView.\n\nPuedo intentar reproducirlo con VLC interno, que soporta más contenedores y códecs."
                            errorMessage.contains("resolver el magnet", ignoreCase = true) -> 
                                "No se pudo conectar con los seeders.\n\nPosibles causas:\n• Torrent sin seeders activos\n• Timeout de conexión\n• Problemas de red\n\n¿Quieres intentar con otro torrent?"
                            errorMessage.contains("timeout", ignoreCase = true) -> 
                                "Timeout esperando seeders.\n\nEste torrent puede estar muerto o tener muy pocos seeders.\n\n¿Quieres intentar con otro torrent?"
                            errorMessage.contains("metadata", ignoreCase = true) -> 
                                "No se pudo obtener la información del torrent.\n\n¿Quieres intentar con otro torrent?"
                            else -> 
                                "Error: $errorMessage\n\n¿Quieres intentar con otro torrent?"
                        })

                    if (unsupportedFormatError) {
                        errorDialogBuilder
                            .setPositiveButton("Reproducir con VLC") { _, _ ->
                                proceedWithTorrentDownload(
                                    addon,
                                    magnetUri,
                                    fileIdx,
                                    quality,
                                    size,
                                    seeders,
                                    item,
                                    useVlcPlayer = true
                                )
                            }
                            .setNeutralButton("Elegir otro") { _, _ ->
                                searchAndShowTorrentOptions(item, 1, 1)
                            }
                    } else {
                        errorDialogBuilder.setPositiveButton("Elegir otro") { _, _ ->
                            // Volver a mostrar el diálogo de selección
                            searchAndShowTorrentOptions(item, 1, 1)
                        }
                    }

                    val errorDialog = errorDialogBuilder
                        .setNegativeButton("Cancelar") { _, _ ->
                            showCatalog()
                        }
                        .setOnCancelListener {
                            showCatalog()
                        }
                        .create()
                    
                    errorDialog.show()
                }
            }
        }
    }
    
    private fun showErrorInPlayer(message: String) {
        val errorHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <style>
                    body {
                        margin: 0;
                        padding: 20px;
                        background: #000000;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        height: 100vh;
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    }
                    .error-container {
                        text-align: center;
                        color: #FFFFFF;
                        max-width: 400px;
                    }
                    .error-icon {
                        font-size: 48px;
                        margin-bottom: 20px;
                    }
                    .error-message {
                        font-size: 16px;
                        color: #FFFFFF;
                        line-height: 1.5;
                    }
                </style>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-icon">!</div>
                    <div class="error-message">${message.replace("<", "&lt;").replace(">", "&gt;")}</div>
                </div>
            </body>
            </html>
        """.trimIndent()
        
        playbackWebView?.loadDataWithBaseURL(
            null,
            errorHtml,
            "text/html",
            "UTF-8",
            null
        )
    }

    private fun localTorrentVideoUrl(serverUrl: String): String {
        return serverUrl.trimEnd('/') + "/video"
    }

    private fun isLocalTorrentVideoUrl(url: String): Boolean {
        return try {
            val host = Uri.parse(url).host?.lowercase().orEmpty()
            host in LOCAL_TORRENT_HOSTS
        } catch (_: Throwable) {
            false
        }
    }

    private fun showTorrentPlayerShell(item: CatalogItem) {
        destroyPlayerWebView()
        releaseSportsLivePlayer()
        releaseEmbeddedVlcPlayer()
        currentScreen = Screen.PLAYER
        currentPlayingItemId = item.id
        playbackWebView = null
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        torrentOverlayView = overlay

        val sbHeight = statusBarHeight()
        // Barra azul oscura superior que cubre la barra de estado del sistema
        val statusBarCover = View(this).apply {
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener { confirmExitVlc() }
        }
        val title = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            setPadding(dp(12), 0, 0, 0)
        }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        topBar.addView(title, LinearLayout.LayoutParams(0, -1, 1f))

        rootView.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        playbackStatusBarCover = statusBarCover
        playbackTopBar = topBar
        playbackVideoTopInsetPx = sbHeight + dp(48)
        rootView.addView(statusBarCover, FrameLayout.LayoutParams(-1, sbHeight, Gravity.TOP))
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, dp(48), Gravity.TOP).apply {
            topMargin = sbHeight
        })
    }

    /** Muestra confirmación antes de salir de cualquier reproducción. */
    private fun confirmExitPlayback() {
        if (exitPlaybackDialog?.isShowing == true) return
        exitPlaybackDialog = android.app.AlertDialog.Builder(this)
            .setTitle("¿Salir de la reproducción?")
            .setMessage("Se detendrá el vídeo y volverás al catálogo.")
            .setPositiveButton("Salir") { _, _ ->
                sportsResolveGeneration++
                releaseSportsLivePlayer()
                releaseEmbeddedVlcPlayer()
                destroyPlayerWebView()
                torrentPlaybackActive = false
                currentTorrentVideoUrl = null
                showCatalog()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        exitPlaybackDialog?.setOnDismissListener { exitPlaybackDialog = null }
        exitPlaybackDialog?.show()
    }

    private fun confirmExitVlc() = confirmExitPlayback()

    private fun showEmbeddedVlcTorrentPlayer(videoUrl: String) {
        try {
            releaseEmbeddedVlcPlayer()
            vlcHasRenderedVideo = false
            playbackWebView?.visibility = View.GONE
            torrentOverlayView?.visibility = View.GONE

            val videoLayout = VLCVideoLayout(this).apply {
                setBackgroundColor(Color.BLACK)
            }
            val insertIndex = if (rootView.childCount >= 2) 1 else rootView.childCount
            rootView.addView(videoLayout, insertIndex, FrameLayout.LayoutParams(-1, -1).apply {
                topMargin = playbackVideoTopInsetPx
            })

            val controlsOverlay = buildEmbeddedVlcControls(videoUrl)
            // Add controls AFTER video layout to ensure they're on top
            rootView.addView(controlsOverlay, FrameLayout.LayoutParams(-1, -1))
            playbackStatusBarCover?.bringToFront()
            playbackTopBar?.bringToFront()

            vlcVideoLayout = videoLayout
            vlcControlsOverlay = controlsOverlay
            setEmbeddedVlcStatus("Preparando VLC interno...", keepVisible = true)

            // Esperar a que el layout esté completamente dibujado antes de iniciar VLC.
            // Se usa TextureView al adjuntar VLC para evitar pantallas negras/z-order con SurfaceView.
            videoLayout.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    videoLayout.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    if (vlcVideoLayout !== videoLayout || currentTorrentVideoUrl != videoUrl) return
                    startEmbeddedVlcWhenSurfaceIsReady(videoLayout, videoUrl)
                }
            })
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "No se pudo preparar VLC interno", error)
            showEmbeddedVlcErrorOverlay("No se pudo preparar VLC interno: ${error.message ?: "error desconocido"}")
        }
    }

    private fun startEmbeddedVlcWhenSurfaceIsReady(
        videoLayout: VLCVideoLayout,
        videoUrl: String,
        attempt: Int = 0
    ) {
        if (vlcVideoLayout !== videoLayout || currentTorrentVideoUrl != videoUrl) return
        if ((!videoLayout.isAttachedToWindow || videoLayout.width <= 0 || videoLayout.height <= 0) && attempt < 30) {
            handler.postDelayed({
                startEmbeddedVlcWhenSurfaceIsReady(videoLayout, videoUrl, attempt + 1)
            }, 100L)
            return
        }

        try {
            val isSportsStream = isLikelySportsStreamUrl(videoUrl) && !isLocalTorrentVideoUrl(videoUrl)
            val cacheMs = if (isSportsStream) "1200" else "8000"
            val libVlc = LibVLC(
                this,
                arrayListOf(
                    "--network-caching=$cacheMs",
                    "--file-caching=$cacheMs",
                    "--live-caching=$cacheMs",
                    "--clock-jitter=0",
                    "--clock-synchro=0",
                    "--no-drop-late-frames",
                    "--no-skip-frames"
                )
            )
            val player = VlcMediaPlayer(libVlc)

            // Adjuntar vistas ANTES de asignar el media y reproducir.
            // El último parámetro activa TextureView; evita muchas pantallas negras al superponer controles.
            player.attachViews(videoLayout, null, false, true)

            val media = VlcMedia(libVlc, Uri.parse(videoUrl)).apply {
                setHWDecoderEnabled(true, false)
                addOption(":network-caching=$cacheMs")
                addOption(":file-caching=$cacheMs")
                addOption(":live-caching=$cacheMs")
                addOption(":http-reconnect")
                if (isSportsStream) {
                    addOption(":http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
                    sportsHttpReferrerForUrl(videoUrl).takeIf { it.isNotBlank() }?.let { addOption(":http-referrer=$it") }
                } else {
                    addOption(":http-user-agent=$COMPATIBLE_USER_AGENT")
                    addOption(":http-referrer=$STREAMED_BASE_URL/")
                }
            }
            player.media = media
            media.release()

            vlcLib = libVlc
            vlcPlayer = player
            vlcSoftwareVolumePercent = 100
            setEmbeddedVlcSoftwareVolume(100)

            player.setEventListener { event ->
                when (event.type) {
                    VlcMediaPlayer.Event.EncounteredError -> handler.post {
                        if (vlcPlayer === player) {
                            showEmbeddedVlcErrorOverlay("VLC interno no pudo reproducir esta fuente. Puede que todavía falten datos del torrent o que el codec no sea compatible en este dispositivo.")
                        }
                    }
                    VlcMediaPlayer.Event.Buffering -> handler.post {
                        if (vlcPlayer === player) {
                            val message = if (isLocalTorrentVideoUrl(videoUrl)) {
                                "Buffering desde torrent..."
                            } else {
                                "Buffering..."
                            }
                            setEmbeddedVlcStatus(message, keepVisible = true)
                            updateEmbeddedVlcPlayPauseButton()
                        }
                    }
                    VlcMediaPlayer.Event.Vout -> handler.post {
                        if (vlcPlayer === player) {
                            vlcHasRenderedVideo = true
                            player.updateVideoSurfaces()
                            setEmbeddedVlcStatus("Imagen recibida", keepVisible = false)
                        }
                    }
                    VlcMediaPlayer.Event.Playing -> handler.post {
                        if (vlcPlayer === player) {
                            // Forzar actualización de superficies cuando empieza a reproducir
                            vlcHasRenderedVideo = true
                            player.updateVideoSurfaces()
                            updateEmbeddedVlcPlayPauseButton()
                            setEmbeddedVlcStatus("Reproduciendo con VLC", keepVisible = false)
                            handler.postDelayed({ if (vlcPlayer === player) player.updateVideoSurfaces() }, 200)
                            handler.postDelayed({ if (vlcPlayer === player) player.updateVideoSurfaces() }, 600)
                        }
                    }
                    VlcMediaPlayer.Event.Paused -> handler.post {
                        if (vlcPlayer === player) {
                            updateEmbeddedVlcPlayPauseButton()
                            setEmbeddedVlcStatus("Pausado", keepVisible = true)
                        }
                    }
                    VlcMediaPlayer.Event.Stopped -> handler.post {
                        if (vlcPlayer === player) {
                            updateEmbeddedVlcPlayPauseButton()
                        }
                    }
                }
            }

            player.play()
            startEmbeddedVlcProgressUpdater()

            // Llamadas escalonadas a updateVideoSurfaces para asegurar que la imagen aparece
            listOf(100L, 300L, 700L, 1500L, 3000L, 5000L).forEach { delay ->
                handler.postDelayed({ if (vlcPlayer === player) player.updateVideoSurfaces() }, delay)
            }

            showToast("Reproduciendo con VLC")
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "No se pudo iniciar VLC interno", error)
            showEmbeddedVlcErrorOverlay("No se pudo iniciar VLC interno: ${error.message ?: "error desconocido"}")
        }
    }

    private fun buildEmbeddedVlcControls(videoUrl: String): FrameLayout {
        return FrameLayout(this).apply {
            isClickable = true
            isFocusable = true
            setBackgroundColor(Color.TRANSPARENT)

            val status = TextView(this@MainActivity).apply {
                text = "Preparando VLC interno..."
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    setColor(color("#88000000"))
                    cornerRadius = dp(10).toFloat()
                }
            }
            vlcStatusText = status
            addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

            // Barra inferior del reproductor (controles de reproducción)
            val bottomBar = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                isClickable = true
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(color("#00000000"), color("#CC000000")))
            }

            val playPause = vlcIconButton("\u25B6", 26f) {
                val player = vlcPlayer ?: return@vlcIconButton
                try {
                    if (player.isPlaying) player.pause() else player.play()
                    updateEmbeddedVlcPlayPauseButton()
                } catch (error: Throwable) {
                    Log.w(LOG_TAG, "No se pudo pausar/reanudar VLC", error)
                }
            }
            vlcPlayPauseButton = playPause
            bottomBar.addView(playPause, LinearLayout.LayoutParams(dp(44), dp(44)))

            val currentTime = vlcTimeText("00:00:00")
            vlcCurrentTimeText = currentTime
            bottomBar.addView(currentTime, LinearLayout.LayoutParams(dp(70), dp(44)).apply { leftMargin = dp(4) })

            val seekBar = SeekBar(this@MainActivity).apply {
                max = 1000
                progress = 0
                splitTrack = false
                progressTintList = ColorStateList.valueOf(Color.WHITE)
                thumbTintList = ColorStateList.valueOf(Color.WHITE)
                progressBackgroundTintList = ColorStateList.valueOf(color("#55FFFFFF"))
                setPadding(dp(4), 0, dp(4), 0)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) updateEmbeddedVlcSeekPreview(progress)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {
                        isVlcSeekBarDragging = true
                    }
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        val targetProgress = seekBar?.progress ?: return
                        isVlcSeekBarDragging = false
                        seekEmbeddedVlcToProgress(targetProgress)
                    }
                })
            }
            vlcSeekBar = seekBar
            bottomBar.addView(seekBar, LinearLayout.LayoutParams(0, dp(44), 1f))

            val duration = vlcTimeText("00:00:00")
            vlcDurationText = duration
            bottomBar.addView(duration, LinearLayout.LayoutParams(dp(70), dp(44)))

            // Botón + (subtítulos)
            val subtitle = vlcIconButton("+", 26f) {
                openEmbeddedVlcSubtitlePicker()
            }
            subtitle.background = null
            subtitle.setPadding(dp(6), 0, dp(6), 0)
            bottomBar.addView(subtitle, LinearLayout.LayoutParams(dp(42), dp(36)).apply { leftMargin = dp(4) })

            // -- Volumen integrado en la barra inferior, entre subtítulos y pantalla completa
        val volumePanel = buildVolumePanel()
            bottomBar.addView(volumePanel, LinearLayout.LayoutParams(dp(48), dp(52)).apply { leftMargin = dp(4) })

            val fullscreen = vlcIconButton("\u26F6", 22f) {
                toggleEmbeddedVlcFullscreen()
            }
            vlcFullscreenButton = fullscreen
            bottomBar.addView(fullscreen, LinearLayout.LayoutParams(dp(42), dp(44)).apply { leftMargin = dp(2) })

            addView(bottomBar, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM))
        }
    }

    private fun buildVolumePanel(): FrameLayout {
        val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
        val barHeights = listOf(dp(16), dp(26), dp(38))

        val wrapper = FrameLayout(this).apply {
            background = null
            setPadding(dp(4), dp(4), dp(4), dp(4))
            isClickable = true
            isFocusable = true
        }

        val controlsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val barsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            isClickable = true
            isFocusable = true
        }

        val volLabel = TextView(this).apply {
            text = ""
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply {
                setColor(color("#AA000000"))
                cornerRadius = dp(4).toFloat()
            }
            visibility = View.GONE
        }

        val volHideToken = Object()

        fun refreshBars() {
            val maxVol = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            if (maxVol > 0) {
                am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, maxVol, 0)
            }
            val pct = vlcSoftwareVolumePercent.coerceIn(100, 200)
            val filled = (1 + ((pct - 100) / 50f).roundToInt()).coerceIn(1, 3)
            for (i in 0 until barsRow.childCount) {
                barsRow.getChildAt(i)?.background = GradientDrawable().apply {
                    setColor(if (i < filled) Color.WHITE else color("#55FFFFFF"))
                    cornerRadius = dp(3).toFloat()
                }
            }
            volLabel.visibility = View.GONE
        }

        fun changeVolume(deltaPercent: Int) {
            val previous = vlcSoftwareVolumePercent
            vlcSoftwareVolumePercent = (vlcSoftwareVolumePercent + deltaPercent).coerceIn(100, 200)
            setEmbeddedVlcSoftwareVolume(vlcSoftwareVolumePercent)
            refreshBars()
            if (deltaPercent > 0 && vlcSoftwareVolumePercent > previous) {
                playVolumeRiseBeep(vlcSoftwareVolumePercent)
            }
        }

        fun startRepeating(deltaPercent: Int) {
            stopVlcVolumeRepeat()
            var repeatCount = 0
            changeVolume(deltaPercent)
            val runnable = object : Runnable {
                override fun run() {
                    changeVolume(deltaPercent)
                    repeatCount++
                    val nextDelay = (210 - repeatCount * 14).coerceAtLeast(72)
                    handler.postDelayed(this, nextDelay.toLong())
                }
            }
            vlcVolumeRepeatRunnable = runnable
            handler.postDelayed(runnable, 360L)
        }

        fun repeatButton(icon: String, deltaPercent: Int): TextView {
            return TextView(this).apply {
                text = icon
                setTextColor(Color.WHITE)
                textSize = 18f
                gravity = Gravity.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                isClickable = true
                isFocusable = true
                background = GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    cornerRadius = dp(8).toFloat()
                }
                setOnTouchListener { v, event ->
                    when (event.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            v.isPressed = true
                            startRepeating(deltaPercent)
                            true
                        }
                        android.view.MotionEvent.ACTION_UP,
                        android.view.MotionEvent.ACTION_CANCEL -> {
                            v.isPressed = false
                            stopVlcVolumeRepeat()
                            true
                        }
                        else -> true
                    }
                }
            }
        }

        barHeights.forEachIndexed { i, h ->
            val bar = View(this).apply {
                background = GradientDrawable().apply {
                    setColor(color("#55FFFFFF"))
                    cornerRadius = dp(3).toFloat()
                }
            }
            barsRow.addView(bar, android.widget.LinearLayout.LayoutParams(dp(6), h).apply {
                if (i < barHeights.lastIndex) rightMargin = dp(3)
            })
        }

        controlsRow.addView(barsRow, android.widget.LinearLayout.LayoutParams(dp(32), dp(40)).apply {
            leftMargin = dp(4)
            rightMargin = dp(4)
        })
        barsRow.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> {
                    val sectionWidth = (v.width / 3f).coerceAtLeast(1f)
                    val section = (event.x / sectionWidth).toInt().coerceIn(0, 2)
                    val target = 100 + section * 50
                    val previous = vlcSoftwareVolumePercent
                    vlcSoftwareVolumePercent = target
                    setEmbeddedVlcSoftwareVolume(target)
                    refreshBars()
                    if (target > previous) playVolumeRiseBeep(target)
                    true
                }
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> {
                    stopVlcVolumeRepeat()
                    true
                }
                else -> true
            }
        }

        wrapper.addView(controlsRow, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        handler.post { refreshBars() }
        return wrapper
    }

    private fun stopVlcVolumeRepeat() {
        vlcVolumeRepeatRunnable?.let { handler.removeCallbacks(it) }
        vlcVolumeRepeatRunnable = null
    }

    private fun playVolumeRiseBeep(percent: Int) {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastVolumeBeepAt < 85L) return
        lastVolumeBeepAt = now
        val pitch = 520.0 + ((percent - 100).coerceIn(0, 100) * 8.5)
        Thread {
            try {
                val sampleRate = 22_050
                val durationMs = 55
                val samplesCount = (sampleRate * durationMs) / 1000
                val samples = ShortArray(samplesCount)
                val amplitude = (Short.MAX_VALUE * 0.14).toInt()
                for (i in samples.indices) {
                    val fade = when {
                        i < samplesCount / 5 -> i.toDouble() / (samplesCount / 5).coerceAtLeast(1)
                        i > samplesCount * 4 / 5 -> (samplesCount - i).toDouble() / (samplesCount / 5).coerceAtLeast(1)
                        else -> 1.0
                    }.coerceIn(0.0, 1.0)
                    samples[i] = (sin(2.0 * PI * i * pitch / sampleRate) * amplitude * fade).toInt().toShort()
                }
                val format = android.media.AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                    .build()
                val minBuffer = android.media.AudioTrack.getMinBufferSize(
                    sampleRate,
                    android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT
                )
                val track = android.media.AudioTrack(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                    format,
                    maxOf(minBuffer, samples.size * 2),
                    android.media.AudioTrack.MODE_STATIC,
                    android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(durationMs + 35L)
                track.release()
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "No se pudo reproducir pitido de volumen", error)
            }
        }.apply {
            name = "DownTVVolumeBeep"
            start()
        }
    }

    private fun setEmbeddedVlcSoftwareVolume(percent: Int) {
        val player = vlcPlayer ?: return
        val clamped = percent.coerceIn(100, 200)
        try {
            val method = player.javaClass.methods.firstOrNull { method ->
                method.name == "setVolume" &&
                    method.parameterTypes.size == 1 &&
                    method.parameterTypes[0] == Int::class.javaPrimitiveType
            }
            method?.invoke(player, clamped)
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo ajustar el volumen de VLC", error)
        }
    }

    private fun vlcIconButton(icon: String, iconSize: Float, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = icon
            setTextColor(Color.WHITE)
            textSize = iconSize
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            includeFontPadding = false
            background = null
            setOnClickListener { onClick() }
        }
    }

    private fun vlcTimeText(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("monospace", Typeface.NORMAL)
            gravity = Gravity.CENTER
            includeFontPadding = false
            setSingleLine(true)
        }
    }

    private fun setEmbeddedVlcStatus(message: String, keepVisible: Boolean) {
        val status = vlcStatusText ?: return
        status.text = message
        status.visibility = View.VISIBLE
        if (!keepVisible) {
            handler.postDelayed({
                if (vlcStatusText === status && status.text == message) {
                    status.visibility = View.GONE
                }
            }, 1800L)
        }
    }

    private fun updateEmbeddedVlcPlayPauseButton() {
        val button = vlcPlayPauseButton ?: return
        val player = vlcPlayer
        button.text = if (player != null && player.isPlaying) "II" else "\u25B6"
    }

    private fun startEmbeddedVlcProgressUpdater() {
        stopEmbeddedVlcProgressUpdater()
        val runnable = object : Runnable {
            override fun run() {
                updateEmbeddedVlcProgress()
                handler.postDelayed(this, 500L)
            }
        }
        vlcProgressRunnable = runnable
        handler.post(runnable)
    }

    private fun stopEmbeddedVlcProgressUpdater() {
        vlcProgressRunnable?.let { handler.removeCallbacks(it) }
        vlcProgressRunnable = null
    }

    private fun updateEmbeddedVlcProgress() {
        val player = vlcPlayer ?: return
        try {
            val length = player.length.coerceAtLeast(0L)
            val time = player.time.coerceAtLeast(0L).coerceAtMost(if (length > 0L) length else Long.MAX_VALUE)
            vlcCurrentTimeText?.text = formatVlcTime(time)
            vlcDurationText?.text = if (length > 0L) formatVlcTime(length) else "00:00:00"
            if (!isVlcSeekBarDragging && length > 0L) {
                vlcSeekBar?.progress = ((time * 1000L) / length).toInt().coerceIn(0, 1000)
            }
            updateEmbeddedVlcPlayPauseButton()
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo actualizar progreso VLC", error)
        }
    }

    private fun updateEmbeddedVlcSeekPreview(progress: Int) {
        val player = vlcPlayer ?: return
        try {
            val length = player.length.coerceAtLeast(0L)
            if (length > 0L) {
                vlcCurrentTimeText?.text = formatVlcTime((length * progress.coerceIn(0, 1000)) / 1000L)
            }
        } catch (_: Throwable) {
        }
    }

    private fun seekEmbeddedVlcToProgress(progress: Int) {
        val player = vlcPlayer ?: return
        try {
            val length = player.length.coerceAtLeast(0L)
            if (length <= 0L) return
            val targetTime = (length * progress.coerceIn(0, 1000)) / 1000L
            val method = player.javaClass.methods.firstOrNull { method ->
                method.name == "setTime" &&
                    method.parameterTypes.size == 1 &&
                    method.parameterTypes[0] == Long::class.javaPrimitiveType
            }
            if (method != null) {
                method.invoke(player, targetTime)
            } else {
                val positionMethod = player.javaClass.methods.firstOrNull { method ->
                    method.name == "setPosition" &&
                        method.parameterTypes.size == 1 &&
                        method.parameterTypes[0] == Float::class.javaPrimitiveType
                }
                positionMethod?.invoke(player, progress.coerceIn(0, 1000) / 1000f)
            }
            updateEmbeddedVlcProgress()
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo mover la reproducción VLC", error)
        }
    }

    private fun formatVlcTime(milliseconds: Long): String {
        val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return "%02d:%02d:%02d".format(hours, minutes, seconds)
    }

    private fun toggleEmbeddedVlcFullscreen() {
        if (isEmbeddedVlcFullscreen) {
            exitEmbeddedVlcFullscreen()
        } else {
            enterEmbeddedVlcFullscreen()
        }
    }

    private fun enterEmbeddedVlcFullscreen() {
        isEmbeddedVlcFullscreen = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        enterImmersiveMode()
        vlcFullscreenButton?.text = "\u25A3"
        handler.postDelayed({ vlcPlayer?.updateVideoSurfaces() }, 300L)
    }

    private fun exitEmbeddedVlcFullscreen() {
        isEmbeddedVlcFullscreen = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        exitImmersiveMode()
        vlcFullscreenButton?.text = "\u26F6"
        handler.postDelayed({ vlcPlayer?.updateVideoSurfaces() }, 300L)
    }

    private fun openEmbeddedVlcSubtitlePicker() {
        try {
            embeddedVlcSubtitlePicker.launch(arrayOf(
                "application/x-subrip",
                "text/srt",
                "text/plain",
                "text/vtt",
                "application/octet-stream",
                "*/*"
            ))
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo abrir selector de subtítulos", error)
            showToast("No se pudo abrir Descargas")
        }
    }

    private fun attachSubtitleToEmbeddedVlc(uri: Uri) {
        val player = vlcPlayer
        if (player == null) {
            showToast("Abre primero un vídeo")
            return
        }
        try {
            val subtitleFile = copySubtitleToInternalCache(uri)
            val subtitleUri = Uri.fromFile(subtitleFile).toString()
            val attached = addSubtitleSlaveWithReflection(player, subtitleUri)
            showToast(if (attached) "Subtítulos añadidos" else "No se pudieron añadir subtítulos")
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "No se pudieron añadir subtítulos", error)
            showToast("No se pudieron añadir subtítulos")
        }
    }

    private fun copySubtitleToInternalCache(uri: Uri): File {
        val dir = File(cacheDir, "vlc_subtitles").apply { mkdirs() }
        val rawName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "subtitles.srt"
        val safeName = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").let { name ->
            if (name.endsWith(".srt", true) || name.endsWith(".vtt", true) || name.endsWith(".sub", true)) name else "$name.srt"
        }
        val target = File(dir, "selected_${System.currentTimeMillis()}_$safeName")
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IOException("No se pudo leer el subtítulo")
        return target
    }

    private fun addSubtitleSlaveWithReflection(player: VlcMediaPlayer, subtitleUri: String): Boolean {
        val methods = player.javaClass.methods.filter { it.name == "addSlave" && it.parameterTypes.size == 3 }
        for (method in methods) {
            try {
                val second = method.parameterTypes[1]
                val result = when {
                    second == String::class.java -> method.invoke(player, 0, subtitleUri, true)
                    second == Uri::class.java -> method.invoke(player, 0, Uri.parse(subtitleUri), true)
                    else -> null
                }
                if (result !is Boolean || result) return true
            } catch (_: Throwable) {
            }
        }
        return false
    }

    private fun showEmbeddedVlcErrorOverlay(message: String) {
        val overlay = torrentOverlayView ?: return
        overlay.removeAllViews()
        overlay.tag = null
        overlay.setBackgroundColor(Color.BLACK)
        overlay.visibility = View.VISIBLE

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
        }

        container.addView(TextView(this).apply {
            text = "VLC interno"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }, LinearLayout.LayoutParams(-1, -2))

        container.addView(TextView(this).apply {
            text = "$message\n\nEl torrent sigue servido desde DownTV mientras permanezcas en esta pantalla."
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setLineSpacing(dp(4).toFloat(), 1f)
            setPadding(0, 0, 0, dp(20))
        }, LinearLayout.LayoutParams(-1, -2))

        container.addView(TextView(this).apply {
            text = "Reintentar VLC"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(18), 0, dp(18), 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener {
                currentTorrentVideoUrl?.let { showEmbeddedVlcTorrentPlayer(it) }
            }
        }, LinearLayout.LayoutParams(-2, dp(44)))

        overlay.addView(container, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
    }
    
    private fun showToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }
    
    private fun showTorrentDownloadNotification() {
        torrentProgressOverlayEnabled = true
        torrentPlaybackActive = false

        // Crear notificación del sistema
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(android.app.NotificationManager::class.java)
            
            // Crear canal de notificación
            val channelId = "torrent_download"
            val channel = android.app.NotificationChannel(
                channelId,
                "Descargas de Torrent",
                android.app.NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificaciones de descarga de torrents"
            }
            notificationManager.createNotificationChannel(channel)
            
            // Crear notificación inicial
            val notification = android.app.Notification.Builder(this, channelId)
                .setContentTitle("Descargando torrent")
                .setContentText("Connecting to seeders")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setProgress(100, 0, true)
                .build()
            
            notifyTorrentDownload(notificationManager, notification)
        }
        
        // Mostrar también en el WebView
        updateTorrentProgressUI(0f, 0, -1, 0, 0)
    }
    
    private fun startProgressUpdater(torrentManager: TorrentStreamManager) {
        stopProgressUpdater()
        isProgressUpdating = true
        
        progressUpdateRunnable = object : Runnable {
            override fun run() {
                if (!isProgressUpdating || torrentStreamManager !== torrentManager) return
                
                val stats = torrentManager.getDownloadStats()
                updateTorrentProgress(stats)
                
                // Actualizar cada 1 segundo
                handler.postDelayed(this, 1000)
            }
        }
        
        handler.postDelayed(progressUpdateRunnable!!, 1000)
    }
    
    private fun stopProgressUpdater() {
        isProgressUpdating = false
        progressUpdateRunnable?.let { handler.removeCallbacks(it) }
        progressUpdateRunnable = null
    }
    
    private fun updateTorrentProgress(stats: TorrentStreamManager.DownloadStats) {
        // Actualizar notificación del sistema
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(android.app.NotificationManager::class.java)
            val channelId = "torrent_download"
            
            val progressPercent = (stats.progress * 100).toInt()
            val downloadRateMBps = stats.downloadRate / (1024.0 * 1024.0)
            
            val contentText = when {
                stats.progress < 0.01f && stats.numSeeds == 0 -> 
                    "Connecting to seeders"
                stats.progress < 0.01f -> 
                    "Connecting to seeders"
                stats.eta > 0 -> {
                    val etaMinutes = stats.eta / 60
                    val etaSeconds = stats.eta % 60
                    val etaText = if (etaMinutes > 0) {
                        "${etaMinutes}m ${etaSeconds}s"
                    } else {
                        "${etaSeconds}s"
                    }
                    String.format("$progressPercent%% - %.1f MB/s - $etaText restantes", downloadRateMBps)
                }
                else -> 
                    String.format("$progressPercent%% - %.1f MB/s", downloadRateMBps)
            }
            
            val notification = android.app.Notification.Builder(this, channelId)
                .setContentTitle(if (torrentPlaybackActive) "Reproduciendo torrent" else "Descargando torrent")
                .setContentText(contentText)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setProgress(100, progressPercent, false)
                .build()
            
            notifyTorrentDownload(notificationManager, notification)
        }

        if (torrentPlaybackActive &&
            currentTorrentVideoUrl?.let { isLocalTorrentVideoUrl(it) } == true &&
            !vlcHasRenderedVideo
        ) {
            val downloadRateMBps = stats.downloadRate / (1024.0 * 1024.0)
            val statusText = when {
                stats.progress < 0.01f && stats.numSeeds == 0 ->
                    "Conectando con seeders..."
                stats.downloadRate > 0 ->
                    String.format("Buffering desde torrent - %.1f MB/s - %d seeders", downloadRateMBps, stats.numSeeds)
                stats.numSeeds > 0 || stats.numPeers > 0 ->
                    "Buffering desde torrent - ${stats.numSeeds} seeders - ${stats.numPeers} peers"
                else ->
                    "Buffering desde torrent..."
            }
            setEmbeddedVlcStatus(statusText, keepVisible = true)
        }
        
        if (torrentProgressOverlayEnabled) {
            updateTorrentProgressUI(
                stats.progress,
                stats.downloadRate,
                stats.eta,
                stats.numSeeds,
                stats.numPeers
            )
        }
    }
    
    private fun updateTorrentProgressUI(
        progress: Float,
        downloadRate: Int,
        eta: Int,
        numSeeds: Int,
        numPeers: Int
    ) {
        handler.post {
            if (currentScreen != Screen.PLAYER) return@post
            val overlay = torrentOverlayView ?: return@post

            val progressPercent = (progress * 100).toInt()
            val downloadRateMBps = downloadRate / (1024.0 * 1024.0)

            val statusMessage = when {
                progress < 0.01f && numSeeds == 0 ->
                    "Connecting to seeders"
                progress < 0.01f ->
                    "Connecting to seeders"
                eta > 0 -> {
                    val etaMinutes = eta / 60
                    val etaSeconds = eta % 60
                    val etaText = if (etaMinutes > 0) "${etaMinutes}m ${etaSeconds}s" else "${etaSeconds}s"
                    String.format("%.1f MB/s · %s restantes", downloadRateMBps, etaText)
                }
                else -> String.format("%.1f MB/s", downloadRateMBps)
            }

            overlay.visibility = View.VISIBLE

            // Actualizar vistas existentes si ya están construidas
            if (overlay.tag == "built") {
                overlay.findViewWithTag<TextView>("percent")?.text = if (progressPercent > 0) "$progressPercent%" else ""
                overlay.findViewWithTag<TextView>("status")?.text = statusMessage
                overlay.findViewWithTag<TextView>("seeds")?.text =
                    if (numSeeds > 0 || numPeers > 0) "$numSeeds seeders · $numPeers peers" else ""
                return@post
            }

            // Construir el overlay por primera vez
            overlay.removeAllViews()
            overlay.tag = "built"

            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(40), 0, dp(40), 0)
            }

            container.addView(android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleLarge).apply {
                isIndeterminate = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    indeterminateTintList = ColorStateList.valueOf(color("#F97316"))
                }
            }, LinearLayout.LayoutParams(dp(72), dp(72)).apply { bottomMargin = dp(16) })

            container.addView(TextView(this).apply {
                tag = "status"
                text = statusMessage
                setTextColor(Color.WHITE)
                textSize = 16f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(10))
            }, LinearLayout.LayoutParams(-1, -2))

            container.addView(TextView(this).apply {
                tag = "percent"
                text = if (progressPercent > 0) "$progressPercent%" else ""
                setTextColor(Color.WHITE)
                textSize = 36f
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(8))
            }, LinearLayout.LayoutParams(-1, -2))

            container.addView(TextView(this).apply {
                tag = "seeds"
                text = if (numSeeds > 0 || numPeers > 0) "$numSeeds seeders · $numPeers peers" else ""
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(20))
            }, LinearLayout.LayoutParams(-1, -2))


            overlay.addView(container, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
    }
    
    private fun cancelTorrentDownloadNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val notificationManager = getSystemService(android.app.NotificationManager::class.java)
                notificationManager.cancel(1)
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "No se pudo cancelar la notificacion de torrent", error)
            }
        }
    }

    private fun canPostTorrentNotification(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun notifyTorrentDownload(
        notificationManager: android.app.NotificationManager,
        notification: android.app.Notification
    ) {
        if (!canPostTorrentNotification()) {
            Log.d(LOG_TAG, "Notificacion de torrent omitida: permiso no concedido")
            return
        }

        try {
            notificationManager.notify(1, notification)
        } catch (error: SecurityException) {
            Log.w(LOG_TAG, "Android bloqueo la notificacion de torrent", error)
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo mostrar la notificacion de torrent", error)
        }
    }

    private fun loadExternalSpanishSubtitles(item: CatalogItem, season: Int, episode: Int) {
        val playbackKey = subtitlePlaybackKey(item, season, episode)
        currentSubtitlePlaybackKey = playbackKey
        activeExternalSubtitleVtt = null

        Thread {
            val subtitle = findExternalSpanishSubtitle(item, season, episode) ?: return@Thread
            handler.post {
                if (currentSubtitlePlaybackKey != playbackKey || currentScreen != Screen.PLAYER) return@post
                activeExternalSubtitleLabel = subtitle.first
                activeExternalSubtitleVtt = subtitle.second
                playbackWebView?.let { injectExternalSubtitleTrack(it) }
                Log.d(LOG_TAG, "Subtitulos externos en castellano cargados: ${subtitle.first}")
            }
        }.start()
    }

    private fun findExternalSpanishSubtitle(item: CatalogItem, season: Int, episode: Int): Pair<String, String>? {
        val imdbId = item.imdbId.trim()
        if (imdbId.isBlank()) return null

        return try {
            val type = if (item.type.equals("series", ignoreCase = true)) "series" else "movie"
            val subtitleId = if (type == "series") "$imdbId:$season:$episode" else imdbId
            val manifestUrl = "$OPEN_SUBTITLES_STREMIO_BASE_URL/subtitles/$type/$subtitleId.json"
            val subtitles = JSONObject(fetchJson(manifestUrl)).optJSONArray("subtitles") ?: return null
            var best: JSONObject? = null
            var bestScore = Int.MIN_VALUE

            for (i in 0 until subtitles.length()) {
                val candidate = subtitles.optJSONObject(i) ?: continue
                val lang = candidate.optString("lang").lowercase()
                val url = candidate.optString("url")
                if (url.isBlank()) continue
                val score = when {
                    lang == "spa" -> 100
                    lang in SPANISH_SUBTITLE_LANGS -> 90
                    lang.startsWith("es") -> 80
                    else -> -100
                } + candidate.optString("g").toIntOrNull().orZero()
                if (score > bestScore) {
                    best = candidate
                    bestScore = score
                }
            }

            val subtitleUrl = best?.optString("url")?.takeIf { it.isNotBlank() } ?: return null
            val rawSubtitle = fetchText(subtitleUrl, "text/vtt,text/plain,*/*", manifestUrl)
            val vtt = subtitleTextToWebVtt(rawSubtitle)
            if (vtt.isBlank()) return null
            val label = when (best?.optString("lang")?.lowercase()) {
                "spa", "esp", "es", "es-es" -> "Castellano"
                else -> "Español"
            }
            label to vtt
        } catch (error: Throwable) {
            Log.d(LOG_TAG, "No se pudieron cargar subtitulos externos: ${error.message}")
            null
        }
    }

    private fun subtitleTextToWebVtt(raw: String): String {
        val clean = raw
            .removePrefix("\uFEFF")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .trim()

        if (clean.isBlank()) return ""
        if (clean.startsWith("WEBVTT", ignoreCase = true)) return clean

        val timestamp = Regex("""(\d{1,2}:\d{2}:\d{2}),(\d{3})""")
        val fixed = clean.lines().joinToString("\n") { line ->
            timestamp.replace(line) { match -> "${match.groupValues[1]}.${match.groupValues[2]}" }
        }
        return "WEBVTT\n\n$fixed\n"
    }

    private fun injectExternalSubtitleTrack(view: WebView) {
        val vtt = activeExternalSubtitleVtt ?: return
        val source = "data:text/vtt;charset=utf-8;base64," +
            Base64.encodeToString(vtt.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val label = activeExternalSubtitleLabel
        val script = """
            (() => {
                const source = ${JSONObject.quote(source)};
                const label = ${JSONObject.quote(label)};
                const marker = 'kota-external-spanish-subtitles';

                function showSpanishTrack(video) {
                    const tracks = video.textTracks || [];
                    for (let i = 0; i < tracks.length; i++) {
                        const t = tracks[i];
                        const isKota = String(t.label || '').toLowerCase() === label.toLowerCase();
                        const isSpanish = ['es', 'spa', 'esp'].includes(String(t.language || '').toLowerCase());
                        t.mode = (isKota || isSpanish) ? 'showing' : 'disabled';
                    }
                }

                function attach(video) {
                    if (!video) return;
                    const current = video.querySelector('track[data-kota-subtitles="' + marker + '"]');
                    if (current && current.src === source) {
                        showSpanishTrack(video);
                        return;
                    }

                    video.querySelectorAll('track[data-kota-subtitles="' + marker + '"]').forEach(t => t.remove());
                    const track = document.createElement('track');
                    track.kind = 'subtitles';
                    track.label = label;
                    track.srclang = 'es';
                    track.default = true;
                    track.src = source;
                    track.setAttribute('data-kota-subtitles', marker);
                    track.addEventListener('load', () => showSpanishTrack(video));
                    video.appendChild(track);
                    [100, 400, 1000, 2000].forEach(delay => setTimeout(() => showSpanishTrack(video), delay));
                }

                function apply() {
                    document.querySelectorAll('video').forEach(attach);
                }

                apply();
                [300, 800, 1600, 3000, 6000].forEach(delay => setTimeout(apply, delay));
                if (!window.__kotaExternalSubtitleObserver) {
                    window.__kotaExternalSubtitleObserver = new MutationObserver(apply);
                    window.__kotaExternalSubtitleObserver.observe(document.documentElement, {
                        childList: true,
                        subtree: true
                    });
                }
                console.log('KotaTV: subtitulos externos preparados');
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun subtitlePlaybackKey(item: CatalogItem, season: Int, episode: Int): String {
        return "${item.id}:${item.imdbId}:$season:$episode"
    }

    private fun Int?.orZero(): Int = this ?: 0

    private fun showPlayer(item: CatalogItem, embedUrl: String, host: PlaybackHost) {
        destroyPlayerWebView()
        currentScreen = Screen.PLAYER
        currentPlayingItemId = item.id
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        val webView = WebView(this).also { playbackWebView = it }
        configurePlayerWebView(webView)

        val sbHeight = statusBarHeight()
        val statusBarCover = View(this).apply {
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke(dp(1), Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener { confirmExitPlayback() }
        }
        
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))

        // Overlay nativo para notificaciones de descarga de torrent
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        torrentOverlayView = overlay

        rootView.addView(webView, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = sbHeight + dp(52)
        })
        rootView.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        rootView.addView(statusBarCover, FrameLayout.LayoutParams(-1, sbHeight, Gravity.TOP))
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply {
            topMargin = sbHeight
        })

        if (embedUrl.isNotBlank()) {
            val headers = mapOf(
                "Accept-Language" to "es-ES,es;q=0.9,en;q=0.8",
                "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Referer" to "https://www.google.com/",
                "Sec-Fetch-Dest" to "iframe",
                "Sec-Fetch-Mode" to "navigate",
                "Sec-Fetch-Site" to "cross-site"
            )
            webView.loadUrl(embedUrl, headers)
        }
    }

    private fun showAudioTrackSelector(webView: WebView) {
        // JavaScript para obtener las pistas de audio disponibles (buscando en iframes también)
        val script = """
            (function() {
                // Buscar video en la página principal
                let video = document.querySelector('video');
                
                // Si no hay video, buscar en iframes
                if (!video) {
                    const iframes = document.querySelectorAll('iframe');
                    for (let iframe of iframes) {
                        try {
                            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                            video = iframeDoc.querySelector('video');
                            if (video) break;
                        } catch (e) {
                            // Cross-origin iframe, no podemos acceder
                            console.log('No se puede acceder al iframe:', e);
                        }
                    }
                }
                
                if (!video) {
                    return JSON.stringify({
                        error: 'No se encontró el reproductor de video. El reproductor puede estar en un iframe de otro dominio (cross-origin) al que no podemos acceder por seguridad.'
                    });
                }
                
                const tracks = video.audioTracks;
                if (!tracks || tracks.length === 0) {
                    return JSON.stringify({
                        error: 'El reproductor no expone pistas de audio. Esto es común con vipstream y otros servidores que no permiten cambiar el audio.'
                    });
                }
                
                const result = {
                    tracks: [],
                    currentTrack: -1
                };
                
                for (let i = 0; i < tracks.length; i++) {
                    const t = tracks[i];
                    result.tracks.push({
                        index: i,
                        language: t.language || 'unknown',
                        label: t.label || 'Pista ' + (i + 1),
                        enabled: t.enabled
                    });
                    if (t.enabled) {
                        result.currentTrack = i;
                    }
                }
                
                return JSON.stringify(result);
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(script) { result ->
            handler.post {
                try {
                    // Remover comillas del resultado
                    val jsonStr = result?.trim('"')?.replace("\\\"", "\"")?.replace("\\n", "") ?: "{}"
                    Log.d(LOG_TAG, "Audio tracks result: $jsonStr")
                    
                    if (jsonStr.contains("\"error\"")) {
                        // Extraer mensaje de error
                        val errorMsg = jsonStr.substringAfter("\"error\":\"").substringBefore("\"")
                        showAudioErrorDialog(errorMsg)
                    } else {
                        // Parsear las pistas manualmente
                        val tracks = mutableListOf<AudioTrack>()
                        var currentTrack = -1
                        
                        // Buscar currentTrack
                        val currentMatch = Regex("\"currentTrack\":(\\d+)").find(jsonStr)
                        if (currentMatch != null) {
                            currentTrack = currentMatch.groupValues[1].toInt()
                        }
                        
                        // Buscar todas las pistas
                        val trackMatches = Regex("\\{\"index\":(\\d+),\"language\":\"([^\"]*)\",\"label\":\"([^\"]*)\",\"enabled\":(true|false)\\}").findAll(jsonStr)
                        for (match in trackMatches) {
                            val index = match.groupValues[1].toInt()
                            val language = match.groupValues[2]
                            val label = match.groupValues[3]
                            tracks.add(AudioTrack(index, language, label))
                        }
                        
                        if (tracks.isEmpty()) {
                            showAudioErrorDialog("No se detectaron pistas de audio")
                        } else {
                            showAudioTrackDialog(webView, tracks, currentTrack)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(LOG_TAG, "Error parsing audio tracks: ${e.message}")
                    showAudioErrorDialog("Error al obtener pistas de audio: ${e.message}")
                }
            }
        }
    }
    
    private data class AudioTrack(val index: Int, val language: String, val label: String)
    
    private fun showAudioErrorDialog(message: String) {
        val dialog = android.app.AlertDialog.Builder(this)
        dialog.setTitle("Pistas de Audio")
        dialog.setMessage(message + "\n\nEl reproductor actual no permite cambiar el audio manualmente. Esto es una limitación del servidor que usa multiembed.mov (normalmente vipstream).")
        dialog.setPositiveButton("OK", null)
        dialog.show()
    }
    
    private fun showAudioTrackDialog(webView: WebView, tracks: List<AudioTrack>, currentTrack: Int) {
        val dialog = android.app.AlertDialog.Builder(this)
        dialog.setTitle("Seleccionar Audio")
        
        val trackLabels = tracks.map { track ->
            val current = if (track.index == currentTrack) " ?" else ""
            "${track.label} (${track.language})$current"
        }.toTypedArray()
        
        dialog.setItems(trackLabels) { _, which ->
            val selectedTrack = tracks[which]
            changeAudioTrack(webView, selectedTrack.index)
        }
        
        dialog.setNegativeButton("Cancelar", null)
        dialog.show()
    }
    
    private fun changeAudioTrack(webView: WebView, trackIndex: Int) {
        val script = """
            (function() {
                const video = document.querySelector('video');
                if (!video || !video.audioTracks) return false;
                
                const tracks = video.audioTracks;
                if (trackIndex < 0 || trackIndex >= tracks.length) return false;
                
                // Desactivar todas las pistas
                for (let i = 0; i < tracks.length; i++) {
                    tracks[i].enabled = false;
                }
                
                // Activar la pista seleccionada
                tracks[$trackIndex].enabled = true;
                
                console.log('? KotaTV: Audio cambiado a pista', $trackIndex);
                return true;
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(script) { result ->
            handler.post {
                if (result == "true") {
                    android.widget.Toast.makeText(this, "Audio cambiado", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    android.widget.Toast.makeText(this, "No se pudo cambiar el audio", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configurePlayerWebView(webView: WebView) {
        webView.setBackgroundColor(Color.BLACK)
        webView.settings.apply {
            javaScriptEnabled = true
            userAgentString = COMPATIBLE_USER_AGENT
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            setGeolocationEnabled(false)
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                isAlgorithmicDarkeningAllowed = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
        }
        webView.isLongClickable = false
        webView.setOnLongClickListener { true }
        webView.removeJavascriptInterface("searchBoxJavaBridge_")
        webView.removeJavascriptInterface("accessibility")
        webView.removeJavascriptInterface("accessibilityTraversal")
        webView.addJavascriptInterface(VideoProgressBridge(), "KotaProgressBridge")
        webView.setDownloadListener { _, _, _, _, _ -> Unit }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handlePlayerNavigation(request.url.toString(), request.isForMainFrame)
            }

            @Deprecated("Deprecated in Android")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handlePlayerNavigation(url, isForMainFrame = true)
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                proxyMediaResource(url)?.let { return it }
                // Interceptar playlists HLS para eliminar segmentos de anuncio pre-roll
                stripAdSegmentsFromM3u8(url)?.let { return it }
                return if (shouldBlockResource(request, url)) emptyResponse() else null
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                Log.d(LOG_TAG, "?? Player onPageStarted: $url")
                // Inyectar ANTES de que el reproductor ejecute su código
                // Esto es crítico para bloquear el pre-roll de Nupload
                injectNoPopupGuards(view)
                injectSpanishAudioSelector(view)
                injectExternalSubtitleTrack(view)
                injectVideoProgressTracker(view)
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String) {
                Log.d(LOG_TAG, "? Player onPageFinished: $url")
                injectNoPopupGuards(view)
                injectSpanishAudioSelector(view)
                injectExternalSubtitleTrack(view)
                injectVideoProgressTracker(view)
                
                // Debug: verificar si hay contenido en la página
                view.evaluateJavascript("""
                    (function() {
                        const info = {
                            title: document.title,
                            bodyText: document.body ? document.body.innerText.substring(0, 200) : 'NO BODY',
                            iframes: document.querySelectorAll('iframe').length,
                            videos: document.querySelectorAll('video').length,
                            bodyHTML: document.body ? document.body.innerHTML.substring(0, 500) : 'NO HTML'
                        };
                        return JSON.stringify(info);
                    })();
                """.trimIndent()) { result ->
                    Log.d(LOG_TAG, "?? Page content info: $result")
                }
                
                super.onPageFinished(view, url)
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                Log.e(LOG_TAG, "? SSL Error: ${error.primaryError} - ${error.url}")
                handler.cancel()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    Log.e(LOG_TAG, "? Player main frame error ${error.errorCode}: ${error.description} - URL: ${request.url}")
                }
                super.onReceivedError(view, request, error)
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame) {
                    Log.e(LOG_TAG, "? HTTP Error ${errorResponse.statusCode}: ${errorResponse.reasonPhrase} - URL: ${request.url}")
                }
                super.onReceivedHttpError(view, request, errorResponse)
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                Log.w(LOG_TAG, "WebView render process gone (crashed=${detail.didCrash()})")
                // Si hay un torrent activo descargando/reproduciendo, NO volver al catálogo.
                // Simplemente recrear el WebView silenciosamente.
                if (torrentStreamManager != null || currentTorrentVideoUrl != null) {
                    handler.post {
                        try {
                            rootView.removeView(view)
                            view.destroy()
                        } catch (_: Throwable) {}
                        playbackWebView = null
                        // Recrear WebView vacío para que el overlay de torrent siga visible
                        val newWebView = WebView(this@MainActivity).also { playbackWebView = it }
                        configurePlayerWebView(newWebView)
                        val overlayIndex = torrentOverlayView?.let { rootView.indexOfChild(it) } ?: -1
                        val insertAt = if (overlayIndex > 0) overlayIndex else 0
                        rootView.addView(newWebView, insertAt, FrameLayout.LayoutParams(-1, -1))
                        newWebView.visibility = View.GONE
                    }
                    return true
                }
                destroyPlayerWebView()
                showCatalog()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage): Boolean {
                Log.d(LOG_TAG, "JS Console [${consoleMessage.messageLevel()}]: ${consoleMessage.message()} (${consoleMessage.sourceId()}:${consoleMessage.lineNumber()})")
                return true
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                return false
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }.toTypedArray()
                if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, false, false)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                fullscreenView = view
                fullscreenCallback = callback
                rootView.addView(view, FrameLayout.LayoutParams(-1, -1))
                playbackWebView?.visibility = View.GONE
                enterImmersiveMode()
            }

            override fun onHideCustomView() {
                exitFullscreenVideo()
            }
        }
    }

    private fun handlePlayerNavigation(url: String, isForMainFrame: Boolean): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (isLocalTorrentUrl(uri)) return false
        if (scheme in internalSchemes) return false
        if (!isForMainFrame) return false
        if (scheme in blockedExternalSchemes || scheme != "https") {
            return true
        }
        if (!isAllowedPlaybackMainUrl(url)) {
            Log.w(LOG_TAG, "Blocked main navigation outside playback hosts: $url")
            return true
        }
        return false
    }

    private fun isLocalTorrentUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase().orEmpty()
        val host = uri.host?.lowercase().orEmpty()
        return scheme == "http" && host in LOCAL_TORRENT_HOSTS
    }

    private fun isAllowedPlaybackMainUrl(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase()?.removePrefix("www.") ?: return false
        if (host in playbackHosts || isAutoEmbedHost(host)) return true
        val cleanUrl = url.lowercase()
        if (blockedFileExtensions.any { cleanUrl.substringBefore('?').endsWith(it) }) return false
        if (isSuspicious(host, cleanUrl)) return false
        return selectedHost.hostAliases.any { host == it.removePrefix("www.") || host.endsWith("." + it.removePrefix("www.")) }
    }

    private fun isAutoEmbedHost(host: String): Boolean {
        val normalized = host.lowercase().removePrefix("www.")
        return AUTO_EMBED_MAIN_HOSTS.any { normalized == it.removePrefix("www.") } ||
            PLAYER_BRIDGE_HOSTS.any { normalized == it.removePrefix("www.") || normalized.endsWith("." + it.removePrefix("www.")) }
    }

    private fun isAutoEmbedMainHost(host: String): Boolean {
        val normalized = host.lowercase().removePrefix("www.")
        return AUTO_EMBED_MAIN_HOSTS.any { normalized == it.removePrefix("www.") }
    }

    private fun shouldBlockResource(request: WebResourceRequest, url: String): Boolean {
        val method = request.method.uppercase()
        if (method !in setOf("GET", "HEAD")) return false
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme in internalSchemes) return false
        if (isLocalTorrentUrl(uri)) return false
        if (scheme in blockedExternalSchemes) {
            Log.d(LOG_TAG, "?? Bloqueado esquema externo: $url")
            return true
        }
        if (scheme != "https") {
            Log.d(LOG_TAG, "?? Bloqueado esquema no-HTTPS: $url")
            return true
        }
        val host = uri.host?.lowercase().orEmpty()
        val cleanUrl = url.lowercase()
        if (blockedFileExtensions.any { cleanUrl.substringBefore('?').endsWith(it) }) {
            Log.d(LOG_TAG, "?? Bloqueado extensión de archivo: $url")
            return true
        }
        if (isSuspicious(host, cleanUrl)) {
            Log.w(LOG_TAG, "?? AD BLOQUEADO: $url")
            return true
        }
        return !isAllowedPlaybackResourceHost(host) && !isLikelyMediaResource(cleanUrl)
    }

    private fun isSuspicious(host: String, cleanUrl: String): Boolean {
        val normalizedHost = host.lowercase().removePrefix("www.")
        return suspiciousHostParts.any { normalizedHost.contains(it) } || suspiciousUrlParts.any { cleanUrl.contains(it) }
    }

    private fun isAllowedPlaybackResourceHost(host: String): Boolean {
        val normalized = host.lowercase().removePrefix("www.")
        return normalized in playbackHosts ||
            isAutoEmbedHost(normalized) ||
            selectedHost.hostAliases.any { normalized == it.removePrefix("www.") || normalized.endsWith("." + it.removePrefix("www.")) }
    }

    private fun isLikelyMediaResource(cleanUrl: String): Boolean {
        val path = cleanUrl.substringBefore('?')
        return listOf(".m3u8", ".mp4", ".m4s", ".ts", ".webm", ".vtt", ".mpd").any { path.endsWith(it) } ||
            listOf("m3u8", "video=", "mime=video", "content-type=video", "/hls/", "/dash/").any { cleanUrl.contains(it) }
    }

    /**
     * Descarga un playlist HLS (.m3u8) y elimina los segmentos de anuncio pre-roll.
     * Nupload y otros hosts insertan el anuncio como bloque DISCONTINUITY al inicio,
     * antes del contenido real. Lo detectamos por:
     * - Segmentos con duración muy corta (< 4s) al inicio antes de un DISCONTINUITY
     * - URLs de segmentos que contienen patrones de anuncio
     * - Presencia de etiquetas #EXT-X-DATERANGE o #EXT-X-CUE con tipo AD
     */
    private fun stripAdSegmentsFromM3u8(url: String): WebResourceResponse? {
        val cleanUrl = url.lowercase()
        val path = cleanUrl.substringBefore('?')
        if (!path.endsWith(".m3u8") && !cleanUrl.contains("m3u8")) return null
        
        Log.d(LOG_TAG, "?? Interceptando M3U8: $url")
        
        // Solo interceptar playlists de media (con segmentos), no master playlists
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000  // Reducido de 8000 para carga más rápida
                readTimeout = 7000     // Reducido de 10000 para carga más rápida
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                Log.w(LOG_TAG, "? M3U8 HTTP $code: $url")
                return null
            }
            val content = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            // Si es master playlist (contiene #EXT-X-STREAM-INF), no modificar
            if (content.contains("#EXT-X-STREAM-INF")) {
                Log.d(LOG_TAG, "?? M3U8 Master playlist (no modificar): $url")
                return WebResourceResponse(
                    "application/vnd.apple.mpegurl", "utf-8", 200, "OK",
                    mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"),
                    content.byteInputStream()
                )
            }

            val cleaned = removeAdSegments(content)
            if (cleaned == content) {
                Log.d(LOG_TAG, "? M3U8 sin anuncios detectados: $url")
                return null // Sin cambios, dejar pasar normal
            }

            Log.w(LOG_TAG, "?? M3U8 PRE-ROLL ELIMINADO de: $url")
            WebResourceResponse(
                "application/vnd.apple.mpegurl", "utf-8", 200, "OK",
                mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"),
                cleaned.byteInputStream()
            )
        } catch (e: Throwable) {
            Log.e(LOG_TAG, "? Error procesando M3U8 $url", e)
            null
        }
    }

    private fun removeAdSegments(m3u8: String): String {
        val lines = m3u8.lines().toMutableList()
        val result = mutableListOf<String>()
        var i = 0
        var inAdBlock = false
        var segmentCount = 0

        // Patrones que indican un segmento de anuncio
        val adSegmentPatterns = listOf(
            "xbet", "1xbet", "pikashow", "realpikashowapk",
            "/ad/", "/ads/", "/preroll/", "/pre-roll/",
            "adserver", "advert", "galaksion", "monetag"
        )

        while (i < lines.size) {
            val line = lines[i]
            val lineLower = line.lowercase()

            // Detectar inicio de bloque de anuncio por etiquetas explícitas
            if (lineLower.contains("#ext-x-daterange") && (lineLower.contains("ad") || lineLower.contains("scte"))) {
                inAdBlock = true
                i++; continue
            }
            if (lineLower.contains("#ext-oatcls-scte35") || lineLower.contains("#ext-x-cue-out") ||
                lineLower.contains("scte35") || (lineLower.contains("#ext-x-ad") )) {
                inAdBlock = true
                i++; continue
            }
            // Fin del bloque de anuncio
            if (inAdBlock && (lineLower.contains("#ext-x-cue-in") || lineLower.contains("#ext-x-discontinuity"))) {
                inAdBlock = false
                i++; continue
            }

            // Bloque EXTINF + URL de segmento
            if (line.startsWith("#EXTINF:")) {
                val duration = line.removePrefix("#EXTINF:").substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                val segUrl = if (i + 1 < lines.size) lines[i + 1] else ""
                val segUrlLower = segUrl.lowercase()

                val isAdByUrl = adSegmentPatterns.any { segUrlLower.contains(it) }
                // Segmentos muy cortos al inicio (< 3s) antes de que haya contenido real son anuncios
                val isAdByDuration = duration < 3.0 && segmentCount < 5 && !segUrl.startsWith("#")

                if (inAdBlock || isAdByUrl || isAdByDuration) {
                    // Saltar este segmento (EXTINF + URL)
                    i += 2
                    continue
                }
                segmentCount++
            }

            if (!inAdBlock) result.add(line)
            i++
        }

        // Limpiar DISCONTINUITY huérfanos al inicio
        val firstContentIdx = result.indexOfFirst { it.startsWith("#EXTINF:") }
        if (firstContentIdx > 0) {
            val cleaned = result.toMutableList()
            var j = firstContentIdx - 1
            while (j >= 0 && cleaned[j].startsWith("#EXT-X-DISCONTINUITY")) {
                cleaned.removeAt(j)
                j--
            }
            return cleaned.joinToString("\n")
        }

        return result.joinToString("\n")
    }

    private fun proxyMediaResource(url: String): WebResourceResponse? {
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase()?.removePrefix("www.") ?: return null
        if (host !in MEDIA_PROXY_HOSTS) return null
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000  // Mantener para media proxy (puede ser más lento)
                readTimeout = 15000    // Reducido de 20000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
                setRequestProperty("Referer", "https://streamingnow.mov/")
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val mimeType = when {
                url.substringBefore('?').endsWith(".json", ignoreCase = true) -> "application/vnd.apple.mpegurl"
                else -> connection.contentType?.substringBefore(";")?.ifBlank { null } ?: "application/octet-stream"
            }
            WebResourceResponse(
                mimeType,
                null,
                code,
                connection.responseMessage ?: if (code in 200..299) "OK" else "Error",
                mapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Access-Control-Allow-Methods" to "GET, HEAD, OPTIONS",
                    "Access-Control-Allow-Headers" to "*",
                    "Cache-Control" to "no-store"
                ),
                stream ?: ByteArrayInputStream(ByteArray(0))
            )
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo cargar recurso de video $url", error)
            null
        }
    }

    private fun injectNoPopupGuards(view: WebView) {
        val script = """
            (() => {
                if (window.__kotaGuard) return;
                window.__kotaGuard = true;

                const hideElement = (el) => {
                    if (!el || el.__kotaHiddenServersButton) return;
                    el.__kotaHiddenServersButton = true;
                    el.style.setProperty('display', 'none', 'important');
                    el.style.setProperty('visibility', 'hidden', 'important');
                    el.style.setProperty('pointer-events', 'none', 'important');
                    el.setAttribute('aria-hidden', 'true');
                };

                const looksLikeServersButton = (el) => {
                    if (!el || el === document.body || el === document.documentElement) return false;
                    const tag = String(el.tagName || '').toLowerCase();
                    const role = String(el.getAttribute('role') || '').toLowerCase();
                    const text = String(el.innerText || el.textContent || '').trim().toLowerCase();
                    const cls = String(el.className || '').toLowerCase();
                    const id = String(el.id || '').toLowerCase();
                    const aria = String(el.getAttribute('aria-label') || '').toLowerCase();
                    const isControl = ['button', 'a'].includes(tag) || role === 'button' || el.onclick || cls.includes('btn');
                    const namesServer = text === 'servers' || text === 'server' || aria.includes('servers') ||
                        aria.includes('server') || cls.includes('servers') || id.includes('servers') ||
                        cls.includes('server-btn') || id.includes('server-btn');

                    if (isControl && namesServer) return true;

                    const style = window.getComputedStyle(el);
                    const rect = el.getBoundingClientRect();
                    const nearTopLeft = rect.width > 36 && rect.width < 220 && rect.height > 22 && rect.height < 80 &&
                        rect.left >= 0 && rect.left < Math.min(260, window.innerWidth * 0.45) &&
                        rect.top >= 0 && rect.top < Math.min(140, window.innerHeight * 0.25);
                    const purpleLike = /rgb\((8[0-9]|9[0-9]|1[0-7][0-9]|18[0-9]),\s*(2[0-9]|3[0-9]|4[0-9]|5[0-9]|6[0-9]),\s*(1[2-9][0-9]|2[0-5][0-9])\)/.test(style.backgroundColor);

                    return nearTopLeft && isControl && (namesServer || (purpleLike && text.includes('servers')));
                };

                const hideServersButton = () => {
                    if (!document.head.querySelector('style[data-kota-hide-servers]')) {
                        const style = document.createElement('style');
                        style.setAttribute('data-kota-hide-servers', 'true');
                        style.textContent = `
                            .servers-button,
                            [id*="servers" i],
                            [class*="servers" i],
                            [aria-label*="servers" i],
                            button[class*="server" i],
                            a[class*="server" i] {
                                display: none !important;
                                visibility: hidden !important;
                                pointer-events: none !important;
                            }
                        `;
                        document.head.appendChild(style);
                    }

                    document.querySelectorAll('button, a, [role="button"], div, span').forEach(el => {
                        if (looksLikeServersButton(el)) hideElement(el);
                    });

                    document.querySelectorAll('iframe').forEach(frame => {
                        try {
                            const doc = frame.contentDocument;
                            if (!doc) return;
                            doc.querySelectorAll('button, a, [role="button"], div, span').forEach(el => {
                                if (looksLikeServersButton(el)) hideElement(el);
                            });
                        } catch(e) {}
                    });
                };
                
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', hideServersButton);
                } else {
                    hideServersButton();
                }
                setInterval(hideServersButton, 600);
                new MutationObserver(hideServersButton).observe(document.documentElement, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['class', 'style', 'aria-label']
                });

                const noop = () => null;
                window.open = noop;
                window.print = noop;
                try { Object.defineProperty(window, 'open', { value: noop, writable: false, configurable: false }); } catch(e) {}

                try { Object.defineProperty(navigator, 'serviceWorker', { get: () => undefined }); } catch(e) {}
                try { Object.defineProperty(window, 'Notification', { get: () => undefined }); } catch(e) {}

                const popKeys = ['popundersPerIP','topmostLayer','minBid','siteId','defaultPerDay'];
                popKeys.forEach(k => {
                    try { Object.defineProperty(window, k, { get: () => 0, set: () => {}, configurable: false }); } catch(e) {}
                });

                const AD_SCRIPT_PATTERNS = [
                    'synedawtit','cdn4ads','sfbyctnfokzd','rxqtuwahzmb',
                    'salac.min','palac.min','lBacon','cBacon',
                    'hilltopads','trafficjunky','juicyads','exoclick',
                    'popads','popcash','adsterra','propellerads',
                    'monetag','adnium','trafficstars','clickadu',
                    'imasdk.googleapis','pagead2.googlesyndication',
                    'pubads.g.doubleclick','securepubads'
                ];
                const _origCreate = document.createElement.bind(document);
                document.createElement = function(tag) {
                    const el = _origCreate(tag);
                    if (tag && tag.toLowerCase() === 'script') {
                        const origSrcDesc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                        let _src = '';
                        Object.defineProperty(el, 'src', {
                            get: () => _src,
                            set: (val) => {
                                const v = String(val || '').toLowerCase();
                                if (AD_SCRIPT_PATTERNS.some(p => v.includes(p))) { el.type = 'text/blocked'; return; }
                                _src = val;
                                if (origSrcDesc && origSrcDesc.set) origSrcDesc.set.call(el, val);
                            },
                            configurable: true
                        });
                    }
                    return el;
                };

                const blockNav = (e) => {
                    const t = e.target;
                    if (!t) return;
                    const a = t.closest ? t.closest('a') : null;
                    if (a) {
                        const href = (a.getAttribute('href') || '').trim();
                        const tgt = (a.getAttribute('target') || '').trim();
                        if (tgt && tgt !== '_self') a.setAttribute('target', '_self');
                        if (/^(intent|market|mailto|tel|sms|whatsapp|tg|magnet|javascript):/i.test(href)) {
                            e.preventDefault(); e.stopImmediatePropagation(); return;
                        }
                    }
                    const onclick = t.getAttribute ? t.getAttribute('onclick') : null;
                    if (onclick && /window\.open|popunder|pop_under/i.test(onclick)) {
                        e.preventDefault(); e.stopImmediatePropagation();
                    }
                };
                document.addEventListener('click', blockNav, true);
                document.addEventListener('touchend', blockNav, true);
                document.addEventListener('mousedown', blockNav, true);

                const _origST = window.setTimeout;
                const _origSI = window.setInterval;
                window.setTimeout = function(fn, delay, ...args) {
                    if (typeof fn === 'string' && /window\.open|popunder/i.test(fn)) return 0;
                    return _origST(fn, delay, ...args);
                };
                window.setInterval = function(fn, delay, ...args) {
                    if (typeof fn === 'string' && /window\.open|popunder/i.test(fn)) return 0;
                    return _origSI(fn, delay, ...args);
                };

                document.addEventListener('visibilitychange', (e) => { e.stopImmediatePropagation(); }, true);
                window.addEventListener('blur', (e) => { e.stopImmediatePropagation(); }, true);
                window.addEventListener('focus', (e) => { e.stopImmediatePropagation(); }, true);
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun injectSpanishAudioSelector(view: WebView) {
        val script = """
            (() => {
                if (window.__kotaAudioSelectorInstalled) return;
                window.__kotaAudioSelectorInstalled = true;

                console.log('?? KotaTV: Selector de audio español activado');

                const LANG_ES = ['es', 'esp', 'spa', 'es-es', 'castellano', 'español', 'espanol', 'spanish', 'spain'];
                const LANG_ES_FALLBACK = ['es-419', 'es-mx', 'es-ar', 'es-co', 'es-cl', 'es-pe', 'es-ve', 'latino', 'latin', 'lat'];

                function isSpanishES(str) {
                    if (!str) return false;
                    const s = String(str).toLowerCase().trim();
                    return LANG_ES.some(l => s === l || s.startsWith(l + '-') || s.includes(l) || s.includes('spain'));
                }
                function isSpanishLatino(str) {
                    if (!str) return false;
                    const s = String(str).toLowerCase().trim();
                    return LANG_ES_FALLBACK.some(l => s === l || s.startsWith(l) || s.includes(l));
                }
                function isSpanish(str) { return isSpanishES(str) || isSpanishLatino(str); }

                // -- BLOQUEO AGRESIVO DE ANUNCIOS ---------------------------------
                const AD_PATTERNS = [
                    /1xbet/i, /xbet/i, /1x-bet/i, /1xstavka/i, /xbet\.com/i,
                    /1xbet\.com/i, /1xbet\.mobi/i, /1xbet\.tv/i,
                    /\/ads?\//i, /\/advert/i, /\/preroll/i, /\/pre-roll/i,
                    /\/vast/i, /\/vpaid/i, /adserver/i, /ad-server/i,
                    /doubleclick/i, /googlesyndication/i, /googleadservices/i,
                    /realpikashowapk/i, /pikashow/i,
                    /galaksion/i, /monetag/i, /cdn4ads/i, /synedawtit/i,
                    /vidoza\.net\/ad/i, /vidozacdn/i, /vidoza-ad/i,
                    /popunder/i, /popup/i, /banner/i, /sponsor/i
                ];

                function isAdUrl(url) {
                    if (!url) return false;
                    const urlStr = String(url).toLowerCase();
                    return AD_PATTERNS.some(p => p.test(urlStr));
                }

                // Bloquear carga de anuncios en video
                function blockAdInVideo(video) {
                    if (!video || video.__kotaAdBlocked) return;
                    video.__kotaAdBlocked = true;

                    const origPlay = video.play;
                    video.play = function() {
                        const src = this.currentSrc || this.src || '';
                        if (isAdUrl(src)) {
                            console.log('?? KotaTV: Anuncio bloqueado:', src);
                            this.pause();
                            this.currentTime = this.duration || 999999;
                            return Promise.resolve();
                        }
                        return origPlay.apply(this, arguments);
                    };

                    video.addEventListener('loadstart', function() {
                        const src = this.currentSrc || this.src || '';
                        if (isAdUrl(src)) {
                            console.log('?? KotaTV: Anuncio bloqueado en loadstart:', src);
                            this.pause();
                            this.src = '';
                        }
                    }, true);

                    video.addEventListener('play', function() {
                        const src = this.currentSrc || this.src || '';
                        if (isAdUrl(src) || (this.duration > 0 && this.duration < 90)) {
                            console.log('?? KotaTV: Anuncio detectado y pausado');
                            this.pause();
                            this.currentTime = this.duration || 999999;
                        }
                    }, true);
                }

                // -- SELECCIÓN AGRESIVA DE AUDIO ESPAÑOL --------------------------
                function forceSpanishAudio(video) {
                    if (!video) return false;
                    
                    // HTML5 AudioTracks
                    const tracks = video.audioTracks;
                    if (tracks && tracks.length > 1) {
                        console.log('?? KotaTV: Detectadas', tracks.length, 'pistas de audio');
                        let esIdx = -1, latinoIdx = -1;
                        
                        for (let i = 0; i < tracks.length; i++) {
                            const t = tracks[i];
                            const lang = String(t.language || '').toLowerCase();
                            const label = String(t.label || '').toLowerCase();
                            const id = String(t.id || '').toLowerCase();
                            
                            console.log('  Pista', i, ':', lang, label, id, t.enabled ? '(activa)' : '');
                            
                            if (isSpanishES(lang) || isSpanishES(label) || isSpanishES(id)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0 && (isSpanishLatino(lang) || isSpanishLatino(label) || isSpanishLatino(id))) {
                                latinoIdx = i;
                            }
                        }
                        
                        const target = esIdx >= 0 ? esIdx : latinoIdx;
                        if (target >= 0) {
                            console.log('? KotaTV: Seleccionando pista española:', target);
                            for (let i = 0; i < tracks.length; i++) {
                                tracks[i].enabled = (i === target);
                            }
                            return true;
                        }
                    }
                    return false;
                }

                function trackLooksSpanish(track) {
                    if (!track) return false;
                    const values = [
                        track.language, track.srclang, track.lang,
                        track.label, track.name, track.id
                    ];
                    return values.some(v => isSpanishES(v)) || values.some(v => isSpanishLatino(v));
                }

                function forceSpanishSubtitles(video) {
                    if (!video) return false;
                    let found = false;

                    const domTracks = video.querySelectorAll ? video.querySelectorAll('track') : [];
                    domTracks.forEach(track => {
                        const kind = String(track.kind || '').toLowerCase();
                        if (kind && kind !== 'subtitles' && kind !== 'captions') return;
                        if (trackLooksSpanish(track)) {
                            track.default = true;
                            found = true;
                        } else {
                            track.default = false;
                        }
                    });

                    const tracks = video.textTracks;
                    if (!tracks || tracks.length === 0) return found;

                    let esIdx = -1, latinoIdx = -1;
                    for (let i = 0; i < tracks.length; i++) {
                        const t = tracks[i];
                        const kind = String(t.kind || '').toLowerCase();
                        if (kind && kind !== 'subtitles' && kind !== 'captions') continue;
                        if (trackLooksSpanish(t)) {
                            if (isSpanishES(t.language) || isSpanishES(t.label) || isSpanishES(t.id)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0) latinoIdx = i;
                        }
                    }

                    const target = esIdx >= 0 ? esIdx : latinoIdx;
                    if (target >= 0) {
                        console.log('KotaTV: Activando subtitulos en espanol:', target);
                        for (let i = 0; i < tracks.length; i++) {
                            tracks[i].mode = (i === target) ? 'showing' : 'disabled';
                        }
                        return true;
                    }
                    return found;
                }

                function forceHlsJsSpanish() {
                    if (!window.Hls) return false;
                    
                    // Buscar todas las instancias de HLS.js
                    const instances = window.Hls.instances || [];
                    let found = false;
                    
                    instances.forEach(hls => {
                        if (!hls || !hls.audioTracks) return;
                        const tracks = hls.audioTracks;
                        if (tracks.length <= 1) return;
                        
                        console.log('?? KotaTV: HLS.js detectado con', tracks.length, 'pistas');
                        let esIdx = -1, latinoIdx = -1;
                        
                        for (let i = 0; i < tracks.length; i++) {
                            const t = tracks[i];
                            const lang = String(t.lang || t.language || '').toLowerCase();
                            const name = String(t.name || t.label || '').toLowerCase();
                            
                            console.log('  HLS Pista', i, ':', lang, name);
                            
                            if (isSpanishES(lang) || isSpanishES(name)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0 && (isSpanishLatino(lang) || isSpanishLatino(name))) {
                                latinoIdx = i;
                            }
                        }
                        
                        const target = esIdx >= 0 ? esIdx : latinoIdx;
                        if (target >= 0 && hls.audioTrack !== target) {
                            console.log('? KotaTV: HLS.js cambiando a pista:', target);
                            hls.audioTrack = target;
                            
                            // Forzar recarga si es necesario
                            if (hls.audioTrack !== target) {
                                setTimeout(() => { hls.audioTrack = target; }, 100);
                            }
                            
                            // Mantener la selección
                            if (hls.on) {
                                hls.on('hlsAudioTracksUpdated', () => {
                                    if (hls.audioTrack !== target) {
                                        console.log('?? KotaTV: Reseleccionando pista española');
                                        hls.audioTrack = target;
                                    }
                                });
                                hls.on('hlsAudioTrackSwitching', () => {
                                    if (hls.audioTrack !== target) {
                                        console.log('?? KotaTV: Bloqueando cambio de pista');
                                        hls.audioTrack = target;
                                    }
                                });
                            }
                            found = true;
                        }
                    });
                    
                    return found;
                }

                function forceHlsJsSpanishSubtitles() {
                    if (!window.Hls) return false;
                    const instances = window.Hls.instances || [];
                    let found = false;

                    instances.forEach(hls => {
                        if (!hls) return;
                        const tracks = hls.subtitleTracks || [];
                        if (!tracks || tracks.length === 0) return;
                        let esIdx = -1, latinoIdx = -1;
                        for (let i = 0; i < tracks.length; i++) {
                            const t = tracks[i];
                            if (isSpanishES(t.lang) || isSpanishES(t.language) || isSpanishES(t.name) || isSpanishES(t.label)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0 && (isSpanishLatino(t.lang) || isSpanishLatino(t.language) || isSpanishLatino(t.name) || isSpanishLatino(t.label))) {
                                latinoIdx = i;
                            }
                        }
                        const target = esIdx >= 0 ? esIdx : latinoIdx;
                        if (target >= 0) {
                            console.log('KotaTV: HLS.js activando subtitulos:', target);
                            hls.subtitleDisplay = true;
                            hls.subtitleTrack = target;
                            found = true;
                        }
                    });

                    return found;
                }

                function forceVideoJsSpanish() {
                    if (!window.videojs) return false;
                    
                    try {
                        const players = Object.values(window.videojs.players || {});
                        let found = false;
                        
                        players.forEach(p => {
                            if (!p || !p.audioTracks) return;
                            const tracks = p.audioTracks();
                            if (!tracks || tracks.length <= 1) return;
                            
                            console.log('?? KotaTV: Video.js detectado con', tracks.length, 'pistas');
                            let esIdx = -1, latinoIdx = -1;
                            
                            for (let i = 0; i < tracks.length; i++) {
                                const t = tracks[i];
                                if (isSpanishES(t.language) || isSpanishES(t.label)) {
                                    esIdx = i;
                                    break;
                                }
                                if (latinoIdx < 0 && (isSpanishLatino(t.language) || isSpanishLatino(t.label))) {
                                    latinoIdx = i;
                                }
                            }
                            
                            const target = esIdx >= 0 ? esIdx : latinoIdx;
                            if (target >= 0) {
                                console.log('? KotaTV: Video.js cambiando a pista:', target);
                                for (let i = 0; i < tracks.length; i++) {
                                    tracks[i].enabled = (i === target);
                                }
                                found = true;
                            }
                        });
                        
                        return found;
                    } catch(e) {
                        console.error('? KotaTV: Error en Video.js:', e);
                        return false;
                    }
                }

                function forceVideoJsSpanishSubtitles() {
                    if (!window.videojs) return false;

                    try {
                        const players = Object.values(window.videojs.players || {});
                        let found = false;

                        players.forEach(p => {
                            if (!p || !p.remoteTextTracks) return;
                            const tracks = p.remoteTextTracks();
                            if (!tracks || tracks.length === 0) return;

                            let esIdx = -1, latinoIdx = -1;
                            for (let i = 0; i < tracks.length; i++) {
                                const t = tracks[i];
                                const kind = String(t.kind || '').toLowerCase();
                                if (kind && kind !== 'subtitles' && kind !== 'captions') continue;
                                if (isSpanishES(t.language) || isSpanishES(t.label)) {
                                    esIdx = i;
                                    break;
                                }
                                if (latinoIdx < 0 && (isSpanishLatino(t.language) || isSpanishLatino(t.label))) {
                                    latinoIdx = i;
                                }
                            }

                            const target = esIdx >= 0 ? esIdx : latinoIdx;
                            if (target >= 0) {
                                console.log('KotaTV: Video.js activando subtitulos:', target);
                                for (let i = 0; i < tracks.length; i++) {
                                    tracks[i].mode = (i === target) ? 'showing' : 'disabled';
                                }
                                found = true;
                            }
                        });

                        return found;
                    } catch(e) {
                        console.error('KotaTV: Error activando subtitulos Video.js:', e);
                        return false;
                    }
                }

                function forceJwPlayerSpanish() {
                    if (!window.jwplayer) return false;
                    
                    try {
                        const p = window.jwplayer();
                        if (!p || !p.getAudioTracks) return false;
                        
                        const tracks = p.getAudioTracks();
                        if (!tracks || tracks.length <= 1) return false;
                        
                        console.log('?? KotaTV: JWPlayer detectado con', tracks.length, 'pistas');
                        let esIdx = -1, latinoIdx = -1;
                        
                        for (let i = 0; i < tracks.length; i++) {
                            const t = tracks[i];
                            if (isSpanishES(t.language) || isSpanishES(t.label) || isSpanishES(t.name)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0 && (isSpanishLatino(t.language) || isSpanishLatino(t.label) || isSpanishLatino(t.name))) {
                                latinoIdx = i;
                            }
                        }
                        
                        const target = esIdx >= 0 ? esIdx : latinoIdx;
                        if (target >= 0) {
                            console.log('? KotaTV: JWPlayer cambiando a pista:', target);
                            p.setCurrentAudioTrack(target);
                            
                            // Mantener la selección
                            if (p.on) {
                                p.on('audioTrackChanged', () => {
                                    if (p.getCurrentAudioTrack() !== target) {
                                        console.log('?? KotaTV: JWPlayer reseleccionando español');
                                        p.setCurrentAudioTrack(target);
                                    }
                                });
                            }
                            return true;
                        }
                    } catch(e) {
                        console.error('? KotaTV: Error en JWPlayer:', e);
                    }
                    return false;
                }

                function forceJwPlayerSpanishSubtitles() {
                    if (!window.jwplayer) return false;

                    try {
                        const p = window.jwplayer();
                        if (!p || !p.getCaptionsList || !p.setCurrentCaptions) return false;

                        const tracks = p.getCaptionsList();
                        if (!tracks || tracks.length === 0) return false;

                        let esIdx = -1, latinoIdx = -1;
                        for (let i = 0; i < tracks.length; i++) {
                            const t = tracks[i];
                            if (isSpanishES(t.language) || isSpanishES(t.label) || isSpanishES(t.name)) {
                                esIdx = i;
                                break;
                            }
                            if (latinoIdx < 0 && (isSpanishLatino(t.language) || isSpanishLatino(t.label) || isSpanishLatino(t.name))) {
                                latinoIdx = i;
                            }
                        }

                        const target = esIdx >= 0 ? esIdx : latinoIdx;
                        if (target >= 0) {
                            console.log('KotaTV: JWPlayer activando subtitulos:', target);
                            p.setCurrentCaptions(target);
                            return true;
                        }
                    } catch(e) {
                        console.error('KotaTV: Error activando subtitulos JWPlayer:', e);
                    }
                    return false;
                }

                // -- APLICAR TODO -------------------------------------------------
                function applyAll() {
                    const videos = document.querySelectorAll('video');
                    videos.forEach(video => {
                        blockAdInVideo(video);
                        forceSpanishAudio(video);
                        forceSpanishSubtitles(video);
                    });
                    
                    forceHlsJsSpanish();
                    forceHlsJsSpanishSubtitles();
                    forceVideoJsSpanish();
                    forceVideoJsSpanishSubtitles();
                    forceJwPlayerSpanish();
                    forceJwPlayerSpanishSubtitles();
                }

                // Ejecutar inmediatamente y con reintentos agresivos
                applyAll();
                [100, 300, 500, 800, 1200, 1800, 2500, 3500, 5000, 7000, 10000, 15000].forEach(d => {
                    setTimeout(applyAll, d);
                });

                // Observer para nuevos videos
                const observer = new MutationObserver(applyAll);
                observer.observe(document.documentElement, { 
                    childList: true, 
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['src']
                });

                // No desconectar el observer - mantenerlo activo
                console.log('? KotaTV: Sistema de audio español y bloqueo de anuncios activo');
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun normalizeEmbedUrl(rawInput: String): String {
        val extracted = extractNestedUrl(rawInput.trim()).ifBlank { rawInput.trim() }
        if (extracted.isBlank()) return ""
        val httpsUrl = extracted.replace(Regex("^http://", RegexOption.IGNORE_CASE), "https://")
        val uri = Uri.parse(httpsUrl)
        val host = uri.host?.lowercase()?.removePrefix("www.") ?: return httpsUrl
        val path = uri.path.orEmpty()

        fun rebuild(newPath: String): String {
            return uri.buildUpon().encodedPath(newPath).build().toString()
        }

        return when {
            host.contains("nupload.me") && path.startsWith("/watch/") -> rebuild(path.replaceFirst("/watch/", "/iframe/"))
            host.contains("streamtape") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/e/"))
            host.contains("streamtape") && path.startsWith("/watch/") -> rebuild(path.replaceFirst("/watch/", "/e/"))
            host.contains("filemoon") && path.startsWith("/d/") -> rebuild(path.replaceFirst("/d/", "/e/"))
            host.contains("filemoon") && path.startsWith("/f/") -> rebuild(path.replaceFirst("/f/", "/e/"))
            host.contains("streamwish") && path.startsWith("/d/") -> rebuild(path.replaceFirst("/d/", "/e/"))
            host.contains("streamwish") && path.startsWith("/f/") -> rebuild(path.replaceFirst("/f/", "/e/"))
            host.contains("vidhide") && path.startsWith("/d/") -> rebuild(path.replaceFirst("/d/", "/embed/"))
            host.contains("dood") && path.startsWith("/d/") -> rebuild(path.replaceFirst("/d/", "/e/"))
            host.contains("uqload") && path.startsWith("/d/") -> rebuild(path.replaceFirst("/d/", "/embed-"))
            host.contains("mixdrop") && path.startsWith("/f/") -> rebuild(path.replaceFirst("/f/", "/e/"))
            host.contains("voe") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/e/"))
            host.contains("vidoza") && path.startsWith("/download/") -> rebuild(path.replaceFirst("/download/", "/embed-"))
            host.contains("upstream.to") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/embed-"))
            host.contains("mp4upload.com") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/embed-"))
            host.contains("vtube.to") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/e/"))
            host.contains("vudeo") && path.startsWith("/v/") -> rebuild(path.replaceFirst("/v/", "/embed/"))
            else -> httpsUrl
        }
    }

    private fun extractNestedUrl(raw: String): String {
        return try {
            val uri = Uri.parse(raw)
            val keys = listOf("url", "u", "src", "embed", "link", "video", "file", "player")
            for (key in keys) {
                val value = uri.getQueryParameter(key)
                if (!value.isNullOrBlank()) {
                    val decoded = URLDecoder.decode(value, "UTF-8")
                    if (decoded.startsWith("http://") || decoded.startsWith("https://")) return decoded
                }
            }
            ""
        } catch (_: Throwable) {
            ""
        }
    }

    private fun loadAutomaticCatalog() {
        catalogLoading = true
        Thread {
            val loaded = mutableListOf<CatalogItem>()
            CATALOG_TYPES.forEach { type ->
                try {
                    loaded += parseCinemetaCatalogJson(fetchJson(catalogUrl(type)))
                } catch (error: Throwable) {
                    Log.e(LOG_TAG, "No se pudo cargar catálogo $type", error)
                }
            }
            val uniqueItems = loaded.distinctBy { it.id.ifBlank { "${it.type}:${it.imdbId}:${it.tmdbId}:${it.title}" } }
            handler.post {
                catalogLoading = false
                homeCatalogItems = uniqueItems
                catalogItems = uniqueItems
                if (currentScreen == Screen.CATALOG) renderCurrentTab()
            }
        }.start()
    }

    private fun scheduleCatalogSearch(query: String) {
        catalogSearchRunnable?.let { handler.removeCallbacks(it) }
        val cleanQuery = query.trim()
        if (cleanQuery.length < 2) {
            // Cancelar cualquier búsqueda pendiente
            catalogSearchGeneration++
            catalogSearchLoading = false
            catalogItems = homeCatalogItems
            if (currentScreen == Screen.CATALOG && ::catalogContent.isInitialized) renderCatalogItems(cleanQuery)
            return
        }
        val generation = ++catalogSearchGeneration
        catalogSearchLoading = true
        if (currentScreen == Screen.CATALOG && ::catalogContent.isInitialized) renderCatalogItems(cleanQuery)
        val runnable = Runnable { loadCatalogSearch(cleanQuery, generation) }
        catalogSearchRunnable = runnable
        handler.postDelayed(runnable, 300)
    }

    private fun loadCatalogSearch(query: String, generation: Int) {
        Thread {
            val results = mutableListOf<CatalogItem>()

            // 1. Cinemeta (movie + series en paralelo)
            CATALOG_TYPES.forEach { type ->
                try {
                    results += parseCinemetaCatalogJson(fetchJson(catalogSearchUrl(type, query)))
                } catch (error: Throwable) {
                    Log.e(LOG_TAG, "Cinemeta search failed for $type '$query'", error)
                }
            }

            // 2. IMDb suggestions — siempre se ejecuta, complementa a Cinemeta
            try {
                results += searchImdbSuggestions(query)
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "IMDb search failed for '$query'", error)
            }

            val uniqueItems = results.distinctBy { it.id.ifBlank { "${it.type}:${it.imdbId}:${it.tmdbId}:${it.title}" } }

            handler.post {
                // Descartar si ya hay una búsqueda más reciente en curso
                if (generation != catalogSearchGeneration) return@post
                if (currentScreen != Screen.CATALOG || currentNavTab != NavTab.HOME) return@post
                // Descartar si el usuario ya cambió el texto
                if (query != currentSearchQuery().trim()) return@post

                rememberHomeSearch(query)
                catalogSearchLoading = false
                // Actualizar siempre — aunque esté vacío, para mostrar "No hay resultados"
                catalogItems = if (uniqueItems.isNotEmpty()) uniqueItems else homeCatalogItems
                renderCatalogItems(query)
            }
        }.start()
    }

    private fun catalogUrl(type: String): String =
        "$CINEMETA_BASE_URL/catalog/$type/top.json"

    private fun catalogSearchUrl(type: String, query: String): String {
        // Cinemeta usa el formato /search=QUERY.json — el término va en la ruta, no como query param
        // No se puede añadir language= como parámetro adicional en la ruta sin romper la URL
        return "$CINEMETA_BASE_URL/catalog/$type/top/search=${Uri.encode(query)}.json"
    }

    private fun searchImdbSuggestions(query: String): List<CatalogItem> {
        val slug = query.trim().lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
        if (slug.length < 2) return emptyList()
        return try {
            val json = fetchJson("$IMDB_SUGGESTION_BASE_URL/${slug.first()}/$slug.json")
            parseImdbSuggestionJson(json).take(18)
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "No se pudo buscar en IMDb $query", error)
            emptyList()
        }
    }

    private fun parseImdbSuggestionJson(json: String): List<CatalogItem> {
        val array = JSONObject(json).optJSONArray("d") ?: return emptyList()
        val items = mutableListOf<CatalogItem>()
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            catalogItemFromImdbSuggestion(obj)?.let { items.add(it) }
        }
        return items
    }

    private fun catalogItemFromImdbSuggestion(obj: JSONObject): CatalogItem? {
        val imdbId = obj.optString("id").trim()
        val title = obj.optString("l").trim()
        if (!imdbId.startsWith("tt") || title.isBlank()) return null
        val type = if (obj.optString("qid").contains("tv", ignoreCase = true) || obj.optString("q").contains("TV", ignoreCase = true)) "series" else "movie"
        loadCinemetaMeta(type, imdbId)?.let { return it }
        val image = obj.optJSONObject("i")?.optString("imageUrl").orEmpty()
        return CatalogItem(
            id = imdbId,
            title = title,
            originalTitle = title,
            type = type,
            year = obj.optString("y").ifBlank { obj.optString("yr").take(4) },
            runtime = "",
            imdbId = imdbId,
            tmdbId = "",
            rating = "",
            overview = "",
            genres = emptyList(),
            posterUrl = image,
            backgroundUrl = image,
            embeds = emptyMap()
        )
    }

    private fun loadCinemetaMeta(type: String, imdbId: String): CatalogItem? {
        return try {
            val json = fetchJson("$CINEMETA_BASE_URL/meta/$type/$imdbId.json")
            val meta = JSONObject(json).optJSONObject("meta") ?: return null
            catalogItemFromCinemeta(meta)
        } catch (_: Throwable) {
            null
        }
    }

    private fun resolvePlaybackChoice(playbackHost: PlaybackHost, embed: String): PlaybackChoice? {
        val embedHost = Uri.parse(embed).host?.lowercase()?.removePrefix("www.") ?: return null
        if (!isAutoEmbedMainHost(embedHost)) {
            return PlaybackChoice(playbackHost, embed, preferredCastellanoHostScore(playbackHost))
        }
        return try {
            val html = fetchText(embed, "text/html,application/xhtml+xml", AUTO_EMBED_BASE_URL)
            if (isUnavailablePlaybackPage(html)) return null
            val resolved = extractPlaybackUrl(html) ?: embed
            val playerScore = if (resolved != embed) {
                try {
                    castellanoScore(fetchText(resolved, "text/html,application/xhtml+xml", embed))
                } catch (_: Throwable) {
                    0
                }
            } else {
                0
            }
            val totalScore = castellanoScore(html) + playerScore + preferredCastellanoHostScore(playbackHost)
            PlaybackChoice(playbackHost, resolved, totalScore)
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudo resolver reproductor $embed", error)
            null
        }
    }

    private fun isUnavailablePlaybackPage(html: String): Boolean {
        val clean = html.lowercase()
        return listOf("not found", "no streams", "unavailable", "video not found", "embed blocked", "contenido no disponible")
            .any { clean.contains(it) }
    }

    private fun castellanoScore(text: String): Int {
        val clean = text.lowercase()
        // Pistas fuertes de español de España (peso alto)
        val strongSpainHints = listOf(
            "castellano", "español", "espanol", "es-es", "es_es",
            "audio es", "audio esp", "lang=es", "language=es", "locale=es-es",
            "\"es\"", "'es'", "[es]", "(es)", "spa",
            "lang\":\"es\"", "language\":\"es\""
        )
        // Pistas débiles de español genérico
        val weakHints = listOf("spanish", "es,", ",es,", "\"es,", "es-419")
        // Penalización por latino explícito
        val latinoPenalty = listOf("latino", "latin", "es-419", "es-mx", "es-ar", "es-co", "es-cl")
        val penalty = latinoPenalty.count { clean.contains(it) }
        return strongSpainHints.count { clean.contains(it) } * 3 +
               weakHints.count { clean.contains(it) } -
               penalty * 2
    }

    private fun preferredCastellanoHostScore(host: PlaybackHost): Int {
        // Puntuación base por host según su historial de tener castellano.
        // Waaw/Latlat y Netu/HQQ son los más fiables para series populares en castellano.
        // Nupload BLOQUEADO (score -100) por servir anuncios pre-roll agresivos con fotos.
        return when (host.key) {
            "waaw"       -> 3
            "netu"       -> 3
            "streamwish" -> 2
            "filemoon"   -> 2
            "nupload"    -> -100  // BLOQUEADO - anuncios con fotos, NUNCA seleccionar
            "vidmoly"    -> 1
            "upstream"   -> 1
            "mp4upload"  -> 1
            "vtube"      -> 1
            "vudeo"      -> 1
            else         -> 0
        }
    }

    private fun extractPlaybackUrl(html: String): String? {
        val urlPattern = Regex("""https?(?:\\)?:(?:\\)?/(?:\\)?/[^"'<>\\\s]+""")
        return urlPattern.findAll(html)
            .map { match -> match.value.replace("\\/", "/").trim() }
            .firstOrNull { candidate ->
                val host = Uri.parse(candidate).host?.lowercase()?.removePrefix("www.") ?: return@firstOrNull false
                !isAutoEmbedMainHost(host) && isAllowedPlaybackMainUrl(candidate)
            }
    }

    private fun fetchText(
        url: String,
        accept: String,
        referer: String? = null,
        connectTimeoutMs: Int = 6000,
        readTimeoutMs: Int = 8000,
        origin: String? = null
    ): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
            setRequestProperty("Accept", accept)
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("Pragma", "no-cache")
            referer?.let { setRequestProperty("Referer", it) }
            origin?.let { setRequestProperty("Origin", it) }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) throw IOException("HTTP $code from $url")
        return body
    }

    private fun fetchJson(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000  // Reducido de 12000 para carga más rápida
            readTimeout = 8000     // Reducido de 12000 para carga más rápida
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) throw IOException("HTTP $code from $url")
        return body
    }

    private fun parseCinemetaCatalogJson(json: String): List<CatalogItem> {
        val array = JSONObject(json).optJSONArray("metas") ?: return emptyList()
        val items = mutableListOf<CatalogItem>()
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            catalogItemFromCinemeta(obj)?.let { items.add(it) }
        }
        return items
    }

    private fun catalogItemFromCinemeta(obj: JSONObject): CatalogItem? {
        val title = obj.optString("name").trim()
        val imdbId = obj.optString("imdb_id", obj.optString("id")).trim()
        val tmdbId = obj.optString("moviedb_id").trim()
        if (title.isBlank() || (imdbId.isBlank() && tmdbId.isBlank())) return null

        val type = obj.optString("type", "movie").trim().ifBlank { "movie" }
        val year = obj.optString("year").ifBlank { obj.optString("releaseInfo") }.ifBlank {
            obj.optString("released").take(4)
        }

        return CatalogItem(
            id = obj.optString("id").ifBlank { imdbId.ifBlank { "$type:$tmdbId" } },
            title = title,
            originalTitle = obj.optString("originalName").ifBlank { title },
            type = type,
            year = year,
            runtime = obj.optString("runtime"),
            imdbId = imdbId,
            tmdbId = tmdbId,
            rating = obj.optString("imdbRating"),
            overview = obj.optString("description"),
            genres = readStringList(obj, "genres").ifEmpty { readStringList(obj, "genre") },
            posterUrl = obj.optString("poster"),
            backgroundUrl = obj.optString("background"),
            embeds = emptyMap()
        )
    }

    private fun readStringList(obj: JSONObject, key: String): List<String> {
        val array = obj.optJSONArray(key)
        if (array != null) {
            val values = mutableListOf<String>()
            for (i in 0 until array.length()) {
                val value = array.optString(i).trim()
                if (value.isNotBlank()) values.add(value)
            }
            return values
        }
        return obj.optString(key)
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    private fun loadHeroBackdropAsync(imageView: ImageView, item: CatalogItem) {
        val url = item.backgroundUrl.ifBlank { item.posterUrl }
        if (url.isBlank()) return
        loadPosterAsync(
            imageView = imageView,
            url = url,
            reqWidth = resources.displayMetrics.widthPixels.coerceAtLeast(1600),
            reqHeight = 900,
            preferOriginalBackdrop = true
        )
    }

    private fun loadPosterAsync(
        imageView: ImageView,
        url: String,
        reqWidth: Int = 800,
        reqHeight: Int = 800,
        preferOriginalBackdrop: Boolean = false
    ) {
        if (url.isBlank()) return
        
        // Mejorar calidad de imagen reemplazando tamaños pequeños por grandes
        val improvedUrl = (if (preferOriginalBackdrop && url.contains("images.metahub.space/background/")) {
            url
                .replace("/background/small/", "/background/large/")
                .replace("/background/medium/", "/background/large/")
                .replace("/background/original/", "/background/large/")
        } else {
            url
        })
            .replace("/s72-c/", "/s800/")
            .replace("/s113/", "/s800/")
            .replace("/s200/", "/s800/")
            .replace("/s320/", "/s800/")
            .replace("/s400/", "/s800/")
            .replace("/s640/", "/s800/")
            .replace("w200", "w780")
            .replace("w300", "w780")
            .replace("w500", "w780")
            .replace("h300", "h632")
        
        // Marcar el ImageView con la URL para evitar race conditions al reciclar vistas
        imageView.tag = improvedUrl
        // Placeholder gris mientras carga
        imageView.setBackgroundColor(0xFF333333.toInt())
        // Servir desde caché si ya está disponible
        posterCache[improvedUrl]?.let { cached ->
            imageView.setImageBitmap(cached)
            imageView.setBackgroundColor(Color.TRANSPARENT)
            return
        }
        Thread {
            // Lista de URLs a intentar: la mejorada + la original + fallback si es metahub
            val urlsToTry = mutableListOf(improvedUrl)
            if (improvedUrl != url) {
                urlsToTry.add(url)
            }
            if (preferOriginalBackdrop && url.contains("images.metahub.space/background/")) {
                urlsToTry.add(url.replace("/background/small/", "/background/large/").replace("/background/medium/", "/background/large/"))
                urlsToTry.add(url.replace("/background/original/", "/background/medium/"))
            }
            // Si es metahub.space, añadir fallback a TMDB image CDN
            if (url.contains("metahub.space")) {
                val imdbId = Regex("""/(tt\d+)/""").find(url)?.groupValues?.get(1)
                if (imdbId != null) {
                    // Intentar obtener imagen desde IMDB suggestion API como fallback
                    urlsToTry.add("https://img.omdbapi.com/?i=$imdbId&apikey=trilogy&h=632")
                }
            }
            for (tryUrl in urlsToTry) {
                try {
                    // Primera conexión: obtener dimensiones con inJustDecodeBounds
                    val conn1 = (URL(tryUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                        setRequestProperty("Accept", "image/webp,image/png,image/jpeg,image/*")
                    }
                    val code1 = conn1.responseCode
                    if (code1 !in 200..299) {
                        conn1.disconnect()
                        continue
                    }
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    conn1.inputStream.use { BitmapFactory.decodeStream(it, null, opts) }
                    conn1.disconnect()
                    val sampleSize = calculateInSampleSize(opts, reqWidth, reqHeight)
                    // Segunda conexión: decodificar con inSampleSize calculado
                    val conn2 = (URL(tryUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                        setRequestProperty("Accept", "image/webp,image/png,image/jpeg,image/*")
                    }
                    val code2 = conn2.responseCode
                    if (code2 in 200..299) {
                        val opts2 = BitmapFactory.Options().apply {
                            inSampleSize = sampleSize
                            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                        }
                        conn2.inputStream.use { stream ->
                            val bitmap = BitmapFactory.decodeStream(stream, null, opts2)
                            if (bitmap != null) {
                                posterCache[improvedUrl] = bitmap  // cachear con la URL mejorada
                                handler.post {
                                    if (imageView.tag == improvedUrl) {
                                        imageView.setImageBitmap(bitmap)
                                        imageView.setBackgroundColor(Color.TRANSPARENT)
                                    }
                                }
                                conn2.disconnect()
                                return@Thread  // éxito, salir
                            }
                        }
                    }
                    conn2.disconnect()
                } catch (error: Throwable) {
                    Log.w(LOG_TAG, "No se pudo cargar poster $tryUrl", error)
                }
            }
        }.start()
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val height = options.outHeight
        val width = options.outWidth
        if (height <= 0 || width <= 0) return 1
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun destroyPlayerWebView() {
        releaseEmbeddedVlcPlayer()
        stopProgressUpdater()
        cancelTorrentDownloadNotification()
        torrentProgressOverlayEnabled = false
        torrentPlaybackActive = false
        torrentStreamManager?.stopStreaming()
        torrentStreamManager = null
        torrentOverlayView = null
        currentTorrentVideoUrl = null
        playbackTopBar = null
        playbackStatusBarCover = null
        playbackVideoTopInsetPx = 0

        playbackWebView?.let { view ->
            try {
                rootView.removeView(view)
                view.stopLoading()
                view.loadUrl("about:blank")
                view.destroy()
            } catch (_: Throwable) {
            }
        }
        playbackWebView = null
        fullscreenView = null
        fullscreenCallback = null
        exitImmersiveMode()
    }

    private fun releaseEmbeddedVlcPlayer() {
        stopVlcVolumeRepeat()
        stopEmbeddedVlcProgressUpdater()
        if (isEmbeddedVlcFullscreen) {
            exitEmbeddedVlcFullscreen()
        }
        try {
            vlcPlayer?.stop()
        } catch (_: Throwable) {
        }
        try {
            vlcPlayer?.detachViews()
        } catch (_: Throwable) {
        }
        try {
            vlcPlayer?.release()
        } catch (_: Throwable) {
        }
        try {
            vlcLib?.release()
        } catch (_: Throwable) {
        }
        vlcControlsOverlay?.let { overlay ->
            try {
                rootView.removeView(overlay)
            } catch (_: Throwable) {
            }
        }
        vlcVideoLayout?.let { layout ->
            try {
                rootView.removeView(layout)
            } catch (_: Throwable) {
            }
        }
        vlcPlayer = null
        vlcLib = null
        vlcVideoLayout = null
        vlcControlsOverlay = null
        vlcStatusText = null
        vlcPlayPauseButton = null
        vlcFullscreenButton = null
        vlcSeekBar = null
        vlcCurrentTimeText = null
        vlcDurationText = null
        vlcHasRenderedVideo = false
        vlcSoftwareVolumePercent = 100
        isVlcSeekBarDragging = false
        playbackWebView?.visibility = View.VISIBLE
    }

    private fun exitFullscreenVideo() {
        val view = fullscreenView ?: return
        try {
            rootView.removeView(view)
            fullscreenCallback?.onCustomViewHidden()
        } catch (_: Throwable) {
        }
        fullscreenView = null
        fullscreenCallback = null
        playbackWebView?.visibility = View.VISIBLE
        exitImmersiveMode()
    }

    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    private fun exitImmersiveMode() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        applyWindowBars()
    }

    private fun assetExists(name: String): Boolean {
        return try {
            assets.open(name).close()
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun emptyResponse(): WebResourceResponse = WebResourceResponse(
        "text/plain",
        "utf-8",
        204,
        "No Content",
        mapOf("Cache-Control" to "no-store"),
        ByteArrayInputStream(ByteArray(0))
    )

    private fun emptyState(message: String): View {
        return TextView(this).apply {
            text = message
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(24), dp(18), dp(24))
            background = roundedBackground(Color.BLACK, 22f, Color.WHITE, 1)
            if (message == "Loading...") startLoadingTypewriter(this)
        }
    }

    private fun startLoadingTypewriter(view: TextView) {
        val fullText = "Loading..."
        val delayMs = 170L
        val pauseTicks = 5
        val ticker = object : Runnable {
            var index = 0
            var pause = 0

            override fun run() {
                if (!view.isAttachedToWindow) return
                if (index >= fullText.length) {
                    view.text = fullText
                    if (pause++ < pauseTicks) {
                        handler.postDelayed(this, delayMs)
                        return
                    }
                    pause = 0
                    index = 0
                }
                index += 1
                view.text = fullText.take(index)
                handler.postDelayed(this, delayMs)
            }
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                handler.removeCallbacks(ticker)
                ticker.index = 0
                ticker.pause = 0
                handler.post(ticker)
            }

            override fun onViewDetachedFromWindow(v: View) {
                handler.removeCallbacks(ticker)
            }
        })
    }

    private fun roundedBackground(fill: Int, radiusDp: Float, stroke: Int, strokeDp: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
        }
    }

    // ------------------------------------------------------------------------------
    // CONTINUE WATCHING - Guardar y cargar progreso de reproducción
    // ------------------------------------------------------------------------------

    private fun saveContinueWatching() {
        try {
            val prefs = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
            val json = JSONArray()
            continueWatchingItems.take(10).forEach { item ->
                json.put(JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("originalTitle", item.originalTitle)
                    put("type", item.type)
                    put("year", item.year)
                    put("runtime", item.runtime)
                    put("imdbId", item.imdbId)
                    put("tmdbId", item.tmdbId)
                    put("rating", item.rating)
                    put("overview", item.overview)
                    put("genres", JSONArray(item.genres))
                    put("posterUrl", item.posterUrl)
                    put("backgroundUrl", item.backgroundUrl)
                    put("lastWatchedPosition", item.lastWatchedPosition)
                    put("lastWatchedTime", item.lastWatchedTime)
                    put("embeds", JSONObject(item.embeds))
                })
            }
            prefs.edit().putString("continue_watching", json.toString()).apply()
        } catch (e: Throwable) {
            Log.e(LOG_TAG, "Error guardando continue watching", e)
        }
    }

    private fun loadContinueWatching() {
        try {
            val prefs = getSharedPreferences("kotatv_prefs", MODE_PRIVATE)
            val jsonStr = prefs.getString("continue_watching", null) ?: return
            val json = JSONArray(jsonStr)
            continueWatchingItems.clear()
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                val genresArray = obj.getJSONArray("genres")
                val genres = mutableListOf<String>()
                for (j in 0 until genresArray.length()) {
                    genres.add(genresArray.getString(j))
                }
                val embedsObj = obj.getJSONObject("embeds")
                val embeds = mutableMapOf<String, String>()
                embedsObj.keys().forEach { key ->
                    embeds[key] = embedsObj.getString(key)
                }
                continueWatchingItems.add(
                    CatalogItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        originalTitle = obj.getString("originalTitle"),
                        type = obj.getString("type"),
                        year = obj.getString("year"),
                        runtime = obj.getString("runtime"),
                        imdbId = obj.getString("imdbId"),
                        tmdbId = obj.getString("tmdbId"),
                        rating = obj.getString("rating"),
                        overview = obj.getString("overview"),
                        genres = genres,
                        posterUrl = obj.getString("posterUrl"),
                        backgroundUrl = obj.getString("backgroundUrl"),
                        embeds = embeds,
                        lastWatchedPosition = obj.optLong("lastWatchedPosition", 0L),
                        lastWatchedTime = obj.optLong("lastWatchedTime", 0L)
                    )
                )
            }
        } catch (e: Throwable) {
            Log.e(LOG_TAG, "Error cargando continue watching", e)
        }
    }

    private fun addToContinueWatching(item: CatalogItem) {
        // Actualizar timestamp
        item.lastWatchedTime = System.currentTimeMillis()
        // Remover si ya existe
        continueWatchingItems.removeAll { it.id == item.id }
        // Añadir al principio
        continueWatchingItems.add(0, item)
        // Limitar a 10 items
        if (continueWatchingItems.size > 10) {
            continueWatchingItems.removeAt(continueWatchingItems.lastIndex)
        }
        saveContinueWatching()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun color(hex: String): Int = Color.parseColor(hex)
    private fun isWideLayout(): Boolean = resources.configuration.screenWidthDp >= 700

    private fun applyWindowBars() {
        window.statusBarColor = STATUS_BAR_COLOR
        window.navigationBarColor = Color.BLACK
    }

    /** Altura de la barra de estado del sistema en píxeles. */
    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dp(24)
    }

    /** Color azul oscuro de la barra de estado de DownTV. */
    private val STATUS_BAR_COLOR = Color.parseColor("#0D1B3E")

    // ------------------------------------------------------------------------------
    // DEPORTES — streamed.su (servidor mas veterano y actualizado de FMHY)
    // API publica: /api/matches/all, /api/stream/{source}/{id}
    // ------------------------------------------------------------------------------

    private fun canonicalSportName(value: String): String {
        val lower = normalizeLanguageText(value)
        return when {
            listOf("basketball", "basket", "nba", "wnba", "baloncesto").any { lower.contains(it) } -> "basketball"
            listOf(
                "football",
                "soccer",
                "futbol",
                "laliga",
                "la liga",
                "liga",
                "premier",
                "gol ",
                "barca",
                "real madrid",
                "bein sports",
                "mutv"
            ).any { lower.contains(it) } -> "football"
            else -> ""
        }
    }

    private fun onlyFootballAndBasketball(matches: List<SportMatch>): List<SportMatch> {
        return matches.mapNotNull { match ->
            val sport = canonicalSportName("${match.sport} ${match.title} ${match.league}")
            if (sport.isBlank()) null else match.copy(sport = sport)
        }
    }

    private fun loadSportsMatches() {
        if (sportsLoading) return
        sportsLoading = true
        refreshCatalogLayout() // Mostrar "Loading..." inmediatamente
        
        // Cargar SOLO canales IPTV (beIN Sports XTRA en Español y Gol TV)
        Thread {
            try {
                loadIptvSportsMatches("Cargando canales IPTV...")
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Error loading IPTV sports: ${e.message}")
                handler.post {
                    sportsLoading = false
                    if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                        renderCatalogItems(currentSearchQuery())
                    }
                }
            }
        }.start()
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun loadSportsMatchesViaWebView() {
        // Cloudflare bloquea HttpURLConnection desde Android.
        // Usamos un WebView oculto que pasa el challenge JS y luego
        // ejecutamos fetch() desde dentro del WebView para obtener el JSON.
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = COMPATIBLE_USER_AGENT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = false
        }
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onMatchesJson(json: String) {
                if (json.isBlank() || json == "null") return
                processMatchesJson(json)
            }
            @android.webkit.JavascriptInterface
            fun onApiEndpoint(endpoint: String) {
                Log.d(LOG_TAG, "Sports API: $endpoint")
            }
        }, "SportsBridge")
        wv.webViewClient = object : WebViewClient() {
            private var mainPageLoaded = false
            private var apiJsonReceived = false
            override fun onPageFinished(view: WebView, url: String) {
                Log.d(LOG_TAG, "Sports WebView onPageFinished: $url")
                val js = """
                    (function() {
                        try {
                            if (!window.SportsBridge) return 'no_bridge';
                            var title = document.title || '';
                            var bodyText = document.body ? document.body.innerText : '';
                            if (title.toLowerCase().includes('just a moment') || bodyText.toLowerCase().includes('checking your browser')) {
                                return 'cloudflare';
                            }
                            var eventEls = document.querySelectorAll('[data-event-id]');
                            if (eventEls.length === 0) return 'no_events_' + document.querySelectorAll('*').length;
                            var events = [];
                            for (var i = 0; i < eventEls.length; i++) {
                                try {
                                    var el = eventEls[i];
                                    var id = el.getAttribute('data-event-id') || '';
                                    if (!id) continue;
                                    var titleEl = el.querySelector('h3,h4,strong,.event-title,.match-title,.teams,.team-names');
                                    var matchTitle = titleEl ? titleEl.textContent.trim() : '';
                                    if (!matchTitle || matchTitle.length < 3) {
                                        var onclick2 = el.getAttribute('onclick') || '';
                                        var urlMatch = onclick2.match(/links\/([^'",\s]+)/);
                                        if (urlMatch) {
                                            matchTitle = urlMatch[1]
                                                .replace(/-\d+${'$'}/, '')
                                                .replace(/-/g, ' ')
                                                .replace(/\b\w/g, function(c) { return c.toUpperCase(); });
                                        }
                                    }
                                    if (!matchTitle || matchTitle.length < 3) matchTitle = 'Partido ' + id;
                                    var onclick3 = el.getAttribute('onclick') || '';
                                    var linkMatch = onclick3.match(/window\.open\(['"]([^'"]+)/i);
                                    var linkUrl = linkMatch ? new URL(linkMatch[1], location.href).href : '';
                                    var sourceMatch = (linkUrl || onclick3).match(/links\/([^'",\s\/?#]+)/);
                                    var sourceId = sourceMatch ? sourceMatch[1] : id;
                                    var statusText = (el.querySelector('.event-status,[class*="status"]') || el).textContent || '';
                                    statusText = statusText.toLowerCase();
                                    var startTs = parseInt(el.getAttribute('data-start-ts') || '0', 10) || 0;
                                    var liveWindow = parseInt(el.getAttribute('data-live-window') || '14400', 10) || 14400;
                                    var nowTs = Math.floor(Date.now() / 1000);
                                    var isFinished = /finished|final|ended|cancelled|postponed/.test(statusText);
                                    var isLive = (el.className || '').toLowerCase().includes('live') ||
                                                 statusText.includes('live') ||
                                                 (startTs > 0 && nowTs >= (startTs - 900) && nowTs <= (startTs + liveWindow));
                                    if (isFinished || !isLive) continue;
                                    events.push({id: id, title: matchTitle, category: 'sport', league: statusText, popular: true, sources: [{source: 'streamed', id: sourceId, streamUrl: linkUrl}]});
                                } catch(ei) {}
                            }
                            if (events.length > 0) {
                                // Devolver el JSON directamente como valor de retorno
                                // (más fiable que @JavascriptInterface para strings grandes)
                                return JSON.stringify(events.slice(0, 40));
                            }
                            return null;
                        } catch(e) { return 'error_' + e.message; }
                    })();
                """.trimIndent()
                view.evaluateJavascript(js) { result ->
                    Log.d(LOG_TAG, "Sports JS: ${result?.take(50)}")
                    if (result != null && result != "null") {
                        // El resultado puede ser un array JSON directo o un string JSON-encoded
                        val json = when {
                            result.startsWith("[") -> result  // Array JSON directo
                            result.startsWith("\"[") -> {
                                // String JSON-encoded — desescapar
                                try {
                                    org.json.JSONArray(org.json.JSONObject("{\"v\":$result}").getString("v")).toString()
                                } catch (_: Throwable) {
                                    result.removePrefix("\"").removeSuffix("\"")
                                        .replace("\\\"", "\"").replace("\\\\", "\\")
                                }
                            }
                            else -> null
                        }
                        if (json != null && json.startsWith("[")) {
                            processMatchesJson(json)
                        } else if (sportsLoading) {
                            // Reintentar si no hay partidos
                            view.postDelayed({
                                if (sportsLoading) {
                                    view.evaluateJavascript(js) { r2 ->
                                        if (r2 != null && r2 != "null") {
                                            val j2 = if (r2.startsWith("[")) r2
                                            else try {
                                                org.json.JSONArray(org.json.JSONObject("{\"v\":$r2}").getString("v")).toString()
                                            } catch (_: Throwable) { null }
                                            if (j2 != null && j2.startsWith("[")) processMatchesJson(j2)
                                        }
                                    }
                                }
                            }, 3000L)
                        }
                    } else if (sportsLoading) {
                        view.postDelayed({
                            if (sportsLoading) {
                                view.evaluateJavascript(js) { r2 ->
                                    if (r2 != null && r2 != "null") {
                                        val j2 = if (r2.startsWith("[")) r2
                                        else try {
                                            org.json.JSONArray(org.json.JSONObject("{\"v\":$r2}").getString("v")).toString()
                                        } catch (_: Throwable) { null }
                                        if (j2 != null && j2.startsWith("[")) processMatchesJson(j2)
                                    }
                                }
                            }
                        }, 3000L)
                    }
                }
            }
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: android.net.http.SslError) {
                handler.proceed()
            }
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val host = request.url.host?.lowercase() ?: ""
                val url = request.url.toString()
                if (isSportsAdRequest(host, url)) return emptySportsResponse()
                return null
            }
        }
        // El WebView debe tener un tamaño razonable para que el JS se ejecute correctamente
        wv.visibility = View.VISIBLE
        rootView.addView(wv, FrameLayout.LayoutParams(100, 100).apply {
            leftMargin = -200
            topMargin = -200
        })
        wv.loadUrl(STREAMED_BASE_URL)
        // Timeout de 30s (3s delay + tiempo de carga)
        handler.postDelayed({
            if (sportsLoading) {
                try { rootView.removeView(wv); wv.destroy() } catch (_: Throwable) {}
                Log.w(LOG_TAG, "Timeout cargando partidos de Streamed via WebView")
                sportsLoading = false
                sportsMatches = emptyList()
                if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                    renderCatalogItems(currentSearchQuery())
                }
            }
        }, 30_000L)
    }

    private fun sportsMatchesWithDirectStreams(matches: List<SportMatch>): List<SportMatch> {
        return matches.mapNotNull { match ->
            val directSources = match.sources.filter { source ->
                source.streamUrl.isNotBlank() && isLikelySportsStreamUrl(source.streamUrl)
            }
            if (directSources.isEmpty()) null else match.copy(sources = directSources)
        }.sortedByDescending { it.isLive }
    }

    private fun loadIptvSportsMatches(reason: String) {
        if (!sportsLoading) return
        Log.w(LOG_TAG, "Sports IPTV fallback: $reason")
        Thread {
            val matches = try {
                val m3u = fetchText(
                    url = IPTV_ORG_SPORTS_M3U_URL,
                    accept = "application/x-mpegURL,text/plain,*/*",
                    referer = null,
                    connectTimeoutMs = 8000,
                    readTimeoutMs = 12000,
                    origin = null
                )
                validateIptvSportsMatches(parseIptvSportsM3u(m3u))
            } catch (e: Throwable) {
                Log.w(LOG_TAG, "IPTV sports m3u failed: ${e.message}")
                emptyList()
            }
            handler.post {
                if (!sportsLoading) return@post
                if (matches.isNotEmpty()) {
                    sportsLoading = false
                    sportsMatches = matches
                    Log.d(LOG_TAG, "Sports IPTV channels loaded: ${matches.size}")
                    if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                        renderCatalogItems(currentSearchQuery())
                    }
                } else {
                    useSportsFallbackMatches("$reason; IPTV-org no entregó canales reproducibles")
                }
            }
        }.start()
    }

    private fun parseIptvSportsM3u(m3u: String): List<SportMatch> {
        val result = mutableListOf<SportMatch>()
        var rawTitle = ""
        var logoUrl = ""
        var rawExtInf = ""
        val logoPattern = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
        m3u.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    rawExtInf = line
                    rawTitle = line.substringAfterLast(",", "").trim()
                    logoUrl = logoPattern.find(line)?.groupValues?.getOrNull(1).orEmpty()
                }
                rawTitle.isNotBlank() &&
                    (line.startsWith("https://", ignoreCase = true) || line.startsWith("http://", ignoreCase = true)) &&
                    isLikelySportsStreamUrl(line) -> {
                    val inferredSport = canonicalSportName(rawTitle)
                    if (inferredSport.isNotBlank() &&
                        !rawTitle.contains("geo-blocked", ignoreCase = true) &&
                        !rawExtInf.contains("""tvg-id="beINSPORTSXTRA.us""", ignoreCase = true) &&
                        !rawExtInf.contains("""tvg-id="PlutoTVFutbolParaFans.us""", ignoreCase = true) &&
                        BLOCKED_IPTV_SPORTS_NAMES.none { rawTitle.contains(it, ignoreCase = true) } &&
                        isAllowedIptvSportsLanguage(rawTitle, rawExtInf)
                    ) {
                        val cleanTitle = cleanIptvSportsTitle(rawTitle)
                            .replace(Regex("""\s*\[[^]]*geo[^]]*]""", RegexOption.IGNORE_CASE), "")
                            .replace(Regex("""\s*\((?:\d{3,4}p|1080i)\)""", RegexOption.IGNORE_CASE), "")
                            .trim()
                        
                        // FILTRO: Solo agregar si está en PREFERRED_IPTV_SPORTS_NAMES
                        val isPreferred = PREFERRED_IPTV_SPORTS_NAMES.any { preferred ->
                            cleanTitle.contains(preferred, ignoreCase = true) ||
                            normalizeLanguageText(cleanTitle).contains(normalizeLanguageText(preferred))
                        }
                        
                        if (cleanTitle.isNotBlank() && isPreferred) {
                            val slug = cleanTitle.lowercase()
                                .replace(Regex("""[^a-z0-9]+"""), "-")
                                .trim('-')
                                .ifBlank { "channel-${result.size + 1}" }
                            Log.d(LOG_TAG, "IPTV channel preferido encontrado: $cleanTitle -> $line")
                            result += SportMatch(
                                id = "iptv-org:$slug",
                                title = cleanTitle,
                                sport = inferredSport,
                                league = if (inferredSport == "basketball") "Baloncesto por IPTV m3u8" else "Fútbol por IPTV m3u8",
                                time = "En directo",
                                isLive = true,
                                posterUrl = logoUrl,
                                sources = listOf(
                                    SportSource(
                                        source = "iptv-org",
                                        id = slug,
                                        streamUrl = line
                                    )
                                )
                            )
                        }
                    }
                    rawTitle = ""
                    logoUrl = ""
                    rawExtInf = ""
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    rawTitle = ""
                    logoUrl = ""
                    rawExtInf = ""
                }
            }
        }
        return result
            .distinctBy { it.sources.firstOrNull()?.streamUrl?.substringBefore("?") ?: it.id }
            .sortedWith(compareBy<SportMatch> { iptvSportsRank(it.title) }.thenBy { it.title.lowercase() })
            .take(40)
    }

    private fun validateIptvSportsMatches(matches: List<SportMatch>): List<SportMatch> {
        val validated = mutableListOf<SportMatch>()
        val failedTimeout = mutableListOf<SportMatch>()
        
        matches.forEach { match ->
            val streamUrl = match.sources.firstOrNull()?.streamUrl.orEmpty()
            val result = resolvePlayableIptvManifestUrlWithReason(streamUrl)
            when {
                result.url != null -> {
                    Log.d(LOG_TAG, "IPTV sports channel validado: ${match.title} -> ${result.url}")
                    val updatedSources = match.sources.mapIndexed { index, source ->
                        if (index == 0) source.copy(streamUrl = result.url) else source
                    }
                    validated += match.copy(sources = updatedSources)
                }
                result.reason == "timeout" -> {
                    Log.w(LOG_TAG, "IPTV sports channel timeout (se agregará con advertencia): ${match.title}")
                    failedTimeout += match
                }
                else -> {
                    Log.w(LOG_TAG, "IPTV sports channel descartado (${result.reason}): ${match.title} -> $streamUrl")
                }
            }
        }
        
        // Agregar canales con timeout (pueden funcionar en algunos casos)
        if (validated.size < 6 && failedTimeout.isNotEmpty()) {
            val toAdd = minOf(6 - validated.size, failedTimeout.size)
            failedTimeout.take(toAdd).forEach { match ->
                Log.d(LOG_TAG, "IPTV channel agregado sin validación: ${match.title}")
                validated += match.copy(
                    league = "${match.league} (puede no funcionar)"
                )
            }
        }
        
        return validated.take(16)
    }

    private data class IptvValidationResult(val url: String?, val reason: String)

    private fun resolvePlayableIptvManifestUrlWithReason(streamUrl: String): IptvValidationResult {
        if (streamUrl.isBlank()) return IptvValidationResult(null, "empty")
        return try {
            val conn = (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                setRequestProperty("Accept", "application/x-mpegURL,text/plain,*/*")
            }
            try {
                val code = conn.responseCode
                if (code == 403 || code == 401) {
                    return IptvValidationResult(null, "forbidden")
                }
                if (code !in 200..399) {
                    Log.w(LOG_TAG, "IPTV validation failed with code $code for: $streamUrl")
                    return IptvValidationResult(null, "http_$code")
                }
                val manifest = conn.inputStream.bufferedReader().use { reader ->
                    val buffer = CharArray(24_000)
                    val read = reader.read(buffer)
                    if (read <= 0) "" else String(buffer, 0, read)
                }
                if (!manifest.contains("#EXTM3U", ignoreCase = true)) {
                    Log.w(LOG_TAG, "IPTV manifest no contiene #EXTM3U: $streamUrl")
                    return IptvValidationResult(null, "invalid_manifest")
                }
                if (!manifest.contains("#EXT-X-", ignoreCase = true) &&
                    !manifest.contains(".m3u8", ignoreCase = true) &&
                    !manifest.contains(".ts", ignoreCase = true)
                ) {
                    Log.w(LOG_TAG, "IPTV manifest no contiene marcadores válidos: $streamUrl")
                    return IptvValidationResult(null, "invalid_manifest")
                }
                IptvValidationResult(bestVariantFromManifest(manifest, streamUrl) ?: streamUrl, "ok")
            } finally {
                conn.disconnect()
            }
        } catch (error: java.net.SocketTimeoutException) {
            Log.w(LOG_TAG, "IPTV sports validation timeout for $streamUrl")
            IptvValidationResult(null, "timeout")
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "IPTV sports validation failed for $streamUrl: ${error.message}")
            IptvValidationResult(null, "error")
        }
    }

    private fun resolvePlayableIptvManifestUrl(streamUrl: String): String? {
        if (streamUrl.isBlank()) return null
        return try {
            val conn = (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000  // Aumentado de 3500 a 6000ms
                readTimeout = 6000     // Aumentado de 3500 a 6000ms
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
                setRequestProperty("Accept", "application/x-mpegURL,text/plain,*/*")
            }
            try {
                val code = conn.responseCode
                if (code !in 200..399) {
                    Log.w(LOG_TAG, "IPTV validation failed with code $code for: $streamUrl")
                    return null
                }
                val manifest = conn.inputStream.bufferedReader().use { reader ->
                    val buffer = CharArray(24_000)
                    val read = reader.read(buffer)
                    if (read <= 0) "" else String(buffer, 0, read)
                }
                if (!manifest.contains("#EXTM3U", ignoreCase = true)) {
                    Log.w(LOG_TAG, "IPTV manifest no contiene #EXTM3U: $streamUrl")
                    return null
                }
                if (!manifest.contains("#EXT-X-", ignoreCase = true) &&
                    !manifest.contains(".m3u8", ignoreCase = true) &&
                    !manifest.contains(".ts", ignoreCase = true)
                ) {
                    Log.w(LOG_TAG, "IPTV manifest no contiene marcadores válidos: $streamUrl")
                    return null
                }
                bestVariantFromManifest(manifest, streamUrl) ?: streamUrl
            } finally {
                conn.disconnect()
            }
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "IPTV sports validation failed for $streamUrl: ${error.message}")
            null
        }
    }

    private fun bestVariantFromManifest(manifest: String, baseUrl: String): String? {
        var pendingBandwidth = 0
        val candidates = mutableListOf<Pair<Int, String>>()
        manifest.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) -> {
                    pendingBandwidth = Regex("""BANDWIDTH=(\d+)""", RegexOption.IGNORE_CASE)
                        .find(line)
                        ?.groupValues
                        ?.getOrNull(1)
                        ?.toIntOrNull()
                        ?: 0
                }
                pendingBandwidth >= 0 && line.isNotBlank() && !line.startsWith("#") -> {
                    val resolved = runCatching { URL(URL(baseUrl), line).toString() }.getOrNull()
                    if (resolved != null && resolved.contains(".m3u8", ignoreCase = true)) {
                        candidates += pendingBandwidth to resolved
                    }
                    pendingBandwidth = -1
                }
            }
        }
        return candidates.maxByOrNull { it.first }?.second
    }

    private fun isAllowedIptvSportsLanguage(title: String, extInf: String): Boolean {
        val tvgId = Regex("""tvg-id="([^"]*)"""", RegexOption.IGNORE_CASE)
            .find(extInf)
            ?.groupValues
            ?.getOrNull(1)
            .orEmpty()
        val country = Regex("""\.([a-z]{2})(?:@|$)""", RegexOption.IGNORE_CASE)
            .find(tvgId)
            ?.groupValues
            ?.getOrNull(1)
            ?.lowercase()
        if (country != null) return country in ALLOWED_IPTV_SPORTS_COUNTRIES

        val normalized = normalizeLanguageText("$title $extInf")
        val spanishHints = listOf(
            "espanol",
            "castellano",
            "la liga",
            "laliga",
            "barca tv",
            "real madrid",
            "gol tv",
            "futbol"
        )
        val englishHints = listOf(
            "nba tv",
            "football",
            "basketball",
            "soccer",
            "premier sports",
            "bein sports xtra"
        )
        return spanishHints.any { normalized.contains(it) } || englishHints.any { normalized.contains(it) }
    }

    private fun cleanIptvSportsTitle(title: String): String =
        title
            .replace("Espanol", "Español", ignoreCase = true)
            .replace("Barca TV", "Barça TV", ignoreCase = true)
            .replace(Regex("""\bFutbol\b""", RegexOption.IGNORE_CASE), "Fútbol")

    private fun normalizeLanguageText(value: String): String =
        value.lowercase()
            .replace("á", "a")
            .replace("é", "e")
            .replace("í", "i")
            .replace("ó", "o")
            .replace("ú", "u")
            .replace("ü", "u")
            .replace("ñ", "n")
            .replace(Regex("""[^a-z0-9]+"""), " ")
            .trim()

    private fun iptvSportsRank(title: String): Int {
        val lower = normalizeLanguageText(title)
        val index = PREFERRED_IPTV_SPORTS_NAMES.indexOfFirst { lower.contains(normalizeLanguageText(it)) }
        return if (index >= 0) index else PREFERRED_IPTV_SPORTS_NAMES.size + 1
    }

    private fun fallbackSportsMatches(): List<SportMatch> {
        return SPORTS_FALLBACK_CHANNELS.mapNotNull { (streamKey, title) ->
            val sport = canonicalSportName(title)
            if (sport.isBlank()) return@mapNotNull null
            SportMatch(
                id = "pirlotv:$streamKey",
                title = title,
                sport = sport,
                league = if (sport == "basketball") "Baloncesto / la14hd" else "Fútbol / la14hd",
                time = "En directo",
                isLive = true,
                posterUrl = "",
                sources = listOf(
                    SportSource(
                        source = "pirlotv",
                        id = streamKey,
                        streamUrl = "$LA14HD_BASE_URL/vivo/canales.php?stream=$streamKey"
                    )
                )
            )
        }
    }

    private fun useSportsFallbackMatches(reason: String) {
        Log.w(LOG_TAG, "Sports fallback: $reason")
        sportsLoading = false
        sportsMatches = fallbackSportsMatches()
        if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
            renderCatalogItems(currentSearchQuery())
        }
    }

    private fun processMatchesJson(json: String) {
        Log.d(LOG_TAG, "Sports processMatchesJson len=${json.length}")
        Thread {
            try {
                val matches = SportsManager.parseMatchesPublic(json)
                    .filter { it.sources.isNotEmpty() }
                    .sortedByDescending { it.isLive }
                handler.post {
                    if (sportsLoading) {
                        if (matches.isNotEmpty()) {
                            val directMatches = sportsMatchesWithDirectStreams(matches)
                            if (directMatches.isNotEmpty()) {
                                sportsLoading = false
                                sportsMatches = directMatches
                                if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                                    renderCatalogItems(currentSearchQuery())
                                }
                            } else {
                                // No hay streams directos, terminar
                                sportsLoading = false
                                sportsMatches = emptyList()
                                if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                                    renderCatalogItems(currentSearchQuery())
                                }
                            }
                        } else {
                            // No hay streams reproducibles, terminar
                            sportsLoading = false
                            sportsMatches = emptyList()
                            if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                                renderCatalogItems(currentSearchQuery())
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(LOG_TAG, "Error parsing sports JSON: ${e.message}")
                handler.post {
                    if (sportsLoading) {
                        sportsLoading = false
                        sportsMatches = emptyList()
                        if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                            renderCatalogItems(currentSearchQuery())
                        }
                    }
                }
            }
        }.start()
    }

    private fun playSportMatch(match: SportMatch) {
        if (match.sources.isEmpty()) {
            android.widget.Toast.makeText(this, "Abriendo página del directo...", android.widget.Toast.LENGTH_SHORT).show()
            showSportsWebPlayer(match)
            return
        }
        match.sources.firstOrNull { it.source == "pirlotv" && it.streamUrl.startsWith("http", ignoreCase = true) }?.let { source ->
            cachedSportsStream(source.streamUrl)?.let { cachedUrl ->
                Log.d(LOG_TAG, "Usando HLS de deportes en cache para ${match.title}: $cachedUrl")
                showSportsVlcPlayer(match, cachedUrl)
                return
            }
            sportsResolveGeneration++
            val generation = sportsResolveGeneration
            showSportsResolveStatus(
                match = match,
                title = "Resolviendo directo...",
                detail = "Probando la señal del canal. Puede tardar unos segundos."
            )
            Thread {
                val streamUrl = try {
                    resolveLa14HdPlaybackUrl(source.streamUrl)
                } catch (error: Throwable) {
                    Log.w(LOG_TAG, "No se pudo resolver la14hd: ${error.message}")
                    null
                }
                handler.post {
                    if (generation != sportsResolveGeneration || currentScreen != Screen.PLAYER) return@post
                    if (streamUrl != null) {
                        sportsResolvedStreamCache[source.streamUrl] = SportsResolvedStream(streamUrl, android.os.SystemClock.elapsedRealtime())
                        Log.d(LOG_TAG, "PirloTV/la14hd resuelto a HLS: $streamUrl")
                        showSportsVlcPlayer(match, streamUrl)
                    } else {
                        Log.w(LOG_TAG, "la14hd no entregó HLS directo; abriendo WebView interactivo")
                        showSportsWebPlayer(match, source.streamUrl)
                    }
                }
            }.start()
            return
        }
        android.widget.Toast.makeText(this, "Loading...", android.widget.Toast.LENGTH_SHORT).show()
        Thread {
            var streamUrl: String? = null
            for (source in match.sources) {
                if (source.streamUrl.isNotBlank() && isLikelySportsStreamUrl(source.streamUrl)) {
                    streamUrl = source.streamUrl
                    break
                }
                if (source.streamUrl.startsWith("http", ignoreCase = true) && source.source != "streamed") {
                    continue
                }
                if (source.source == "streamed" && source.id.contains("-")) continue
                if (source.source != "streamed") continue
                streamUrl = SportsManager.fetchStreamUrl(source.source, source.id)
                if (streamUrl != null) break
            }
            handler.post {
                if (streamUrl != null) {
                    showSportsVlcPlayer(match, streamUrl!!)
                } else {
                    val candidates = sportsCandidateUrls(match)
                    if (candidates.isNotEmpty()) {
                        resolveSportsPageToVlc(match, candidates.first(), candidates.drop(1))
                    } else {
                        showSportsWebPlayer(match)
                    }
                    return@post
                    // Si no se pudo obtener el stream via API, usar la URL del source directamente
                    // El sourceId puede ser una URL completa o un slug de istreameast.is
                    val firstSource = match.sources.first()
                    val directUrl = when {
                        firstSource.id.startsWith("http") -> firstSource.id
                        // Slug como "pfl-mena-1-khobar-2433646" → URL de istreameast.is
                        firstSource.id.contains("-") && !firstSource.id.contains("/") ->
                            "https://istreameast.is/links/${firstSource.id}"
                        firstSource.streamUrl.isNotBlank() -> firstSource.streamUrl
                        else -> null
                    }
                    if (directUrl != null) {
                        resolveSportsPageToVlc(match, directUrl)
                    } else {
                        resolveSportsPageToVlc(match, "$STREAMED_BASE_URL/watch/${match.id}")
                    }
                }
            }
        }.start()
    }

    private fun sportsCandidateUrls(match: SportMatch): List<String> {
        val urls = linkedSetOf<String>()
        match.sources.forEach { source ->
            if (source.streamUrl.startsWith("http", ignoreCase = true)) {
                urls += source.streamUrl
            }
            when {
                source.id.startsWith("http", ignoreCase = true) -> urls += source.id
                source.source == "streamed" && source.id.contains("-") && !source.id.contains("/") ->
                    urls += "https://istreameast.is/links/${source.id}"
                source.id.isNotBlank() -> {
                    urls += "$STREAMED_BASE_URL/watch/${Uri.encode(source.id)}"
                    urls += "$STREAMED_BASE_URL/links/${Uri.encode(source.id)}"
                }
            }
        }
        if (match.id.startsWith("http", ignoreCase = true)) {
            urls += match.id
        } else if (match.id.isNotBlank()) {
            urls += "$STREAMED_BASE_URL/watch/${Uri.encode(match.id)}"
        }
        return urls.toList()
    }

    private fun cachedSportsStream(sourceUrl: String): String? {
        val cached = sportsResolvedStreamCache[sourceUrl] ?: return null
        val age = android.os.SystemClock.elapsedRealtime() - cached.resolvedAtMs
        return if (age in 0 until SPORTS_STREAM_CACHE_TTL_MS) {
            cached.url
        } else {
            sportsResolvedStreamCache.remove(sourceUrl)
            null
        }
    }

    private fun resolveLa14HdPlaybackUrl(pageUrl: String): String? {
        val referer = "$PIRLOTV_BASE_URL/"
        try {
            val html = fetchText(
                url = pageUrl,
                accept = "text/html,application/xhtml+xml,*/*",
                referer = referer,
                connectTimeoutMs = 6000,
                readTimeoutMs = 7000,
                origin = PIRLOTV_BASE_URL
            )
            val streamUrl = extractLa14HdPlaybackUrl(html, pageUrl)
            if (streamUrl != null) return streamUrl
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "la14hd fallo referer=$referer: ${error.message}")
            throw error
        }
        return null
    }

    private fun extractLa14HdPlaybackUrl(rawHtml: String, pageUrl: String): String? {
        val html = rawHtml
            .replace("\\/", "/")
            .replace("\\u002F", "/")
            .replace("\\u003A", ":")
            .replace("&amp;", "&")
        val candidates = listOf(
            Regex("""playbackURL\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""(?:source|src|file)\s*:\s*["']([^"']+\.m3u8[^"']*)["']""", RegexOption.IGNORE_CASE),
            Regex("""https?://[^"'<>\\\s]+\.m3u8[^"'<>\\\s]*""", RegexOption.IGNORE_CASE)
        ).flatMap { pattern ->
            pattern.findAll(html).map { match -> match.groupValues.getOrElse(1) { match.value } }
        }
        return candidates
            .mapNotNull { normalizeSportsCandidateUrl(it, pageUrl) }
            .firstOrNull { isLikelySportsStreamUrl(it) }
    }

    private fun showSportsResolveStatus(
        match: SportMatch,
        title: String,
        detail: String,
        retrySourceUrl: String? = null,
        verifyMount: Boolean = true
    ) {
        releaseEmbeddedVlcPlayer()
        destroyPlayerWebView()
        releaseSportsLivePlayer()
        currentScreen = Screen.PLAYER
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        val sbHeight = statusBarHeight()
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener {
                confirmExitPlayback()
            }
        }
        val titleView = TextView(this).apply {
            text = match.title.ifBlank { "Deporte en directo" }
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            setPadding(dp(12), 0, 0, 0)
        }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        topBar.addView(titleView, LinearLayout.LayoutParams(0, -1, 1f))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(26), dp(24), dp(26), dp(24))
        }
        val status = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val description = TextView(this).apply {
            text = detail
            setTextColor(color("#D6D6D6"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        content.addView(status, LinearLayout.LayoutParams(-1, -2))
        content.addView(description, LinearLayout.LayoutParams(-1, -2))
        if (retrySourceUrl != null) {
            val retry = TextView(this).apply {
                text = "Reintentar"
                setTextColor(Color.BLACK)
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                setPadding(dp(18), 0, dp(18), 0)
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = dp(8).toFloat()
                }
                setOnClickListener { playSportMatch(match) }
            }
            content.addView(retry, LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(18) })
        }

        rootView.addView(View(this).apply { setBackgroundColor(STATUS_BAR_COLOR) }, FrameLayout.LayoutParams(-1, sbHeight, Gravity.TOP))
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply { topMargin = sbHeight })
        rootView.addView(content, FrameLayout.LayoutParams(-1, -1).apply { topMargin = sbHeight + dp(52) })
        rootView.requestLayout()
        rootView.invalidate()
        Log.d(LOG_TAG, "Sports resolve status mounted children=${rootView.childCount} title=$title")
        if (verifyMount) {
            listOf(250L, 1500L).forEach { delay ->
                handler.postDelayed({
                    if (currentScreen == Screen.PLAYER && rootView.childCount == 0) {
                        Log.w(LOG_TAG, "Sports resolve status remount after empty root title=$title")
                        showSportsResolveStatus(match, title, detail, retrySourceUrl, verifyMount = false)
                    }
                }, delay)
            }
        }
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun resolveSportsPageToVlc(match: SportMatch, pageUrl: String, extraPageUrls: List<String> = emptyList()) {
        sportsResolveGeneration++
        val generation = sportsResolveGeneration
        showSportsResolveStatus(
            match = match,
            title = "Buscando stream...",
            detail = "Analizando la fuente del directo para encontrar el video reproducible."
        )
        embedsportsFallbackIndex = 0
        var resolved = false
        val seenPages = linkedSetOf<String>()
        val candidateQueue = java.util.ArrayDeque<String>()
        var activeCandidate: String? = null
        val wv = WebView(this)

        fun isCurrentResolve() = generation == sportsResolveGeneration && currentScreen == Screen.PLAYER

        fun cleanup() {
            candidateQueue.clear()
            activeCandidate = null
            try {
                rootView.removeView(wv)
            } catch (_: Throwable) {
            }
            try {
                wv.stopLoading()
                wv.loadUrl("about:blank")
                wv.destroy()
            } catch (_: Throwable) {
            }
        }

        fun loadNextCandidate() {
            if (resolved || !isCurrentResolve()) return
            val next = candidateQueue.pollFirst() ?: run {
                activeCandidate = null
                return
            }
            activeCandidate = next
            Log.d(LOG_TAG, "Sports loading candidate: $next")
            wv.loadUrl(next)
        }

        fun openCandidate(candidateUrl: String) {
            if (!isCurrentResolve()) {
                cleanup()
                return
            }
            val clean = normalizeSportsCandidateUrl(candidateUrl, pageUrl) ?: return
            if (resolved || !seenPages.add(clean)) return
            if (isLikelySportsStreamUrl(clean)) {
                resolved = true
                cleanup()
                showSportsVlcPlayer(match, clean)
            } else if (isLikelySportsCandidatePage(clean)) {
                candidateQueue.add(clean)
                handler.post {
                    if (!resolved && activeCandidate == null) loadNextCandidate()
                }
            }
        }

        wv.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = COMPATIBLE_USER_AGENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = false
        }
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onStreamUrl(streamUrl: String) {
                if (streamUrl.isBlank() || resolved) return
                Log.d(LOG_TAG, "Sports stream resolved via WebView: $streamUrl")
                handler.post { if (isCurrentResolve()) openCandidate(streamUrl) else cleanup() }
            }

            @android.webkit.JavascriptInterface
            fun onCandidatePage(candidateUrl: String) {
                if (candidateUrl.isBlank() || resolved) return
                Log.d(LOG_TAG, "Sports candidate page: $candidateUrl")
                handler.post { if (isCurrentResolve()) openCandidate(candidateUrl) else cleanup() }
            }
        }, "Android")

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val reqUrl = request.url.toString()
                val host = request.url.host?.lowercase().orEmpty()
                if (isSportsAdRequest(host, reqUrl)) return emptySportsResponse()
                if (isLikelySportsStreamUrl(reqUrl) && !resolved) {
                    resolved = true
                    val captured = reqUrl
                    handler.post {
                        if (isCurrentResolve()) {
                            cleanup()
                            showSportsVlcPlayer(match, captured)
                        } else {
                            cleanup()
                        }
                    }
                    return emptySportsResponse()
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val reqUrl = request.url.toString()
                val host = request.url.host?.lowercase().orEmpty()
                if (isSportsAdRequest(host, reqUrl)) return true
                if (isLikelySportsStreamUrl(reqUrl)) {
                    openCandidate(reqUrl)
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, pageUrl: String) {
                if (resolved) return
                injectAntiDetectionJs(view)
                injectStreamInterceptorJs(view)
                injectSportsStreamCandidateJs(view)
                handler.postDelayed({ if (!resolved) injectSportsStreamCandidateJs(view) }, 900L)
                handler.postDelayed({ if (!resolved) injectSportsStreamCandidateJs(view) }, 2_300L)
                if (activeCandidate == pageUrl) {
                    handler.postDelayed({
                        if (!resolved && activeCandidate == pageUrl) {
                            activeCandidate = null
                            loadNextCandidate()
                        }
                    }, 8_000L)
                }
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.proceed()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame || resolved) return
                val errorCode = error.errorCode
                Log.w(LOG_TAG, "Sports resolver WebView error ${errorCode}: ${error.description}")
                // Si hay candidatos en la cola, pasar al siguiente en lugar de reintentar
                if (candidateQueue.isNotEmpty()) {
                    activeCandidate = null
                    handler.postDelayed({ if (!resolved) loadNextCandidate() }, 500L)
                    return
                }
                // Cola vacía — intentar subdominios de embedsports si es ERR_CONNECTION_RESET
                if (errorCode == -101) {
                    val currentUrl = request.url.toString()
                    if (currentUrl.contains("embedsports")) {
                        val nextIdx = embedsportsFallbackIndex
                        if (nextIdx < EMBEDSPORTS_FALLBACK_SUBDOMAINS.size) {
                            embedsportsFallbackIndex++
                            val subdomain = EMBEDSPORTS_FALLBACK_SUBDOMAINS[nextIdx]
                            val fallbackUrl = currentUrl.replace(
                                Regex("""(?:admin\.|delta\.|echo\.)?embedsports\.top"""),
                                "$subdomain.embedsports.top"
                            )
                            Log.d(LOG_TAG, "Sports fallback subdomain: $fallbackUrl")
                            handler.postDelayed({ if (!resolved) view.loadUrl(fallbackUrl) }, 800L)
                            return
                        }
                    }
                }
                // Sin más opciones
                if (activeCandidate == request.url.toString()) {
                    activeCandidate = null
                    handler.postDelayed({ if (!resolved) loadNextCandidate() }, 800L)
                } else {
                    handler.postDelayed({ if (!resolved) view.loadUrl(request.url.toString()) }, 1_500L)
                }
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean = false
            override fun onPermissionRequest(request: PermissionRequest) { request.grant(request.resources) }
        }
        rootView.addView(wv, FrameLayout.LayoutParams(2, 2).apply {
            leftMargin = -20
            topMargin = -20
        })
        extraPageUrls
            .mapNotNull { normalizeSportsCandidateUrl(it, pageUrl) }
            .filter { seenPages.add(it) }
            .forEach { candidateQueue.add(it) }
        wv.loadUrl(pageUrl)
        handler.postDelayed({
            if (!resolved && isCurrentResolve()) {
                Log.w(LOG_TAG, "Sports resolver sigue sin m3u8 para ${match.title}")
                cleanup()
                showSportsWebPlayer(match, pageUrl)
            }
        }, 35_000L)
    }

    private fun normalizeSportsCandidateUrl(candidateUrl: String, baseUrl: String): String? {
        val clean = candidateUrl.trim().replace("\\/", "/")
        if (clean.isBlank() || clean.startsWith("javascript:", ignoreCase = true)) return null
        return try {
            URL(URL(baseUrl), clean).toString()
        } catch (_: Throwable) {
            clean.takeIf { it.startsWith("http", ignoreCase = true) }
        }
    }

    private fun isLikelySportsStreamUrl(url: String): Boolean {
        val lower = url.lowercase()
        val path = lower.substringBefore("?")
        val mediaTypeHint = lower.contains("application/x-mpegurl") ||
            lower.contains("application/vnd.apple.mpegurl")
        val staticAssetExtensions = listOf(
            ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
            ".ico", ".woff", ".woff2", ".ttf", ".otf", ".map"
        )
        if (!mediaTypeHint && staticAssetExtensions.any { path.endsWith(it) }) return false
        return lower.contains(".m3u8") ||
            lower.contains(".mpd") ||
            lower.contains("application/x-mpegurl") ||
            lower.contains("application/vnd.apple.mpegurl") ||
            path.endsWith(".ts") ||
            path.endsWith(".m4s") ||
            ((path.endsWith(".mp4") || path.endsWith(".webm")) && (lower.contains("live") || lower.contains("stream"))) ||
            (lower.contains("playlist") && lower.contains("m3u"))
    }

    private fun isLikelySportsCandidatePage(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase().orEmpty()
            val path = uri.path.orEmpty().lowercase()
            if (isSportsAdRequest(host, url)) return false
            host.contains("embedsports") ||
                host.contains("streameast") ||
                host.contains("streamed") ||
                host.contains("pirlotv") ||
                host.contains("futbol-libre") ||
                host.contains("la14hd") ||
                host.contains("fubohd") ||
                host.contains("player") ||
                host.contains("embed") ||
                path.contains("/vivo/") ||
                path.contains("/links/") ||
                path.contains("/embed") ||
                path.contains("/player") ||
                path.contains("/stream") ||
                path.contains("embedsports") ||
                url.lowercase().contains(".m3u8")
        } catch (_: Throwable) {
            false
        }
    }

    private fun injectSportsStreamCandidateJs(view: WebView) {
        val js = """
            (function() {
                function abs(url) {
                    try { return new URL(url, location.href).href; } catch(e) { return url || ''; }
                }
                function send(url) {
                    url = abs(url);
                    if (!url || !window.Android) return;
                    var parsed;
                    try { parsed = new URL(url); } catch(e) { parsed = null; }
                    var u = url.toLowerCase();
                    var host = parsed ? parsed.hostname.toLowerCase() : '';
                    var path = parsed ? parsed.pathname.toLowerCase() : u;
                    var isStatic = /\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|map)$/.test(path);
                    if (!isStatic && (u.indexOf('.m3u8') >= 0 || u.indexOf('.mpd') >= 0 || path.endsWith('.ts') || path.endsWith('.m4s') || u.indexOf('mpegurl') >= 0)) {
                        window.Android.onStreamUrl(url);
                    } else if (host.indexOf('embedsports') >= 0 || host.indexOf('streameast') >= 0 || host.indexOf('pirlotv') >= 0 || host.indexOf('futbol-libre') >= 0 || host.indexOf('la14hd') >= 0 || host.indexOf('fubohd') >= 0 || host.indexOf('stream') >= 0 || host.indexOf('player') >= 0 || host.indexOf('embed') >= 0 || path.indexOf('/vivo/') >= 0 || path.indexOf('/links/') >= 0 || path.indexOf('/embed') >= 0 || path.indexOf('/player') >= 0 || path.indexOf('/watch') >= 0 || path.indexOf('/live') >= 0 || path.indexOf('/stream') >= 0) {
                        window.Android.onCandidatePage(url);
                    }
                }
                document.querySelectorAll('video[src],source[src],iframe[src],a[href]').forEach(function(el) {
                    send(el.src || el.href || '');
                });
                var candidates = [];
                document.querySelectorAll('[data-src],[data-href],[data-url],[data-link]').forEach(function(el) {
                    ['data-src','data-href','data-url','data-link'].forEach(function(attr) {
                        var value = el.getAttribute(attr);
                        if (value) candidates.push(value);
                    });
                });
                candidates.forEach(send);
                var buttons = document.querySelectorAll('button[data-src],a[data-src],.server-btn,.watch-btn,[class*="server"],[class*="watch"],[class*="play"]');
                for (var i = 0; i < Math.min(buttons.length, 4); i++) {
                    try { buttons[i].click(); } catch(e) {}
                }
                if (performance && performance.getEntriesByType) {
                    performance.getEntriesByType('resource').forEach(function(entry) { send(entry.name || ''); });
                }
                var html = document.documentElement ? document.documentElement.innerHTML : '';
                html = html.replace(/\\\//g, '/').replace(/\\u002F/g, '/').replace(/\\u003A/g, ':').replace(/&amp;/g, '&');
                var re = /https?:\/\/[^"'\s<>]+\.m3u8[^"'\s<>]*/ig;
                var m;
                while ((m = re.exec(html)) !== null) send(m[0]);
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun resizeSportsLiveTextureToVideo() {
        val texture = sportsLiveTexture ?: return
        val videoWidth = sportsLiveVideoWidth
        val videoHeight = sportsLiveVideoHeight
        if (videoWidth <= 0 || videoHeight <= 0) return
        val host = texture.parent as? View ?: return
        val hostWidth = host.width
        val hostHeight = host.height
        if (hostWidth <= 0 || hostHeight <= 0) return
        val videoRatio = videoWidth.toFloat() / videoHeight
        val hostRatio = hostWidth.toFloat() / hostHeight
        val targetWidth: Int
        val targetHeight: Int
        if (videoRatio > hostRatio) {
            targetWidth = hostWidth
            targetHeight = (hostWidth / videoRatio).roundToInt().coerceAtLeast(1)
        } else {
            targetWidth = (hostHeight * videoRatio).roundToInt().coerceAtLeast(1)
            targetHeight = hostHeight
        }
        val lp = (texture.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(-1, -1)
        lp.width = targetWidth
        lp.height = targetHeight
        lp.gravity = Gravity.CENTER
        texture.layoutParams = lp
    }

    private fun toggleSportsPlayerOrientation() {
        isSportsPlayerLandscape = !isSportsPlayerLandscape
        requestedOrientation = if (isSportsPlayerLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        sportsOrientationButton?.text = if (isSportsPlayerLandscape) "\u25A3" else "\u26F6"
        handler.postDelayed({ resizeSportsLiveTextureToVideo() }, 350L)
        handler.postDelayed({ resizeSportsLiveTextureToVideo() }, 900L)
    }

    private fun showSportsHlsPlayer(match: SportMatch, streamUrl: String) {
        releaseEmbeddedVlcPlayer()
        destroyPlayerWebView()
        releaseSportsLivePlayer()
        currentScreen = Screen.PLAYER
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)

        val texture = TextureView(this).apply {
            isOpaque = true
        }
        sportsLiveTexture = texture
        val videoHost = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipToPadding = true
        }
        videoHost.addView(texture, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        videoHost.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            resizeSportsLiveTextureToVideo()
        }

        val status = TextView(this).apply {
            text = "Buffering..."
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(color("#88000000"))
                cornerRadius = dp(10).toFloat()
            }
        }
        val sbHeight = statusBarHeight()
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
            setOnClickListener {
                confirmExitPlayback()
            }
        }
        val title = TextView(this).apply {
            text = match.title.ifBlank { "Deporte en directo" }
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            setPadding(dp(12), 0, 0, 0)
        }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        topBar.addView(title, LinearLayout.LayoutParams(0, -1, 1f))

        fun start(surfaceTexture: SurfaceTexture) {
            releaseSportsLivePlayer()
            val surface = Surface(surfaceTexture)
            sportsLiveSurface = surface
            sportsLiveTexture = texture
            val headers = mutableMapOf("User-Agent" to COMPATIBLE_USER_AGENT)
            sportsHttpReferrerForUrl(streamUrl).takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
            sportsHttpOriginForUrl(streamUrl).takeIf { it.isNotBlank() }?.let { headers["Origin"] = it }
            
            val isDash = streamUrl.contains(".mpd", ignoreCase = true) ||
                streamUrl.contains("/dash/", ignoreCase = true)

            if (isDash) {
                Log.d(LOG_TAG, "Stream DASH detectado, usando VLC embebido")
                status.text = "Cargando con VLC..."
                handler.postDelayed({
                    playSportsWithEmbeddedVlc(streamUrl, match.title)
                }, 100)
                return
            }
            
            sportsLivePlayer = MediaPlayer().apply {
                setSurface(surface)
                setDataSource(
                    this@MainActivity,
                    Uri.parse(streamUrl),
                    headers
                )
                setOnVideoSizeChangedListener { _, videoWidth, videoHeight ->
                    if (videoWidth > 0 && videoHeight > 0) {
                        sportsLiveVideoWidth = videoWidth
                        sportsLiveVideoHeight = videoHeight
                        texture.post {
                            resizeSportsLiveTextureToVideo()
                        }
                    }
                }
                setOnPreparedListener { player ->
                    status.text = "Reproduciendo"
                    status.postDelayed({ status.visibility = View.GONE }, 900L)
                    player.start()
                }
                setOnInfoListener { _, what, _ ->
                    when (what) {
                        MediaPlayer.MEDIA_INFO_BUFFERING_START -> {
                            status.text = "Buffering..."
                            status.visibility = View.VISIBLE
                        }
                        MediaPlayer.MEDIA_INFO_BUFFERING_END -> status.visibility = View.GONE
                    }
                    false
                }
                setOnErrorListener { _, what, extra ->
                    Log.w(LOG_TAG, "Sports MediaPlayer error what=$what extra=$extra")
                    // Error -1005 = formato no soportado, intentar con VLC
                    if (extra == -1005 || what == 1) {
                        Log.d(LOG_TAG, "Formato no soportado por MediaPlayer (what=$what extra=$extra), intentando con VLC")
                        handler.post {
                            playSportsWithEmbeddedVlc(streamUrl, match.title)
                        }
                    } else {
                        status.text = "No se pudo reproducir este directo"
                        status.visibility = View.VISIBLE
                    }
                    true
                }
                prepareAsync()
            }
        }

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                start(surface)
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) = Unit
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                releaseSportsLivePlayer()
                return true
            }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
        }

        rootView.addView(videoHost, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = sbHeight + dp(52)
        })
        rootView.addView(View(this).apply { setBackgroundColor(STATUS_BAR_COLOR) }, FrameLayout.LayoutParams(-1, sbHeight, Gravity.TOP))
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply { topMargin = sbHeight })
        rootView.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val orientationButton = vlcIconButton(if (isSportsPlayerLandscape) "\u25A3" else "\u26F6", 23f) {
            toggleSportsPlayerOrientation()
        }.apply {
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(color("#AA000000"))
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), color("#66FFFFFF"))
            }
        }
        sportsOrientationButton = orientationButton
        rootView.addView(orientationButton, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(14)
            bottomMargin = dp(18)
        })
        texture.surfaceTexture?.let { start(it) }
    }

    private fun showSportsVlcPlayer(match: SportMatch, streamUrl: String) {
        if (isLikelySportsStreamUrl(streamUrl) && !isLocalTorrentVideoUrl(streamUrl)) {
            showSportsHlsPlayer(match, streamUrl)
            return
        }
        // Reutilizar el shell de VLC con controles completos (play/pause, seekbar, subtítulos, fullscreen)
        val fakeItem = CatalogItem(
            id = "sport:${match.id}",
            title = match.title.ifBlank { "Deporte en directo" },
            originalTitle = match.title,
            type = "movie",
            year = "",
            runtime = "",
            imdbId = "",
            tmdbId = "",
            rating = "",
            overview = match.league,
            genres = listOf(match.sport),
            posterUrl = match.posterUrl,
            backgroundUrl = match.posterUrl,
            embeds = emptyMap()
        )
        currentTorrentVideoUrl = streamUrl
        Log.d(LOG_TAG, "Sports VLC shell start for ${match.title}: $streamUrl")
        showTorrentPlayerShell(fakeItem)
        Log.d(LOG_TAG, "Sports VLC shell mounted children=${rootView.childCount}")
        // Lanzar VLC directamente con la URL del stream (no hay torrent, es directo)
        handler.post {
            showEmbeddedVlcTorrentPlayer(streamUrl)
            Log.d(LOG_TAG, "Sports VLC embedded requested children=${rootView.childCount}")
        }
    }

    private fun playSportsWithEmbeddedVlc(streamUrl: String, matchTitle: String) {
        // Wrapper para reproducir deportes con VLC embebido cuando MediaPlayer falla
        Log.d(LOG_TAG, "Switching to VLC for sports stream: $matchTitle")
        releaseEmbeddedVlcPlayer()
        destroyPlayerWebView()
        releaseSportsLivePlayer()
        
        currentScreen = Screen.PLAYER
        val fakeItem = CatalogItem(
            id = "sports_vlc_${System.currentTimeMillis()}",
            title = matchTitle,
            originalTitle = matchTitle,
            type = "sports",
            year = "",
            runtime = "",
            imdbId = "",
            tmdbId = "",
            rating = "",
            overview = "Reproducción en vivo",
            genres = listOf("Deportes"),
            posterUrl = "",
            backgroundUrl = "",
            embeds = emptyMap()
        )
        currentTorrentVideoUrl = streamUrl
        showTorrentPlayerShell(fakeItem)
        handler.post {
            showEmbeddedVlcTorrentPlayer(streamUrl)
        }
    }

    private fun sportsHttpReferrerForUrl(videoUrl: String): String {
        val host = try { Uri.parse(videoUrl).host?.lowercase().orEmpty() } catch (_: Throwable) { "" }
        return when {
            host.contains("fubohd") -> "$LA14HD_BASE_URL/"
            host.contains("la14hd") -> "$LA14HD_BASE_URL/"
            host.contains("pirlotv") -> "$PIRLOTV_BASE_URL/"
            host.contains("streameast") -> "https://istreameast.is/"
            host.contains("streamed") -> "$STREAMED_BASE_URL/"
            host.contains("embedsports") -> "https://embedsports.top/"
            else -> ""
        }
    }

    private fun sportsHttpOriginForUrl(videoUrl: String): String {
        val host = try { Uri.parse(videoUrl).host?.lowercase().orEmpty() } catch (_: Throwable) { "" }
        return when {
            host.contains("fubohd") -> LA14HD_BASE_URL
            host.contains("la14hd") -> LA14HD_BASE_URL
            host.contains("pirlotv") -> PIRLOTV_BASE_URL
            host.contains("streameast") -> "https://istreameast.is"
            host.contains("streamed") -> STREAMED_BASE_URL
            host.contains("embedsports") -> "https://embedsports.top"
            else -> ""
        }
    }

    private fun showSportsWebPlayer(match: SportMatch, overrideUrl: String? = null) {
        // Fallback: WebView con anti-deteccion completa cuando no hay m3u8 directo
        val url = overrideUrl ?: "$STREAMED_BASE_URL/watch/${match.id}"
        sportsWebViewUserInteracted = true  // el usuario ya interactuó al tocar el partido
        destroyPlayerWebView()
        currentScreen = Screen.PLAYER
        rootView.removeAllViews()
        rootView.setBackgroundColor(Color.BLACK)
        val wv = buildAntiDetectionWebView(url)
        playbackWebView = wv
        val sbHeight = statusBarHeight()
        val statusBarCover = View(this).apply { setBackgroundColor(STATUS_BAR_COLOR) }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(16), 0)
            setBackgroundColor(STATUS_BAR_COLOR)
        }
        val back = TextView(this).apply {
            text = "\u2190"
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke(dp(1), Color.WHITE); cornerRadius = dp(20).toFloat()
            }
            setOnClickListener { confirmExitPlayback() }
        }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        rootView.addView(wv, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = sbHeight + dp(52)
        })
        rootView.addView(statusBarCover, FrameLayout.LayoutParams(-1, sbHeight, Gravity.TOP))
        rootView.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply {
            topMargin = sbHeight
        })
    }

    // WebView con anti-deteccion completa para reproductores de deportes.
    // Oculta navigator.webdriver, simula plugins de Chrome, bloquea ads via JS + shouldInterceptRequest.
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun buildSportsEmbedSection(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        // Barra de búsqueda de deportes
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val sportsSearchBox = android.widget.EditText(this).apply {
            hint = "Buscar partido, liga, deporte..."
            setHintTextColor(0xFF888888.toInt())
            setTextColor(Color.WHITE)
            textSize = 13f
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), 0, dp(12), 0)
            background = GradientDrawable().apply {
                setColor(0xFF111111.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.WHITE)
            }
        }
        val sportsWv = buildAntiDetectionWebView("$STREAMED_BASE_URL/")
        sportsSearchBox.setOnEditorActionListener { _, _, _ ->
            val q = sportsSearchBox.text?.toString().orEmpty().trim()
            if (q.isNotBlank()) {
                // Buscar en la página de streamed usando JS
                sportsWv.evaluateJavascript("""
                    (function() {
                        var inputs = document.querySelectorAll('input[type="search"],input[type="text"],input[placeholder*="search" i],input[placeholder*="buscar" i]');
                        if (inputs.length > 0) {
                            inputs[0].value = '${q.replace("'", "\\'")}';
                            inputs[0].dispatchEvent(new Event('input', {bubbles:true}));
                            inputs[0].dispatchEvent(new Event('change', {bubbles:true}));
                            inputs[0].form && inputs[0].form.submit();
                        } else {
                            window.location.href = '${STREAMED_BASE_URL}/?s=${Uri.encode(q)}';
                        }
                    })();
                """.trimIndent(), null)
            }
            false
        }
        searchRow.addView(sportsSearchBox, LinearLayout.LayoutParams(0, dp(40), 1f))
        container.addView(searchRow, LinearLayout.LayoutParams(-1, -2))
        container.addView(sportsWv, LinearLayout.LayoutParams(-1, dp(340)))
        return container
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun buildAntiDetectionWebView(url: String): WebView {
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            userAgentString = COMPATIBLE_USER_AGENT
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            loadWithOverviewMode = true
            useWideViewPort = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
        }
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        // Interfaz JS para capturar streams detectados por el interceptor de fetch/XHR
        wv.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onStreamUrl(streamUrl: String) {
                if (streamUrl.isBlank() || !isLikelySportsStreamUrl(streamUrl)) return
                Log.d(LOG_TAG, "JS stream intercepted: $streamUrl")
                handler.post {
                    val fakeMatch = SportMatch("live", "En Directo", "sport", "", "", true, "", emptyList())
                    showSportsVlcPlayer(fakeMatch, streamUrl)
                }
            }
        }, "Android")
        wv.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? {
                val reqUrl = request.url.toString()
                val host = request.url.host?.lowercase() ?: ""
                if (isSportsAdRequest(host, reqUrl)) return emptySportsResponse()
                // Solo interceptar streams si el usuario ha tocado algo (evita auto-lanzar VLC al cargar HOME)
                val isStream = isLikelySportsStreamUrl(reqUrl)
                if (isStream && sportsWebViewUserInteracted) {
                    val capturedUrl = reqUrl
                    Log.d(LOG_TAG, "Sports stream intercepted: $capturedUrl")
                    handler.post {
                        val fakeMatch = SportMatch("live", "En Directo", "sport", "", "", true, "", emptyList())
                        showSportsVlcPlayer(fakeMatch, capturedUrl)
                    }
                    return emptySportsResponse()
                }
                return null
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val reqUrl = request.url.toString()
                val host = request.url.host?.lowercase() ?: ""
                if (isSportsAdRequest(host, reqUrl)) return true
                if (request.isForMainFrame && !isAllowedSportsMainHost(host)) {
                    Log.d(LOG_TAG, "Sports popup/navigation blocked: $reqUrl")
                    return true
                }
                return false
            }
            override fun onPageFinished(view: WebView, pageUrl: String) {
                injectAntiDetectionJs(view)
                injectSportsAdBlockJs(view)
                // Inyectar interceptor de fetch/XHR para capturar streams que se cargan via JS
                injectStreamInterceptorJs(view)
            }
            override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                handler.proceed()
            }
            override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame) return
                val retryUrl = request.url.toString().ifBlank { url }
                Log.w(LOG_TAG, "Sports WebView error ${error.errorCode}: ${error.description}")
                handler.postDelayed({ view.loadUrl(retryUrl) }, 1800)
            }
        }
        // Marcar interacción del usuario al tocar el WebView
        wv.setOnTouchListener { v, _ ->
            sportsWebViewUserInteracted = true
            v.performClick()
            false
        }
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                return false
            }
            override fun onShowCustomView(view: View, callback: android.webkit.WebChromeClient.CustomViewCallback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return }
                fullscreenView = view
                fullscreenCallback = callback
                rootView.addView(view, FrameLayout.LayoutParams(-1, -1))
                wv.visibility = View.GONE
                enterImmersiveMode()
            }
            override fun onHideCustomView() { exitFullscreenVideo() }
            override fun onPermissionRequest(request: android.webkit.PermissionRequest) { request.grant(request.resources) }
        }
        wv.loadUrl(url)
        return wv
    }

    // Intercepta fetch() y XMLHttpRequest para capturar URLs de streams m3u8 que se cargan via JS
    // (Streamed.watch y similares cargan el stream via fetch, no como src de <video>)
    @android.annotation.SuppressLint("JavascriptInterface")
    private fun injectStreamInterceptorJs(view: WebView) {
        val js = """
            (function() {
                if (window.__streamInterceptInstalled) return;
                window.__streamInterceptInstalled = true;
                function isStreamUrl(url) {
                    if (!url || typeof url !== 'string') return false;
                    var parsed;
                    try { parsed = new URL(url, location.href); } catch(e) { parsed = null; }
                    var u = url.toLowerCase();
                    var path = parsed ? parsed.pathname.toLowerCase() : u.split('?')[0];
                    if (/\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|map)$/.test(path)) return false;
                    return u.includes('.m3u8') || u.includes('.mpd') ||
                           path.endsWith('.ts') || path.endsWith('.m4s') ||
                           u.includes('application/x-mpegurl') || u.includes('application/vnd.apple.mpegurl');
                }
                function abs(url) {
                    try { return new URL(url, location.href).href; } catch(e) { return url || ''; }
                }
                function sendStream(url) {
                    if (window.Android && window.Android.onStreamUrl) {
                        window.Android.onStreamUrl(abs(url));
                    }
                }
                function scanTextForStreams(text) {
                    if (!text || typeof text !== 'string') return;
                    var decoded = text.replace(/\\\//g, '/').replace(/\\u002F/g, '/').replace(/\\u003A/g, ':').replace(/&amp;/g, '&');
                    var re = /https?:\/\/[^"'\s<>]+(?:\.m3u8|\.mpd|mpegurl)[^"'\s<>]*/ig;
                    var m;
                    while ((m = re.exec(decoded)) !== null) sendStream(m[0]);
                }
                if (document.documentElement) {
                    scanTextForStreams(document.documentElement.innerHTML || '');
                }
                // Interceptar fetch
                var origFetch = window.fetch;
                window.fetch = function(input, init) {
                    var url = (typeof input === 'string') ? input : (input && input.url) ? input.url : '';
                    if (isStreamUrl(url)) {
                        sendStream(url);
                    }
                    return origFetch.apply(this, arguments).then(function(resp) {
                        try {
                            resp.clone().text().then(scanTextForStreams).catch(function(){});
                        } catch(e) {}
                        return resp;
                    });
                };
                // Interceptar XHR
                var origOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function(method, url) {
                    if (isStreamUrl(url)) {
                        sendStream(url);
                    }
                    try {
                        this.addEventListener('load', function() {
                            try { scanTextForStreams(this.responseText || ''); } catch(e) {}
                        });
                    } catch(e) {}
                    return origOpen.apply(this, arguments);
                };
                // Interceptar asignación de src en elementos <video> y <source>
                var origSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
                if (origSrcDescriptor && origSrcDescriptor.set) {
                    Object.defineProperty(HTMLMediaElement.prototype, 'src', {
                        set: function(val) {
                            if (isStreamUrl(val) && window.Android && window.Android.onStreamUrl) {
                                sendStream(val);
                            }
                            origSrcDescriptor.set.call(this, val);
                        },
                        get: origSrcDescriptor.get
                    });
                }
                setInterval(function() {
                    try {
                        if (!performance || !performance.getEntriesByType) return;
                        performance.getEntriesByType('resource').forEach(function(entry) {
                            if (isStreamUrl(entry.name) && window.Android && window.Android.onStreamUrl) {
                                sendStream(entry.name);
                            }
                        });
                    } catch(e) {}
                }, 1000);
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun injectAntiDetectionJs(view: WebView) {
        val js = """
            (function() {
                if (window.__antiDetectInstalled) return;
                window.__antiDetectInstalled = true;
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                Object.defineProperty(navigator, 'plugins', { get: () => [
                    { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
                    { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
                    { name: 'Native Client', filename: 'internal-nacl-plugin', description: '' }
                ]});
                Object.defineProperty(navigator, 'languages', { get: () => ['es-ES', 'es', 'en-US', 'en'] });
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
                window.open = function(url) {
                    if (typeof url === 'string' && /^https?:\/\//i.test(url)) {
                        window.location.href = url;
                    }
                    return null;
                };
                window.alert = function() {};
                window.confirm = function() { return false; };
                window.prompt = function() { return null; };
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun injectSportsAdBlockJs(view: WebView) {
        val js = """
            (function() {
                if (window.__sportsAdBlockInstalled) return;
                window.__sportsAdBlockInstalled = true;
                document.title = 'DownTV';

                // Bloquear popups y ventanas emergentes de forma agresiva
                window.open = function(url) {
                    if (typeof url === 'string' && /^https?:\/\//i.test(url) && !url.includes('ad') && !url.includes('pop')) {
                        window.location.href = url;
                    }
                    return null;
                };
                window.alert = function() {};
                window.confirm = function() { return false; };
                window.prompt = function() { return null; };

                // Bloquear service workers que instalan push notifications
                if (navigator.serviceWorker) {
                    navigator.serviceWorker.register = function() { return Promise.reject(new Error('blocked')); };
                }

                // Bloquear Notification API
                if (window.Notification) {
                    window.Notification.requestPermission = function() { return Promise.resolve('denied'); };
                }

                var css = `
                    header,.header,.page-header,footer,.footer,.site-footer,.mobile-nav,.mobile-menu,
                    .logo,.nav,.navigation,.nav-link,.breadcrumb,.breadcrumbs,
                    [class*="share"],[id*="share"],[class*="social"],[id*="social"],
                    a[href*="facebook"],a[href*="twitter"],a[href*="x.com"],a[href*="reddit"],
                    a[href*="pinterest"],a[href*="telegram"],a[href*="whatsapp"],
                    a[href*="discord"],a[href*="discord.gg"],[class*="discord"],[id*="discord"],
                    [class*="telegram"],[id*="telegram"],[class*="whatsapp"],[id*="whatsapp"],
                    script[src*="googletagmanager"],script[src*="analytics"],
                    [class*="cookie"],[id*="cookie"],[class*="gdpr"],[id*="gdpr"],
                    [class*="consent"],[id*="consent"],[class*="subscribe"],[id*="subscribe"],
                    [class*="newsletter"],[id*="newsletter"],[class*="notification"],[id*="notification"],
                    [class*="push-"],[id*="push-"],[class*="modal"]:not([class*="player"]):not([class*="stream"]) {
                        display:none!important;visibility:hidden!important;width:0!important;height:0!important;
                    }
                    html,body{background:#000!important;color:#fff!important;margin:0!important;padding:0!important;overflow-x:hidden!important;}
                    body{font-family:system-ui,-apple-system,Segoe UI,sans-serif!important;}
                    .container{max-width:none!important;width:100%!important;padding:0!important;margin:0!important;}
                    .section{padding:0!important;margin:0!important;background:#000!important;}
                    .section-header{padding:10px 8px!important;margin:0!important;background:#000!important;}
                    .section-title{font-size:18px!important;line-height:1.2!important;color:#fff!important;margin:0!important;}
                    .events-list{display:block!important;padding:0 6px 12px!important;background:#000!important;}
                    .event-card{background:#101010!important;border:1px solid #333!important;border-radius:8px!important;margin:8px 0!important;padding:10px!important;color:#fff!important;box-shadow:none!important;}
                    .event-title{font-size:15px!important;color:#fff!important;font-weight:700!important;}
                    .event-meta,.event-time,.event-sport,.event-league,.event-status{color:#ddd!important;}
                    main,article,[class*="event-detail"],[class*="match-detail"],[class*="stream-detail"]{background:#000!important;color:#fff!important;}
                    img[alt*="Streamed"],img[src*="logo"],svg.logo{display:none!important;}
                    video,iframe[src*="stream"],iframe[src*="player"]{display:block!important;width:100%!important;max-width:100%!important;}
                `;
                var style = document.getElementById('__downtv_sports_css');
                if (!style) {
                    style = document.createElement('style');
                    style.id = '__downtv_sports_css';
                    style.textContent = css;
                    document.documentElement.appendChild(style);
                }
                function removeAds() {
                    // Eliminar todos los target="_blank" para evitar popups
                    document.querySelectorAll('[target]').forEach(function(el) {
                        var t = (el.getAttribute('target') || '').toLowerCase();
                        if (t === '_blank' || t === '_new') el.removeAttribute('target');
                    });
                    // Eliminar botones/links de redes sociales y publicidad
                    document.querySelectorAll('a,button').forEach(function(el) {
                        var text = (el.textContent || '').toLowerCase();
                        var href = (el.getAttribute('href') || '').toLowerCase();
                        var cls = ((el.className || '') + ' ' + (el.id || '')).toLowerCase();
                        if (/discord|join our|chat live|telegram|whatsapp|facebook|twitter|reddit|pinterest|subscribe|notification|push|cookie|gdpr|consent/.test(text + ' ' + href + ' ' + cls)) {
                            el.remove();
                        }
                    });
                    // Redirigir clicks de event-card que usan window.open
                    document.querySelectorAll('.event-card,[class*="match"],[class*="event"]').forEach(function(card) {
                        var raw = card.getAttribute('onclick') || '';
                        var match = raw.match(/window\.open\(['"]([^'"]+)/i);
                        if (match && !card.__downtvClick) {
                            var target = match[1];
                            card.removeAttribute('onclick');
                            card.__downtvClick = true;
                            card.addEventListener('click', function(ev) {
                                ev.preventDefault();
                                ev.stopPropagation();
                                window.location.href = target;
                            }, true);
                        }
                    });
                    // Traducir textos
                    document.querySelectorAll('.section-title,h1,h2,h3').forEach(function(el) {
                        var text = (el.textContent || '');
                        if (/Today/i.test(text) || /Upcoming/i.test(text)) {
                            var count = (text.match(/\(([^)]+)\)/) || [,''])[1];
                            el.textContent = count ? 'Partidos de hoy (' + count + ')' : 'Partidos de hoy';
                        }
                    });
                    document.querySelectorAll('.event-status,[class*="status"]').forEach(function(el) {
                        var text = (el.textContent || '').trim().toLowerCase();
                        if (text === 'live') el.textContent = 'EN DIRECTO';
                        else if (text === 'finished') el.textContent = 'Finalizado';
                        else if (text.includes('from now')) el.textContent = text.replace('from now', '').trim();
                    });
                    var translations = [
                        [/Monday/g, 'Lunes'], [/Tuesday/g, 'Martes'], [/Wednesday/g, 'Miércoles'],
                        [/Thursday/g, 'Jueves'], [/Friday/g, 'Viernes'], [/Saturday/g, 'Sabado'], [/Sunday/g, 'Domingo'],
                        [/January/g, 'enero'], [/February/g, 'febrero'], [/March/g, 'marzo'], [/April/g, 'abril'],
                        [/May/g, 'mayo'], [/June/g, 'junio'], [/July/g, 'julio'], [/August/g, 'agosto'],
                        [/September/g, 'septiembre'], [/October/g, 'octubre'], [/November/g, 'noviembre'], [/December/g, 'diciembre'],
                        [/\bSoccer\b/g, 'Fútbol'], [/\bBasketball\b/g, 'Baloncesto'], [/\bTennis\b/g, 'Tenis'],
                        [/\bBoxing\b/g, 'Boxeo'], [/\bhours\b/g, 'horas'], [/\bhour\b/g, 'hora'],
                        [/\bminutes\b/g, 'minutos'], [/\bminute\b/g, 'minuto'],
                        [/Stream not available/g, 'Emisión no disponible'],
                        [/Not available/gi, 'No disponible'],
                        [/Watch now/gi, 'Ver ahora'],
                        [/Click to watch/gi, 'Toca para ver']
                    ];
                    document.querySelectorAll('body *:not(script):not(style):not(video):not(iframe)').forEach(function(el) {
                        if (el.children.length) return;
                        var text = el.textContent || '';
                        if (!text.trim()) return;
                        translations.forEach(function(pair) { text = text.replace(pair[0], pair[1]); });
                        if (text !== el.textContent) el.textContent = text;
                    });
                    // Eliminar iframes de publicidad
                    document.querySelectorAll('iframe').forEach(function(f) {
                        var src = (f.src || '').toLowerCase();
                        var bad = ['ads','advert','banner','popunder','popup','track','analytics',
                            'doubleclick','googlesyndication','adsterra','exoclick','propellerads',
                            'hilltopads','trafficjunky','juicyads','monetag','adnium','coinzilla',
                            'galaksion','1xbet','xbet','facebook','twitter','reddit','pinterest','discord',
                            'push','notification','subscribe','cookie'];
                        if (bad.some(function(p) { return src.includes(p); })) f.remove();
                    });
                    // Eliminar overlays y popups por clase/id
                    ['[id*="ad-"]','[id*="ads-"]','[id*="banner"]','[id*="popup"]','[id*="popunder"]',
                     '[class*="ad-"]','[class*="ads-"]','[class*="banner"]','[class*="popup"]',
                     '[class*="share"]','[id*="share"]','[class*="social"]','[id*="social"]',
                     '.page-header','.header','header','footer',
                     '[class*="overlay"]:not([class*="player"])',
                     '[class*="interstitial"]','[class*="cookie"]','[class*="gdpr"]',
                     '[class*="consent"]','[class*="subscribe"]','[class*="notification"]',
                     'div[style*="z-index: 9999"]','div[style*="z-index:9999"]',
                     'div[style*="position: fixed"]','div[style*="position:fixed"]'].forEach(function(sel) {
                        try { document.querySelectorAll(sel).forEach(function(el) {
                            if (!el.querySelector('video') && !el.id.includes('player') && !el.className.includes('player') && !el.className.includes('stream')) el.remove();
                        }); } catch(e) {}
                    });
                }
                removeAds();
                var obs = new MutationObserver(function(mutations) {
                    removeAds();
                });
                obs.observe(document.documentElement, { childList: true, subtree: true, attributes: false });
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun isSportsAdRequest(host: String, url: String): Boolean {
        val h = host.removePrefix("www.")
        val u = url.lowercase()
        val adHosts = listOf("doubleclick","googlesyndication","googleadservices","adsterra","exoclick",
            "propellerads","hilltopads","trafficjunky","juicyads","monetag","adnium","coinzilla",
            "galaksion","1xbet","xbet.com","adnxs","rubiconproject","openx.net","pubmatic","appnexus",
            "criteo","amazon-adsystem","popads.net","popcash.net","adspyglass","bidvertiser","yllix",
            "synedawtit","cdn4ads","sfbyctnfokzd","rxqtuwahzmb","fuckingfast.co","onesignal.com",
            "pushground","richpush","evadav","adpushup","trafficstars","zeropark","revcontent",
            "adcash","clickadu","pub-ac0ba41ae0e44cc28ac9f38ccf646acb.r2.dev","ads.tiogolhd.com",
            "ezojs.com","ezoicanalytics.com","facebook.com","twitter.com","x.com","reddit.com","pinterest.com",
            "telegram.org","whatsapp.com","discord.com","discord.gg")
        val adUrls = listOf("/ads/","/adserver","/advert","/banner","/prebid","/vast","/vpaid",
            "/ima3","/popunder","/popup","runpop","zoneid=","/push/","/notification","/tracker",
            "/tracking","/analytics","/metrics","popundersPerIP","topmostLayer","/ima/","/adsense/",
            "/pagead/","prebid.js","/preroll","/pre-roll","/midroll","/postroll",
            "/vast.xml","/vast2","/vast3","/vmap","ad_type=","adzone=")
        if (adHosts.any { h.contains(it) }) return true
        if (adUrls.any { u.contains(it) }) return true
        return false
    }

    private fun isAllowedSportsMainHost(host: String): Boolean {
        val h = host.lowercase().removePrefix("www.")
        return h == "streamed.watch" ||
            h == "streamed.su" ||
            h == "streamed.ng" ||
            h == "streamed.st" ||
            h == "pirlotv.io" ||
            h == "futbol-libre.life" ||
            h == "la14hd.com" ||
            h == "istreameast.is" ||
            h == "crckstreams.ch" ||
            h.endsWith(".streamed.watch") ||
            h.endsWith(".streamed.su") ||
            h.endsWith(".streamed.ng") ||
            h.endsWith(".streamed.st") ||
            h.endsWith(".pirlotv.io") ||
            h.endsWith(".futbol-libre.life") ||
            h.endsWith(".la14hd.com") ||
            h.endsWith(".fubohd.com") ||
            h.endsWith(".istreameast.is") ||
            h.endsWith(".crckstreams.ch") ||
            h.contains("stream") ||
            h.contains("sport")
    }

    private fun emptySportsResponse() = android.webkit.WebResourceResponse(
        "text/plain", "utf-8", 204, "No Content",
        mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )

    // ------------------------------------------------------------------------------
    // MEGADESCARGAS — Catalogo de series con enlaces Mega por episodio/temporada
    // ------------------------------------------------------------------------------

    // Usar las clases de MegaSeriesManager.kt
    // data class MegaSeries, Season, Episode están en MegaSeriesManager.kt
    
    data class GrantTorrentItem(
        val title: String,
        val url: String,
        val category: String,
        val quality: String,
        val date: String
    )

    data class GrantTorrentDetail(
        val item: GrantTorrentItem,
        val torrentUrl: String,
        val summary: String
    )

    private fun loadGrantTorrentCatalog() {
        if (grantTorrentLoading) return
        grantTorrentLoading = true
        refreshCatalogLayout() // Mostrar "Loading..." inmediatamente
        Thread {
            try {
                val items = scrapeGrantTorrentCatalog()
                handler.post {
                    grantTorrentLoading = false
                    grantTorrentItems = items
                    Log.d(LOG_TAG, "GrantTorrent catalog loaded: ${items.size}")
                    if (items.isEmpty()) {
                        Log.w(LOG_TAG, "GrantTorrent .wtf no devolvio resultados en este arranque")
                    }
                    if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                        val query = currentSearchQuery()
                        renderCatalogItems(query)
                    }
                }
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "Error loading GrantTorrent catalog: ${error.message}")
                handler.post {
                    grantTorrentLoading = false
                    grantTorrentItems = emptyList()
                    showToast("GrantTorrent no disponible")
                    refreshCatalogLayout() // Actualizar UI aunque falle
                }
            }
        }.start()
    }

    private fun scrapeGrantTorrentCatalog(): List<GrantTorrentItem> {
        // Solo usar grantorrent.wtf
        val urls = listOf(
            "$GRANTORRENT_BASE_URL/peliculas",
            "$GRANTORRENT_BASE_URL/series"
        )
        val items = mutableListOf<GrantTorrentItem>()
        
        for (url in urls) {
            try {
                val html = fetchGrantTorrentText(url)
                if (isCloudflareChallengeHtml(html)) {
                    Log.w(LOG_TAG, "Cloudflare challenge detectado en $url")
                    continue
                }
                val parsed = parseGrantTorrentItems(html, url)
                Log.d(LOG_TAG, "GrantTorrent parsed ${parsed.size} items from $url")
                items += parsed
                val unique = items.distinctBy { it.url }
                if (unique.size >= 24) return unique.take(160)
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "Error scraping GrantTorrent .wtf desde $url: ${error.message}")
            }
        }
        return items.distinctBy { it.url }.take(160)
    }

    private fun fetchGrantTorrentText(url: String): String {
        try {
            val direct = fetchGrantTorrentTextWithHttp(url)
            Log.d(LOG_TAG, "GrantTorrent HTTP success: ${direct.length} chars from $url")
            return direct
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "GrantTorrent HTTP failed for $url: ${error.message}")
        }

        try {
            val cronet = fetchGrantTorrentTextWithCronet(url, enableQuic = false)
            Log.d(LOG_TAG, "GrantTorrent Cronet success: ${cronet.length} chars from $url")
            return cronet
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "GrantTorrent Cronet failed for $url: ${error.message}")
        }

        Log.d(LOG_TAG, "Fetching GrantTorrent via WebView: $url")
        
        // Usar WebView para bypass SSL fingerprinting
        val latch = java.util.concurrent.CountDownLatch(1)
        var result = ""
        var error: Exception? = null
        var webViewRef: android.webkit.WebView? = null
        
        handler.post {
            try {
                val webView = android.webkit.WebView(this@MainActivity)
                webViewRef = webView
                webView.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    userAgentString = GRANTORRENT_USER_AGENT
                    cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        safeBrowsingEnabled = false
                    }
                }
                android.webkit.CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(webView, true)
                }
                
                webView.webViewClient = object : android.webkit.WebViewClient() {
                    override fun onPageFinished(view: android.webkit.WebView, url: String) {
                        view.evaluateJavascript("document.documentElement.outerHTML") { html ->
                            result = html?.replace("\\u003C", "<")
                                ?.replace("\\n", "\n")
                                ?.replace("\\\"", "\"")
                                ?.trim('"') ?: ""
                            latch.countDown()
                        }
                    }
                    
                    override fun onReceivedError(
                        view: android.webkit.WebView,
                        request: android.webkit.WebResourceRequest,
                        webError: android.webkit.WebResourceError
                    ) {
                        if (request.isForMainFrame) {
                            error = Exception("WebView error: ${webError.description}")
                            latch.countDown()
                        }
                    }
                    
                    override fun onReceivedHttpError(
                        view: android.webkit.WebView,
                        request: android.webkit.WebResourceRequest,
                        errorResponse: android.webkit.WebResourceResponse
                    ) {
                        if (request.isForMainFrame) {
                            error = Exception("HTTP ${errorResponse.statusCode}")
                            latch.countDown()
                        }
                    }
                }

                rootView.addView(webView, FrameLayout.LayoutParams(dp(120), dp(120)).apply {
                    leftMargin = -dp(240)
                    topMargin = -dp(240)
                })
                
                webView.loadUrl(url)
                
                // Dar tiempo al WebView para ejecutar JS/challenges antes de declarar fallo.
                Thread {
                    Thread.sleep(20_000)
                    if (latch.count > 0) {
                        error = Exception("WebView timeout after 20s")
                        latch.countDown()
                    }
                }.start()
                
            } catch (e: Exception) {
                error = e
                latch.countDown()
            }
        }
        
        latch.await()

        handler.post {
            webViewRef?.let { view ->
                try { rootView.removeView(view) } catch (_: Throwable) {}
                try { view.stopLoading() } catch (_: Throwable) {}
                try { view.loadUrl("about:blank") } catch (_: Throwable) {}
                try { view.destroy() } catch (_: Throwable) {}
            }
        }
        
        if (error != null) {
            Log.e(LOG_TAG, "WebView fetch failed: ${error!!.message}")
            throw error!!
        }
        
        if (result.length > 1000 && !isCloudflareChallengeHtml(result)) {
            Log.d(LOG_TAG, "✓ WebView success: ${result.length} chars")
            return result
        }
        
        throw Exception("WebView returned empty content (${result.length} chars)")
    }

    private fun fetchGrantTorrentTextWithHttp(requestUrl: String): String {
        var current = requestUrl
        repeat(6) {
            val connection = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 18_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", GRANTORRENT_USER_AGENT)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.7")
                setRequestProperty("Cache-Control", "no-cache")
                setRequestProperty("Referer", "$GRANTORRENT_BASE_URL/")
            }
            val code = connection.responseCode
            if (code in 300..399) {
                val location = connection.getHeaderField("Location").orEmpty()
                connection.disconnect()
                if (location.isBlank()) throw IOException("HTTP $code sin Location desde $current")
                current = URL(URL(current), location).toString()
                    .replaceFirst("http://", "https://", ignoreCase = true)
                return@repeat
            }
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()
                ?.use { it.readText() }
                .orEmpty()
            connection.disconnect()
            if (code !in 200..299) throw IOException("HTTP $code from $current")
            if (body.isBlank()) throw IOException("Respuesta vacia desde $current")
            if (isCloudflareChallengeHtml(body)) throw IOException("Cloudflare challenge from $current")
            return body
        }
        throw IOException("Demasiadas redirecciones desde $requestUrl")
    }

    private fun isCloudflareChallengeHtml(html: String): Boolean {
        val clean = html.lowercase()
        return clean.contains("cf-mitigated") ||
            clean.contains("just a moment") ||
            clean.contains("enable javascript and cookies to continue") ||
            clean.contains("/cdn-cgi/challenge-platform/") ||
            clean.contains("challenge-platform")
    }

    private fun fetchGrantTorrentTextWithCronet(requestUrl: String, enableQuic: Boolean): String {
        val engine = CronetEngine.Builder(applicationContext)
            .enableQuic(enableQuic)
            .enableHttp2(true)
            .enableBrotli(true)
            .build()
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        val latch = java.util.concurrent.CountDownLatch(1)
        val output = ByteArrayOutputStream()
        val errorRef = java.util.concurrent.atomic.AtomicReference<Throwable?>()
        val statusRef = java.util.concurrent.atomic.AtomicInteger(-1)
        val callback = object : UrlRequest.Callback() {
            override fun onRedirectReceived(request: UrlRequest, info: UrlResponseInfo, newLocationUrl: String) {
                request.followRedirect()
            }

            override fun onResponseStarted(request: UrlRequest, info: UrlResponseInfo) {
                statusRef.set(info.httpStatusCode)
                request.read(ByteBuffer.allocateDirect(32 * 1024))
            }

            override fun onReadCompleted(request: UrlRequest, info: UrlResponseInfo, byteBuffer: ByteBuffer) {
                byteBuffer.flip()
                val bytes = ByteArray(byteBuffer.remaining())
                byteBuffer.get(bytes)
                output.write(bytes)
                byteBuffer.clear()
                request.read(byteBuffer)
            }

            override fun onSucceeded(request: UrlRequest, info: UrlResponseInfo) {
                statusRef.set(info.httpStatusCode)
                latch.countDown()
            }

            override fun onFailed(request: UrlRequest, info: UrlResponseInfo?, error: CronetException) {
                errorRef.set(error)
                latch.countDown()
            }
        }
        try {
            engine.newUrlRequestBuilder(requestUrl, callback, executor)
                .addHeader("User-Agent", GRANTORRENT_USER_AGENT)
                .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                .addHeader("Accept-Language", "es-ES,es;q=0.9,en;q=0.7")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Referer", "$GRANTORRENT_BASE_URL/")
                .build()
                .start()
            if (!latch.await(8, java.util.concurrent.TimeUnit.SECONDS)) {
                throw IOException("Timeout Cronet desde $requestUrl")
            }
            errorRef.get()?.let { throw it }
            val status = statusRef.get()
            if (status !in 200..299) throw IOException("HTTP $status from $requestUrl")
            val body = output.toString(Charsets.UTF_8.name())
            if (body.isBlank()) throw IOException("Respuesta vacia desde $requestUrl")
            if (isCloudflareChallengeHtml(body)) throw IOException("Cloudflare challenge from $requestUrl")
            return body
        } finally {
            try { engine.shutdown() } catch (_: Throwable) {}
            executor.shutdownNow()
        }
    }

    private fun parseGrantTorrentItems(html: String, sourceUrl: String = GRANTORRENT_BASE_URL): List<GrantTorrentItem> {
        val articlePattern = Regex(
            """<article\b[^>]*class=["']([^"']*\bitem\b[^"']*)["'][^>]*>([\s\S]*?)</article>""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        val articleItems = articlePattern.findAll(html).mapNotNull { match ->
            val classes = match.groupValues[1]
            val articleHtml = match.groupValues[2]
            val url = Regex("""<a\s+[^>]*href=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .findAll(articleHtml)
                .map { normalizeGrantTorrentUrl(it.groupValues[1], sourceUrl) }
                .firstOrNull { isGrantTorrentItemUrl(it) }
                ?: return@mapNotNull null
            val title = Regex("""<h3[^>]*>\s*<a[^>]*>([\s\S]*?)</a>\s*</h3>""", RegexOption.IGNORE_CASE)
                .find(articleHtml)
                ?.groupValues
                ?.getOrNull(1)
                ?.let { htmlText(it) }
                ?.takeIf { it.isNotBlank() }
                ?: Regex("""<img[^>]*alt=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                    .find(articleHtml)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { htmlText(it) }
                    ?.takeIf { it.isNotBlank() }
                ?: titleFromGrantTorrentUrl(url)
            val date = Regex("""<span[^>]*>\s*((?:19|20)\d{2})\s*</span>""", RegexOption.IGNORE_CASE)
                .find(articleHtml)
                ?.groupValues
                ?.getOrNull(1)
                .orEmpty()
            val category = when {
                classes.contains("tvshows", ignoreCase = true) -> "Serie"
                classes.contains("movies", ignoreCase = true) -> "Película"
                else -> grantTorrentCategory(url)
            }
            GrantTorrentItem(title, url, category, "", date)
        }.toList()

        val linkPattern = Regex(
            """<a\s+[^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        val htmlItems = linkPattern.findAll(html).mapNotNull { match ->
            val url = normalizeGrantTorrentUrl(match.groupValues[1], sourceUrl)
            if (!isGrantTorrentItemUrl(url)) return@mapNotNull null
            val rawTitle = cleanGrantTorrentRawTitle(match.groupValues[2])
            val date = Regex("""\b\d{2}/\d{2}/\d{4}\b""").find(rawTitle)?.value.orEmpty()
            val quality = extractGrantTorrentQuality(rawTitle)
            val title = grantTorrentDisplayTitle(rawTitle).ifBlank { titleFromGrantTorrentUrl(url) }
            if (title.isBlank()) return@mapNotNull null
            GrantTorrentItem(
                title = title,
                url = url,
                category = grantTorrentCategory(url),
                quality = quality,
                date = date
            )
        }.toList()

        val markdownPattern = Regex(
            """(?m)^\[(.*)\]\((https://grantorrent\.wtf/(?:peliculas|series|documentales)/[^)\s"]+)""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
        )
        val markdownItems = markdownPattern.findAll(html).mapNotNull { match ->
            val url = normalizeGrantTorrentUrl(match.groupValues[2], sourceUrl)
            if (!isGrantTorrentItemUrl(url)) return@mapNotNull null
            val rawTitle = cleanGrantTorrentRawTitle(match.groupValues[1])
            if (!Regex("""\b(DVD\s*-?Rip|HDRip|HDTV|Blu\s*-?Ray|Bluray|MicroHD|BDremux|Screener|4K)\b""", RegexOption.IGNORE_CASE).containsMatchIn(rawTitle)) {
                return@mapNotNull null
            }
            val date = Regex("""\b\d{2}/\d{2}/\d{4}\b""").find(rawTitle)?.value.orEmpty()
            val quality = extractGrantTorrentQuality(rawTitle)
            val title = grantTorrentDisplayTitle(rawTitle)
            if (title.isBlank()) return@mapNotNull null
            GrantTorrentItem(title, url, grantTorrentCategory(url), quality, date)
        }.toList()

        // Filtrar 4K: demasiado pesado para streaming en móvil y causa problemas de reproducción
        return (articleItems + htmlItems + markdownItems)
            .distinctBy { it.url }
            .filter { it.quality.uppercase() != "4K" }
    }

    private fun cleanGrantTorrentRawTitle(raw: String): String {
        return htmlText(
            raw.replace(Regex("""!\[.*?\]\([^)]*\)"""), " ")
        )
            .replace(Regex("""\bImage\s+\d+:\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun extractGrantTorrentQuality(rawTitle: String): String {
        val rawQuality = Regex(
            """^(4K|DVD\s*-?Rip|HDRip|HDTV(?:[-\s]?\d+p)?|Blu\s*-?Ray[-\s]?\d+p|Bluray\d+p|MicroHD[-\s]?\d+p|BDremux[-\s]?\d+p|Screener|VHS\w*)""",
            RegexOption.IGNORE_CASE
        ).find(rawTitle)?.value.orEmpty()
        if (rawQuality.isBlank()) return ""

        val compact = rawQuality.replace(Regex("""[\s_-]+"""), "").lowercase()
        return when {
            compact == "dvdrip" -> "DVDRip"
            compact == "hdrip" -> "HDRip"
            compact.startsWith("hdtv") -> "HDTV" + compact.removePrefix("hdtv").uppercase()
            compact.startsWith("bluray") -> {
                val resolution = compact.removePrefix("bluray").uppercase()
                if (resolution.isBlank()) "BluRay" else "BluRay $resolution"
            }
            compact.startsWith("microhd") -> {
                val resolution = compact.removePrefix("microhd").uppercase()
                if (resolution.isBlank()) "MicroHD" else "MicroHD $resolution"
            }
            compact.startsWith("bdremux") -> {
                val resolution = compact.removePrefix("bdremux").uppercase()
                if (resolution.isBlank()) "BDRemux" else "BDRemux $resolution"
            }
            compact == "4k" -> "4K"
            else -> rawQuality.trim()
        }
    }

    private fun grantTorrentDisplayTitle(rawTitle: String): String {
        return rawTitle
            .replace(Regex("""\b\d{2}/\d{2}/\d{4}\b"""), "")
            .replace(Regex("""^(4K|DVD\s*-?Rip|HDRip|HDTV(?:[-\s]?\d+p)?|Blu\s*-?Ray[-\s]?\d+p|Bluray\d+p|MicroHD[-\s]?\d+p|BDremux[-\s]?\d+p|Screener|VHS\w*)\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\[(?:4K|720p|1080p|HDTV|Blu\s*-?Ray[-\s]?\d+p|Bluray\d+p|DVD\s*-?Rip|HDRip|MicroHD[-\s]?\d+p|BDremux[-\s]?\d+p)\]""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\b(?:DonTorrent|GranTorrent)\b""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\s+"""), " ")
            .trim(' ', '-', '|', '·')
    }

    private fun titleFromGrantTorrentUrl(url: String): String {
        val slug = try {
            Uri.parse(url).lastPathSegment.orEmpty()
        } catch (_: Throwable) {
            url.substringAfterLast('/').substringBefore('?')
        }
        return URLDecoder.decode(slug, "UTF-8")
            .replace(Regex("""[-_]+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word -> word.lowercase().replaceFirstChar { it.titlecase() } }
    }

    private fun normalizeGrantTorrentUrl(url: String, sourceUrl: String = GRANTORRENT_BASE_URL): String {
        val clean = url.trim().replace("&amp;", "&")
        val resolved = try {
            val base = URL(if (sourceUrl.endsWith("/")) sourceUrl else "$sourceUrl/")
            URL(base, clean).toString().replaceFirst("http://", "https://", ignoreCase = true)
        } catch (_: Throwable) {
            when {
                clean.startsWith("http://", ignoreCase = true) -> clean.replaceFirst("http://", "https://", ignoreCase = true)
                clean.startsWith("https://", ignoreCase = true) -> clean
                clean.startsWith("/") -> "$GRANTORRENT_BASE_URL$clean"
                else -> "$GRANTORRENT_BASE_URL/$clean"
            }
        }
        return forceGrantTorrentWtfUrl(resolved)
    }

    private fun forceGrantTorrentWtfUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase()?.removePrefix("www.").orEmpty()
            if (host == "grantorrent.wtf" || !host.startsWith("grantorrent.")) return url
            uri.buildUpon()
                .scheme("https")
                .authority("grantorrent.wtf")
                .build()
                .toString()
        } catch (_: Throwable) {
            url
        }
    }

    private fun isGrantTorrentItemUrl(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase()?.removePrefix("www.") ?: return false
            if (host !in GRANTORRENT_LINK_HOSTS) return false
            val segments = uri.pathSegments
            if (segments.size < 2) return false
            val section = segments[0].lowercase()
            if (section !in setOf("peliculas", "series", "documentales")) return false
            val slug = segments[1].trim()
            slug.isNotBlank() && slug !in setOf("page", "feed")
        } catch (_: Throwable) {
            false
        }
    }

    private fun grantTorrentCategory(url: String): String {
        val path = Uri.parse(url).path.orEmpty().lowercase()
        return when {
            path.startsWith("/series") -> "Serie"
            path.startsWith("/documentales") -> "Documental"
            else -> "Película"
        }
    }

    private fun htmlText(value: String): String {
        val stripped = stripHtml(value)
            .replace("&nbsp;", " ")
            .replace("&#160;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            android.text.Html.fromHtml(stripped, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            @Suppress("DEPRECATION")
            android.text.Html.fromHtml(stripped).toString()
        }.replace(Regex("""\s+"""), " ").trim()
    }

    private fun showGrantTorrentSelector(item: GrantTorrentItem) {
        showToast("Resolviendo torrent automáticamente...")
        Thread {
            val detail = try {
                loadGrantTorrentDetail(item)
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "HTTP directo falló para GrantTorrent: ${error.message}")
                null
            }
            handler.post {
                if (detail != null && detail.torrentUrl.isNotBlank()) {
                    if (isTorrentPlaybackSource(detail.torrentUrl)) {
                        startGrantTorrentPlayback(detail)
                    } else {
                        openGrantTorrentViewer(detail.item, detail.torrentUrl)
                    }
                } else {
                    openGrantTorrentViewer(item, item.url)
                    showToast("No se pudo obtener el torrent automáticamente")
                }
            }
        }.start()
    }

    private fun isTorrentPlaybackSource(url: String): Boolean {
        val clean = url.substringBefore('?')
        return clean.startsWith("magnet:", ignoreCase = true) ||
            clean.endsWith(".torrent", ignoreCase = true) ||
            clean.startsWith("file:", ignoreCase = true)
    }

    private fun openGrantTorrentViewer(item: GrantTorrentItem, url: String) {
        Log.d(LOG_TAG, "Catalogo torrent externo desactivado: ${item.title} -> $url")
        showToast("Catalogo torrent desactivado")
    }

    private fun saveGrantTorrentTorrentData(sourceUrl: String, base64Data: String): File {
        val bytes = Base64.decode(base64Data, Base64.DEFAULT)
        if (bytes.size < 32 || bytes.firstOrNull()?.toInt()?.toChar() != 'd') {
            throw IOException(".torrent vacio o invalido")
        }
        val safeName = Uri.parse(sourceUrl).lastPathSegment
            ?.replace(Regex("""[\\/:*?"<>|]+"""), "_")
            ?.takeIf { it.endsWith(".torrent", ignoreCase = true) }
            ?: "grantorrent_${System.currentTimeMillis()}.torrent"
        val dir = File(cacheDir, "grantorrent_torrents").apply { mkdirs() }
        return File(dir, safeName).apply {
            writeBytes(bytes)
        }
    }

    private fun loadGrantTorrentDetail(item: GrantTorrentItem): GrantTorrentDetail {
        val html = fetchGrantTorrentText(item.url)
        val linkPattern = Regex(
            """<a\s+[^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        var torrentUrl = linkPattern.findAll(html).firstNotNullOfOrNull { match ->
            val href = match.groupValues[1].trim()
            val text = htmlText(match.groupValues[2])
            val normalizedHref = normalizeGrantTorrentUrl(href, item.url)
            val cleanHref = normalizedHref.lowercase()
            val looksTorrent = text.contains("Descargar Torrent", ignoreCase = true) ||
                isTorrentPlaybackSource(normalizedHref) ||
                (cleanHref.contains("torrent") && !cleanHref.contains("/ayuda"))
            if (looksTorrent) normalizedHref else null
        }.orEmpty()

            val summary = Regex("""Resumen\s*</?[^>]*>\s*(.*?)\s*(?:<h\d|También te puede interesar|Pasos para descargar)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { htmlText(it) }
            .orEmpty()
        if (torrentUrl.isBlank()) {
            torrentUrl = Regex("""\[Descargar Torrent]\((https?://(?:grantorrent\.wtf|grantorrent\.quest|grantorrent\.org)/torrents/[^)]+\.torrent)\)""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1)
                .orEmpty()
        }
        if (torrentUrl.isBlank()) {
            torrentUrl = linkPattern.findAll(html).firstNotNullOfOrNull { match ->
                val href = match.groupValues[1].trim()
                val text = htmlText(match.groupValues[2])
                val normalizedHref = normalizeGrantTorrentUrl(href, item.url)
                val cleanHref = normalizedHref.lowercase()
                val isDownloadPage = text.equals("Descarga", ignoreCase = true) ||
                    text.contains("Descarga", ignoreCase = true) ||
                    cleanHref.contains("/enlaces/") ||
                    cleanHref.contains("free.7hd.club/")
                if (isDownloadPage) normalizedHref else null
            }.orEmpty()
        }
        return GrantTorrentDetail(item, torrentUrl, summary)
    }

    private fun resolveDonTorrentProtectedTorrentUrl(item: GrantTorrentItem): String? {
        val parsed = grantTorrentContentIdAndTable(item) ?: return null
        val contentId = parsed.first
        val table = parsed.second
        val referer = donTorrentRefererFor(item, contentId, table)
        val generateBody = JSONObject()
            .put("action", "generate")
            .put("content_id", contentId)
            .put("tabla", table)
            .toString()
        val challengeJson = postDonTorrentPowJson(generateBody, referer)
        val challenge = JSONObject(challengeJson).optString("challenge")
        if (challenge.isBlank()) throw IOException("DonTorrent no devolvio challenge")

        val nonce = computeDonTorrentProofOfWork(challenge)
        val validateBody = JSONObject()
            .put("action", "validate")
            .put("challenge", challenge)
            .put("nonce", nonce)
            .toString()
        val validateJson = postDonTorrentPowJson(validateBody, referer)
        val obj = JSONObject(validateJson)
        if (!obj.optBoolean("success", false)) {
            throw IOException(obj.optString("error").ifBlank { "Validacion DonTorrent fallida" })
        }
        return normalizeDonTorrentDownloadUrl(obj.optString("download_url"))
    }

    private fun grantTorrentContentIdAndTable(item: GrantTorrentItem): Pair<Int, String>? {
        val pathSegments = try { Uri.parse(item.url).pathSegments } catch (_: Throwable) { emptyList() }
        if (pathSegments.size < 2) return null
        val section = pathSegments[0].lowercase()
        val id = pathSegments[1].substringBefore("-").toIntOrNull() ?: return null
        val table = when (section) {
            "peliculas" -> "peliculas"
            "series" -> "series"
            "documentales" -> "documentales"
            else -> return null
        }
        return id to table
    }

    private fun donTorrentRefererFor(item: GrantTorrentItem, contentId: Int, table: String): String {
        val slug = Uri.parse(item.url).lastPathSegment
            ?.substringAfter("-", "")
            ?.takeIf { it.isNotBlank() }
            ?: item.title.replace(Regex("""[^\p{L}\p{N}]+"""), "-").trim('-')
        val path = when (table) {
            "peliculas" -> "pelicula/$contentId/$slug"
            "series" -> "serie/$contentId/$contentId/$slug"
            "documentales" -> "documental/$contentId/$slug"
            else -> ""
        }
        return "$DONTORRENT_BASE_URL/$path"
    }

    private fun postDonTorrentPowJson(body: String, referer: String): String {
        val connection = (URL("$DONTORRENT_BASE_URL/api_validate_pow.php").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 20_000
            doOutput = true
            setRequestProperty("User-Agent", COMPATIBLE_USER_AGENT)
            setRequestProperty("Accept", "application/json,text/plain,*/*")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Origin", DONTORRENT_BASE_URL)
            setRequestProperty("Referer", referer)
        }
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
            ?.bufferedReader()
            ?.use { it.readText() }
            .orEmpty()
        connection.disconnect()
        if (code !in 200..299) throw IOException("DonTorrent HTTP $code")
        return response
    }

    private fun computeDonTorrentProofOfWork(challenge: String): Int {
        val digest = MessageDigest.getInstance("SHA-256")
        var nonce = 0
        while (nonce < 2_000_000) {
            val hash = digest.digest((challenge + nonce).toByteArray(Charsets.UTF_8))
            if (hash.size >= 2 && hash[0].toInt() == 0 && (hash[1].toInt() and 0xF0) == 0) return nonce
            nonce++
        }
        throw IOException("Proof of Work DonTorrent agotado")
    }

    private fun normalizeDonTorrentDownloadUrl(value: String): String? {
        val clean = value.trim()
            .replace("\\/", "/")
            .replace("&amp;", "&")
        if (clean.isBlank()) return null
        return when {
            clean.startsWith("//") -> "https:$clean"
            clean.startsWith("/") -> "$DONTORRENT_BASE_URL$clean"
            clean.startsWith("http://", ignoreCase = true) -> clean.replaceFirst("http://", "https://", ignoreCase = true)
            clean.startsWith("https://", ignoreCase = true) -> clean
            else -> null
        }
    }

    private fun startGrantTorrentPlayback(detail: GrantTorrentDetail) {
        val item = grantTorrentCatalogItem(detail)
        proceedWithTorrentDownload(
            addon = "Torrent",
            magnetUri = detail.torrentUrl,
            fileIdx = null,
            quality = detail.item.quality.ifBlank { "Torrent" },
            size = "",
            seeders = "?",
            item = item,
            useVlcPlayer = true
        )
    }

    private fun grantTorrentCatalogItem(detail: GrantTorrentDetail): CatalogItem {
        val source = detail.item
        return CatalogItem(
            id = "grant:${source.url}",
            title = source.title,
            originalTitle = source.title,
            type = if (source.category == "Serie") "series" else "movie",
            year = source.date.takeLast(4),
            runtime = "",
            imdbId = "",
            tmdbId = "",
            rating = "",
            overview = detail.summary,
            genres = listOf(source.category),
            posterUrl = "",
            backgroundUrl = "",
            embeds = emptyMap()
        )
    }

    private fun loadMegaSeriesCatalog() {
        if (megaLoading) return
        megaLoading = true
        Log.d(LOG_TAG, "Loading MegaSeries catalog...")
        Thread {
            try {
                val series = MegaSeriesManager.fetchSeriesCatalog()
                handler.post {
                    megaLoading = false
                    megaSeriesList = series
                    Log.d(LOG_TAG, "MegaDescargas catalog loaded: ${series.size} series")
                    if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                        renderCatalogItems(currentSearchQuery())
                    }
                }
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Error loading MegaSeries catalog: ${e.message}", e)
                handler.post {
                    megaLoading = false
                    megaSeriesList = emptyList()
                    if (currentScreen == Screen.CATALOG && currentNavTab == NavTab.HOME) {
                        renderCatalogItems(currentSearchQuery())
                    }
                }
            }
        }.start()
    }

    private fun scrapeMegaDescargasCatalog(): List<MegaSeries> {
        val catalogUrls = listOf(
            MEGA_SERIES_CATALOG_URL,
            "$MEGA_SERIES_CATALOG_URL/p/catalogo-de-series.html",
            "https://megadescargas-new.blogspot.com"
        )
        return catalogUrls.flatMap { url ->
            try {
                parseMegaSeriesFromHtml(fetchText(url, "text/html", null))
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Error scraping MegaDescargas desde $url: ${e.message}")
                emptyList()
            }
        }.distinctBy { it.url }.take(100)
    }

    private fun parseMegaSeriesFromHtml(html: String): List<MegaSeries> {
        val result = mutableListOf<MegaSeries>()
        val postPattern = Regex(
            """<a\s+[^>]*href=["'](https?://[^"']+)["'][^>]*>(.*?)</a>""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        postPattern.findAll(html).forEach { m ->
            val url = normalizeMegaSeriesUrl(m.groupValues[1])
            if (!isMegaSeriesCandidate(url)) return@forEach
            val title = extractMegaSeriesTitle(m.groupValues[2], url)
            if (isUsefulMegaSeriesTitle(title)) {
                result.add(MegaSeries(
                    id = url.hashCode().toString(),
                    title = title,
                    posterUrl = "",
                    year = "",
                    rating = "",
                    description = "",
                    seasons = emptyList(),
                    url = url
                ))
            }
        }
        return result.distinctBy { it.url }
    }

    private fun normalizeMegaSeriesUrl(url: String): String =
        url.trim()
            .replace("hhttps://", "https://")
            .replace("http://", "https://")

    private fun isMegaSeriesCandidate(url: String): Boolean {
        return try {
            val parsed = URL(url)
            val host = parsed.host.lowercase().removePrefix("www.")
            val path = parsed.path.orEmpty()
            if (host !in MEGA_SERIES_LINK_HOSTS) return false
            if (host == "tinyurl.com") return path.trim('/').length >= 4
            if (path.startsWith("/p/", ignoreCase = true)) return false
            path.endsWith(".html", ignoreCase = true)
        } catch (_: Throwable) {
            false
        }
    }

    private fun extractMegaSeriesTitle(anchorHtml: String, url: String): String {
        val titleAttr = Regex("""\btitle=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            .find(anchorHtml)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { htmlText(it) }
            ?.trim()
        if (!titleAttr.isNullOrBlank() && !titleAttr.startsWith("http", ignoreCase = true)) {
            return titleAttr
        }
        val text = stripHtml(anchorHtml)
            .replace("&nbsp;", " ")
            .replace("&#160;", " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        if (text.length >= 4 && !text.startsWith("http", ignoreCase = true)) return text
        return titleFromMegaSeriesUrl(url)
    }

    private fun isUsefulMegaSeriesTitle(title: String): Boolean {
        val clean = title.trim()
        if (clean.length < 3) return false
        val normalized = clean.lowercase()
            .replace("í", "i")
            .replace("é", "e")
            .replace("á", "a")
            .replace("ó", "o")
            .replace("ú", "u")
        val blocked = setOf(
            "series",
            "indice de series",
            "catalogo de series",
            "listado de series",
            "mega descargas",
            "descargar series mega"
        )
        return normalized !in blocked
    }

    private fun extractMegaUrlsFromText(value: String): List<String> {
        val variants = decodedTextVariants(value)
        val patterns = listOf(
            Regex("""https?://mega\.nz/(?:file|folder|#)[^\s"'<>\\)]+""", RegexOption.IGNORE_CASE),
            Regex("""mega\.nz/(?:file|folder|#)[^\s"'<>\\)]+""", RegexOption.IGNORE_CASE)
        )
        return variants.flatMap { variant ->
            patterns.flatMap { pattern -> pattern.findAll(variant).map { it.value } }
        }.mapNotNull { cleanMegaUrlCandidate(it) }.distinct()
    }

    private fun extractShortenerUrlsFromText(value: String): List<String> {
        val hosts = """ouo\.io|ouo\.press|shrinkme\.io|adshort\.co|adf\.ly|bc\.vc|cuty\.io|exe\.io|gplinks\.co|oke\.io|za\.gl|link1s\.com|short\.pe|clk\.sh|bit\.ly|tinyurl\.com|rebrand\.ly|linkvertise\.com|shon\.xyz|adbull\.org|cpmlink\.net"""
        val pattern = Regex("""https?://(?:$hosts)[^\s"'<>\\)]+""", RegexOption.IGNORE_CASE)
        return decodedTextVariants(value)
            .flatMap { variant -> pattern.findAll(variant).map { it.value } }
            .map { it.trim().trimEnd('.', ',', ';', ')', ']', '}') }
            .distinct()
    }

    private fun decodedTextVariants(value: String): List<String> {
        val variants = linkedSetOf(value, htmlText(value))
        variants.toList().forEach { base ->
            variants += base.replace("\\/", "/").replace("\\u002F", "/").replace("\\u003A", ":")
        }
        repeat(2) {
            variants.toList().forEach { candidate ->
                try {
                    variants += URLDecoder.decode(candidate, "UTF-8")
                } catch (_: Throwable) {
                }
            }
        }
        return variants.toList()
    }

    private fun cleanMegaUrlCandidate(value: String): String? {
        var clean = value
            .replace("\\/", "/")
            .replace("\\u002F", "/")
            .replace("\\u003A", ":")
            .replace("&amp;", "&")
            .trim()
            .trimEnd('.', ',', ';', ')', ']', '}', '"', '\'')
        if (clean.startsWith("mega.nz/", ignoreCase = true)) clean = "https://$clean"
        return clean.takeIf {
            it.startsWith("https://mega.nz/", ignoreCase = true) ||
                it.startsWith("http://mega.nz/", ignoreCase = true)
        }?.replaceFirst("http://", "https://", ignoreCase = true)
    }

    private fun stripHtml(value: String): String =
        value.replace(Regex("""<[^>]+>"""), " ")

    private fun titleFromMegaSeriesUrl(url: String): String {
        val slug = try {
            URL(url).path.trim('/').substringAfterLast('/').substringBeforeLast(".html")
        } catch (_: Throwable) {
            url.substringAfterLast('/').substringBefore('?')
        }
        var cleaned = URLDecoder.decode(slug, "UTF-8")
            .replace(Regex("""[-_]+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        listOf("serie completa", "latino", "castellano", "espanol", "español").forEach { suffix ->
            cleaned = cleaned.replace(Regex("""\b${Regex.escape(suffix)}\b""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }
        return cleaned.split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase().replaceFirstChar { first -> first.titlecase() }
            }
    }

    // NOTA: Las siguientes funciones han sido reemplazadas por MegaSeriesManager.kt
    // y ya no se utilizan. Se mantienen comentadas por referencia.
    
    /*
    private fun loadMegaSeriesDetail(series: MegaSeries, onResult: (MegaSeries) -> Unit) {
        Thread {
            try {
                val html = fetchText(series.url, "text/html", null)
                val seasons = parseMegaSeasonsFromHtml(html)
                handler.post { onResult(series.copy(seasons = seasons)) }
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Error loading series detail: ${e.message}")
                handler.post { onResult(series) }
            }
        }.start()
    }

    private fun parseMegaSeasonsFromHtml(html: String): List<MegaSeason> {
        // ... código antiguo comentado ...
        return emptyList()
    }

    private fun parseGoogleDocsMegaSeasonsFromHtml(html: String): List<MegaSeason> {
        // ... código antiguo comentado ...
        return emptyList()
    }
    
    private fun resolveMegaShorteners(seasons: List<MegaSeason>): List<MegaSeason> {
        // ... código antiguo comentado ...
        return seasons
    }
    
    private fun cleanMegaEpisodeTitle(title: String, episodeNumber: Int): String {
        val legacySuffix = "(" + "acort" + "ador" + ")"
        return title.replace(legacySuffix, "", ignoreCase = true)
            .trim()
            .ifBlank { "Episodio $episodeNumber" }
    }
    */

    private fun extractGoogleDocsTextAndLinks(html: String): Pair<String, List<MegaDocLink>>? {
        val chunks = Regex(
            """DOCS_modelChunk\s*=\s*(\{.*?});\s*DOCS_modelChunkLoadStart""",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        ).findAll(html).toList()
        if (chunks.isEmpty()) return null

        val text = StringBuilder()
        val links = mutableListOf<MegaDocLink>()
        chunks.forEach { match ->
            val json = match.groupValues[1]
            val array = try {
                JSONObject(json).optJSONArray("chunk")
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "No se pudo parsear DOCS_modelChunk", error)
                null
            } ?: return@forEach

            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                if (obj.optString("ty") == "is") {
                    text.append(obj.optString("s"))
                    continue
                }
                val url = obj.optJSONObject("sm")
                    ?.optJSONObject("lnks_link")
                    ?.optString("ulnk_url")
                    ?.trim()
                    .orEmpty()
                if (url.isBlank()) continue
                val start = obj.optInt("si", -1)
                val end = obj.optInt("ei", -1)
                if (start >= 0 && end > start) links += MegaDocLink(start, end, url)
            }
        }

        return text.toString().takeIf { it.isNotBlank() }?.let { it to links }
    }

    private fun googleDocsEpisodeTitle(line: String, season: Int, episode: Int): String {
        val clean = line
            .replace(Regex("""\s*\|\s*Mega.*$""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""^Episodio\s+\d+\s*x\s*\d+\s*:?\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
        return if (clean.isBlank()) "Ep $episode" else "Ep $episode - $clean"
    }

    private fun String.safeSubstring(start: Int, end: Int): String {
        val safeStart = start.coerceIn(0, length)
        val safeEnd = end.coerceIn(safeStart, length)
        return substring(safeStart, safeEnd)
    }

    // NOTA: Funciones antiguas comentadas - ahora se usa MegaSeriesManager.kt
    /*
    private fun resolveMegaShorteners(seasons: List<MegaSeason>): List<MegaSeason> {
        return seasons.map { season ->
            val episodes = season.episodes.mapNotNull { episode ->
                if (episode.megaUrl.startsWith("https://mega.nz") || episode.megaUrl.startsWith("mega://")) {
                    episode
                } else {
                    followShortenerToMega(episode.megaUrl, 12)?.let { direct ->
                        episode.copy(
                            title = cleanMegaEpisodeTitle(episode.title, episode.episodeNumber),
                            megaUrl = direct
                        )
                    }
                }
            }.distinctBy { it.megaUrl }
            season.copy(episodes = episodes)
        }.filter { it.episodes.isNotEmpty() }
    }

    private fun cleanMegaEpisodeTitle(title: String, episodeNumber: Int): String {
        val legacySuffix = "(" + "acort" + "ador" + ")"
        return title.replace(legacySuffix, "", ignoreCase = true)
            .trim()
            .ifBlank { "Episodio $episodeNumber" }
    }
    */

    private fun showMegaSeriesSelector(series: com.kotatv.MegaSeries) {
        
        // Verificar que tenemos la URL de la serie
        if (series.url.isBlank()) {
            android.widget.Toast.makeText(
                this,
                "No se pudo obtener la URL de la serie",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        
        // Mostrar un diálogo de progreso
        startActivity(Intent(this, MegaSeriesViewerActivity::class.java).apply {
            putExtra(MegaSeriesViewerActivity.EXTRA_URL, series.url)
            putExtra(MegaSeriesViewerActivity.EXTRA_SERIES_TITLE, series.title)
            putExtra(MegaSeriesViewerActivity.EXTRA_MODE, MegaSeriesViewerActivity.MODE_SERIES_CATALOG)
        })
    }

    private fun showMegaEpisodeDialog(series: com.kotatv.MegaSeries) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFF0D1117.toInt())
        }
        
        // Título de la serie
        container.addView(TextView(this).apply {
            text = series.title
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(0, 0, 0, dp(16))
        })
        
        // Mostrar cada temporada con sus episodios
        series.seasons.forEach { season ->
            // Encabezado de temporada
            container.addView(TextView(this).apply {
                text = "Temporada ${season.number}"
                setTextColor(0xFFFFD700.toInt()) // Dorado
                textSize = 15f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setPadding(0, dp(12), 0, dp(8))
            })
            
            // Episodios de la temporada
            season.episodes.forEach { episode ->
                container.addView(createEpisodeButton(series, season, episode))
            }
        }
        
        // Mostrar en un diálogo con scroll
        val scroll = android.widget.ScrollView(this).apply {
            addView(container)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        
        val dialog = android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setView(scroll)
            .setNegativeButton("Cerrar", null)
            .create()
        
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }
    
    private fun createEpisodeButton(
        series: com.kotatv.MegaSeries,
        season: com.kotatv.Season,
        episode: com.kotatv.Episode
    ): View {
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(0xFF1A1A1A.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), 0xFF333333.toInt())
            }
            
            setOnClickListener {
                // Si hay múltiples enlaces, mostrar selector
                if (episode.shortenerLinks.size > 1) {
                    showEpisodeLinkSelector(series, season, episode)
                } else if (episode.shortenerLinks.isNotEmpty()) {
                    openEpisodeInShortenerViewer(series, season, episode, episode.shortenerLinks[0])
                }
            }
        }
        
        // Número de episodio
        button.addView(TextView(this).apply {
            text = "Ep ${episode.number}"
            setTextColor(0xFF00D9FF.toInt()) // Cyan
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            minWidth = dp(50)
        })
        
        // Título del episodio
        button.addView(TextView(this).apply {
            text = episode.title
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setPadding(dp(12), 0, 0, 0)
            maxLines = 2
        }, LinearLayout.LayoutParams(0, -2, 1f))
        
        // Indicador de múltiples enlaces
        if (episode.shortenerLinks.size > 1) {
            button.addView(TextView(this).apply {
                text = "${episode.shortenerLinks.size} enlaces"
                setTextColor(0xFF888888.toInt())
                textSize = 11f
                setPadding(dp(8), 0, 0, 0)
            })
        }
        
        return LinearLayout(this).apply {
            addView(button, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(6)
            })
        }
    }
    
    private fun showEpisodeLinkSelector(
        series: com.kotatv.MegaSeries,
        season: com.kotatv.Season,
        episode: com.kotatv.Episode
    ) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        
        container.addView(TextView(this).apply {
            text = "Selecciona un enlace"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(0, 0, 0, dp(12))
        })
        
        episode.shortenerLinks.forEachIndexed { index, link ->
            container.addView(TextView(this).apply {
                text = "Enlace ${index + 1}"
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(0xFF1A1A1A.toInt())
                    cornerRadius = dp(6).toFloat()
                }
                setOnClickListener {
                    openEpisodeInShortenerViewer(series, season, episode, link)
                }
            }, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(6)
            })
        }
        
        android.app.AlertDialog.Builder(this)
            .setView(container)
            .setNegativeButton("Cancelar", null)
            .show()
    }
    
    private fun openEpisodeInShortenerViewer(
        series: com.kotatv.MegaSeries,
        season: com.kotatv.Season,
        episode: com.kotatv.Episode,
        shortenerUrl: String
    ) {
        Log.d(LOG_TAG, "Opening episode: ${series.title} S${season.number}E${episode.number} -> $shortenerUrl")
        
        val intent = Intent(this, MegaSeriesViewerActivity::class.java).apply {
            putExtra(MegaSeriesViewerActivity.EXTRA_URL, shortenerUrl)
            putExtra(MegaSeriesViewerActivity.EXTRA_SERIES_TITLE, series.title)
            putExtra(MegaSeriesViewerActivity.EXTRA_SEASON, season.number)
            putExtra(MegaSeriesViewerActivity.EXTRA_EPISODE, episode.number)
        }
        startActivity(intent)
    }

    // -- Mega.nz -------------------------------------------------------------------
    // Mega no expone un stream directo reproducible: se obtiene el enlace temporal,
    // se muestra el peso real, se descarga/descifra el archivo y luego se entrega a VLC.
    private fun getMegaUserAgent(): String = COMPATIBLE_USER_AGENT

    private fun isDirectPlayableVideoUrl(url: String): Boolean {
        val clean = url.substringBefore('?').lowercase()
        return clean.endsWith(".m3u8") ||
            clean.endsWith(".mp4") ||
            clean.endsWith(".mkv") ||
            clean.endsWith(".m4v") ||
            clean.endsWith(".webm") ||
            clean.endsWith(".ts")
    }

    private fun showDirectVlcPlayer(title: String, videoUrl: String) {
        val item = CatalogItem(
            id = "direct:${videoUrl.hashCode()}",
            title = title,
            originalTitle = title,
            type = "movie",
            year = "",
            runtime = "",
            imdbId = "",
            tmdbId = "",
            rating = "",
            overview = "",
            genres = emptyList(),
            posterUrl = "",
            backgroundUrl = "",
            embeds = emptyMap()
        )
        currentTorrentVideoUrl = videoUrl
        showTorrentPlayerShell(item)
        handler.post { showEmbeddedVlcTorrentPlayer(videoUrl) }
    }

    private var lastMegaUrl: String? = null  // Para reintentos
    
    private fun startMegaDownloadAndPlay(url: String) {
        lastMegaUrl = url  // Guardar para reintentos
        val normalizedUrl = normalizeMegaPlaybackUrl(url)
        if (isMegaFolderLink(normalizedUrl)) {
            android.widget.Toast.makeText(this, "Buscando videos en carpeta Mega...", android.widget.Toast.LENGTH_SHORT).show()
            Thread {
                try {
                    val videoFile = findVideoInMegaFolder(normalizedUrl)
                    handler.post {
                        if (videoFile != null) {
                            Log.d(LOG_TAG, "Video encontrado en carpeta: $videoFile")
                            startMegaDownloadAndPlay(videoFile)
                        } else {
                            android.app.AlertDialog.Builder(this)
                                .setTitle("Mega")
                                .setMessage("No se encontraron archivos de video (.mp4, .mkv, .avi) en esta carpeta.")
                                .setPositiveButton("Abrir Mega") { _, _ -> openMegaExternally(normalizedUrl) }
                                .setNegativeButton("Cerrar", null)
                                .show()
                        }
                    }
                } catch (e: Exception) {
                    Log.e(LOG_TAG, "Error buscando videos en carpeta Mega: ${e.message}", e)
                    handler.post {
                        android.app.AlertDialog.Builder(this)
                            .setTitle("Mega")
                            .setMessage("Error al buscar videos en la carpeta. Abre Mega manualmente.")
                            .setPositiveButton("Abrir Mega") { _, _ -> openMegaExternally(normalizedUrl) }
                            .setNegativeButton("Cerrar", null)
                            .show()
                    }
                }
            }.start()
            return
        }
        if (parseMegaFileLink(normalizedUrl) == null) {
            showToast("Enlace Mega no reconocido")
            return
        }

        val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
        val paused = java.util.concurrent.atomic.AtomicBoolean(false)
        val lastDialogMessage = java.util.concurrent.atomic.AtomicReference("Leyendo peso...")
        lateinit var dialog: android.app.AlertDialog
        val dialogChrome = createMegaDownloadDialogChrome("Mega") {
            confirmMegaDownloadCancellation(cancelled, dialog)
        }
        dialog = android.app.AlertDialog.Builder(this)
            .setCustomTitle(dialogChrome.view)
            .setMessage(lastDialogMessage.get())
            .setNeutralButton("Navegador", null)
            .setNegativeButton("Pausar", null)
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
        dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL)?.visibility = View.GONE
        dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)?.setOnClickListener { button ->
            val nowPaused = !paused.get()
            paused.set(nowPaused)
            (button as? TextView)?.text = if (nowPaused) "Reanudar" else "Pausar"
            val base = lastDialogMessage.get()
            dialog.setMessage(
                if (nowPaused) {
                    base.replace("Descargando", "Pausado")
                } else {
                    base.replace("Pausado", "Descargando")
                }
            )
        }

        Thread {
            mega509RetryCount = 0
            try {
                val info = loadMegaFileDownloadInfo(normalizedUrl)
                val target = megaDownloadTargetFile(info.title)
                handler.post {
                    if (dialog.isShowing) {
                        dialogChrome.titleText.text = info.title
                        val message = megaDownloadStatusMessage(info, 0L, paused.get())
                        lastDialogMessage.set(message)
                        dialog.setMessage(message)
                        configureMegaBrowserButton(dialog, info, normalizedUrl)
                    }
                }

                // SIEMPRE descargar completamente antes de reproducir
                val file = if (target.exists() && target.length() == info.sizeBytes) {
                    Log.d(LOG_TAG, "Archivo Mega ya descargado: ${target.name}")
                    target
                } else {
                    Log.d(LOG_TAG, "Descargando archivo Mega completamente antes de reproducir...")
                    var lastUiUpdate = 0L
                    downloadAndDecryptMegaFile(info, target, cancelled, paused) { downloaded ->
                        val now = System.currentTimeMillis()
                        if (now - lastUiUpdate > 500L || downloaded >= info.sizeBytes) {
                            lastUiUpdate = now
                            handler.post {
                                if (dialog.isShowing) {
                                    val message = megaDownloadStatusMessage(info, downloaded, paused.get())
                                    lastDialogMessage.set(message)
                                    dialog.setMessage(message)
                                }
                            }
                        }
                    }
                }
                
                // Verificar que la descarga se completó
                if (cancelled.get()) {
                    Log.d(LOG_TAG, "Descarga Mega cancelada por el usuario")
                    return@Thread
                }
                
                if (!file.exists() || file.length() != info.sizeBytes) {
                    throw IOException("La descarga no se completó correctamente")
                }
                
                Log.d(LOG_TAG, "Descarga Mega completada. Reproduciendo: ${file.name}")
                
                // Reproducir SOLO después de que la descarga esté completa
                handler.post {
                    dialog.dismiss()
                    showDirectVlcPlayer(info.title, Uri.fromFile(file).toString())
                }
            } catch (error: Throwable) {
                if (cancelled.get() || error.message == "Descarga cancelada") {
                    handler.post {
                        if (dialog.isShowing) dialog.dismiss()
                        showToast("Descarga Mega cancelada")
                    }
                    return@Thread
                }
                if (error.message?.startsWith("MEGA_509:") == true && mega509RetryCount < 3) {
                    handler.post {
                        if (dialog.isShowing) dialog.dismiss()
                        android.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Límite de transferencia Mega")
                            .setMessage("Mega ha limitado temporalmente la descarga para esta IP.\n\nPuedes esperar 30 segundos e intentarlo de nuevo, o abrir el enlace directamente en la app de Mega.")
                            .setPositiveButton("Reintentar en 30 s") { _, _ ->
                                mega509RetryCount++
                                handler.postDelayed({
                                    Thread {
                                        var newDialog: android.app.AlertDialog? = null
                                        try {
                                            val info2 = loadMegaFileDownloadInfo(normalizedUrl)
                                            val target2 = megaDownloadTargetFile(info2.title)
                                            val retryMessage = java.util.concurrent.atomic.AtomicReference(
                                                megaDownloadStatusMessage(info2, 0L, paused.get())
                                            )
                                            val retryChrome = createMegaDownloadDialogChrome(info2.title) {
                                                newDialog?.let { confirmMegaDownloadCancellation(cancelled, it) }
                                            }
                                            newDialog = android.app.AlertDialog.Builder(this@MainActivity)
                                                .setCustomTitle(retryChrome.view)
                                                .setMessage(retryMessage.get())
                                                .setNeutralButton("Navegador", null)
                                                .setNegativeButton("Pausar", null)
                                                .create()
                                            handler.post {
                                                val activeDialog = newDialog ?: return@post
                                                activeDialog.setCancelable(false)
                                                activeDialog.setCanceledOnTouchOutside(false)
                                                activeDialog.show()
                                                retryChrome.titleText.text = info2.title
                                                configureMegaBrowserButton(activeDialog, info2, normalizedUrl)
                                                activeDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)?.setOnClickListener { button ->
                                                    val nowPaused = !paused.get()
                                                    paused.set(nowPaused)
                                                    (button as? TextView)?.text = if (nowPaused) "Reanudar" else "Pausar"
                                                    val base = retryMessage.get()
                                                    activeDialog.setMessage(
                                                        if (nowPaused) {
                                                            base.replace("Descargando", "Pausado")
                                                        } else {
                                                            base.replace("Pausado", "Descargando")
                                                        }
                                                    )
                                                }
                                            }
                                            val file2 = downloadAndDecryptMegaFile(info2, target2, cancelled, paused) { downloaded ->
                                                handler.post {
                                                    val activeDialog = newDialog
                                                    if (activeDialog?.isShowing == true) {
                                                        val message = megaDownloadStatusMessage(info2, downloaded, paused.get())
                                                        retryMessage.set(message)
                                                        activeDialog.setMessage(message)
                                                    }
                                                }
                                            }
                                            if (!cancelled.get() && file2.exists() && file2.length() == info2.sizeBytes) {
                                                Log.d(LOG_TAG, "Reintento exitoso. Reproduciendo: ${file2.name}")
                                                handler.post {
                                                    newDialog?.dismiss()
                                                    showDirectVlcPlayer(info2.title, Uri.fromFile(file2).toString())
                                                }
                                            }
                                        } catch (e2: Throwable) {
                                            handler.post {
                                                if (newDialog?.isShowing == true) newDialog?.dismiss()
                                                if (cancelled.get() || e2.message == "Descarga cancelada") {
                                                    showToast("Descarga Mega cancelada")
                                                } else {
                                                    showMegaDownloadError(e2)
                                                }
                                            }
                                        }
                                    }.start()
                                }, 30_000L)
                            }
                            .setNegativeButton("Abrir en Mega") { _, _ ->
                                openMegaExternally(normalizedUrl)
                            }
                            .show()
                    }
                } else {
                    handler.post {
                        dialog.dismiss()
                        showMegaDownloadError(error)
                    }
                }
            }
        }.start()
    }

    private fun normalizeMegaPlaybackUrl(url: String): String {
        val clean = url.trim()
        return when {
            clean.startsWith("mega://", ignoreCase = true) ->
                clean.replaceFirst("mega://", "https://mega.nz/", ignoreCase = true)
            clean.startsWith("http://mega.nz", ignoreCase = true) ->
                clean.replaceFirst("http://", "https://", ignoreCase = true)
            else -> clean
        }
    }

    private fun isMegaFolderLink(url: String): Boolean {
        return parseMegaFolderLink(url) != null
    }

    private fun findVideoInMegaFolder(folderUrl: String): String? {
        try {
            Log.d(LOG_TAG, "Buscando videos en carpeta Mega: $folderUrl")
            val folder = parseMegaFolderLink(folderUrl) ?: return null
            val folderKeyBytes = megaBase64UrlDecode(folder.key)
            if (folderKeyBytes.size < 16) throw IOException("Clave de carpeta Mega incompleta")
            val folderAesKey = folderKeyBytes.copyOf(16)

            val requestBody = """[{"a":"f","c":1,"r":1}]"""
            val response = postMegaApi(requestBody, folder.id)
            val json = org.json.JSONArray(response)
            if (json.length() == 0) {
                Log.d(LOG_TAG, "Respuesta vacía de Mega API")
                return null
            }
            val first = json.opt(0)
            if (first is Number) {
                val errorMsg = megaApiErrorMessage(first.toInt())
                Log.e(LOG_TAG, "Error de Mega API: $errorMsg")
                throw IOException(errorMsg)
            }
            val filesArray = (first as? JSONObject)?.optJSONArray("f")
            if (filesArray == null) {
                Log.d(LOG_TAG, "No se encontró array de archivos en respuesta Mega")
                return null
            }
            
            Log.d(LOG_TAG, "Carpeta Mega contiene ${filesArray.length()} elementos")
            
            val videoExtensions = setOf("mp4", "mkv", "avi", "m4v", "mov", "webm", "ts", "m2ts", "mpg", "mpeg", "flv", "wmv")
            val videos = mutableListOf<MegaFolderVideo>()

            for (i in 0 until filesArray.length()) {
                val fileObj = filesArray.getJSONObject(i)
                val fileType = fileObj.optInt("t", -1)
                // t=0 es archivo, t=1 es carpeta
                if (fileType != 0) {
                    Log.d(LOG_TAG, "Saltando elemento tipo $fileType (no es archivo)")
                    continue
                }
                val fileId = fileObj.optString("h", "")
                val encryptedKey = fileObj.optString("k", "")
                val attribute = fileObj.optString("a", "")
                if (fileId.isBlank() || encryptedKey.isBlank()) {
                    Log.d(LOG_TAG, "Archivo sin ID o clave, saltando")
                    continue
                }

                // Intentar descifrar la clave del nodo
                val nodeKey = decryptMegaFolderNodeKeyCandidates(encryptedKey, folderAesKey)
                    .firstOrNull { it.size >= 32 }
                    ?.copyOf(32)
                
                if (nodeKey == null) {
                    Log.d(LOG_TAG, "No se pudo descifrar clave del nodo para archivo $fileId")
                    continue
                }
                
                // Descifrar atributos para obtener el nombre del archivo
                val fileName = decryptMegaAttributes(attribute, megaFileAttributeAesKey(nodeKey))
                    .ifBlank { fileObj.optString("name", "") }
                
                if (fileName.isBlank()) {
                    Log.d(LOG_TAG, "Archivo sin nombre, saltando")
                    continue
                }
                
                val extension = fileName.substringAfterLast('.', "").lowercase()
                Log.d(LOG_TAG, "Archivo encontrado: $fileName (extensión: $extension)")
                
                if (extension in videoExtensions) {
                    val fileUrl = "https://mega.nz/file/$fileId#${megaBase64UrlEncode(nodeKey)}"
                    val size = fileObj.optLong("s", 0L)
                    videos += MegaFolderVideo(fileName, fileUrl, size, i)
                    Log.d(LOG_TAG, "✓ Video encontrado en carpeta Mega: $fileName (${formatFileSize(size)})")
                } else {
                    Log.d(LOG_TAG, "✗ Archivo no es video: $fileName")
                }
            }

            if (videos.isEmpty()) {
                Log.d(LOG_TAG, "No se encontraron archivos de video en la carpeta")
                return null
            }
            
            // Seleccionar el video más grande (generalmente mejor calidad)
            val selected = videos.sortedWith(
                compareByDescending<MegaFolderVideo> { it.sizeBytes }
                    .thenBy { it.order }
            ).firstOrNull()
            
            if (selected != null) {
                Log.d(LOG_TAG, "✓✓ Video Mega seleccionado: ${selected.title} (${formatFileSize(selected.sizeBytes)}) -> ${selected.url}")
                return selected.url
            }
            
            Log.d(LOG_TAG, "No se pudo seleccionar un video de la lista")
            return null
        } catch (e: Exception) {
            Log.e(LOG_TAG, "Error buscando videos en carpeta Mega: ${e.message}", e)
            e.printStackTrace()
            return null
        }
    }

    private fun parseMegaFolderLink(url: String): MegaFolderLink? {
        val clean = normalizeMegaPlaybackUrl(url)
        return try {
            val uri = Uri.parse(clean)
            val pathSegments = uri.pathSegments
            val fragment = uri.fragment.orEmpty().trim()
            if (pathSegments.size >= 2 && pathSegments[0].equals("folder", ignoreCase = true) && fragment.isNotBlank()) {
                return MegaFolderLink(pathSegments[1], fragment.substringBefore('/').substringBefore('?'))
            }
            if (fragment.startsWith("F!", ignoreCase = true)) {
                val parts = fragment.substring(2).split('!')
                if (parts.size >= 2) return MegaFolderLink(parts[0], parts[1].substringBefore('/').substringBefore('?'))
            }
            if (fragment.startsWith("folder/", ignoreCase = true)) {
                val parts = fragment.substring("folder/".length).split('/')
                if (parts.size >= 2) return MegaFolderLink(parts[0], parts[1].substringBefore('?'))
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun parseMegaFileLink(url: String): MegaFileLink? {
        val clean = normalizeMegaPlaybackUrl(url)
        return try {
            val uri = Uri.parse(clean)
            val pathSegments = uri.pathSegments
            val fragment = uri.fragment.orEmpty().trim()
            if (pathSegments.size >= 2 && pathSegments[0].equals("file", ignoreCase = true) && fragment.isNotBlank()) {
                return MegaFileLink(
                    id = pathSegments[1],
                    key = fragment.substringBefore('/').substringBefore('?')
                )
            }
            if (fragment.startsWith("!", ignoreCase = true)) {
                val parts = fragment.trimStart('!').split('!')
                if (parts.size >= 2) return MegaFileLink(parts[0], parts[1].substringBefore('/').substringBefore('?'))
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun loadMegaFileDownloadInfo(url: String): MegaDownloadInfo {
        val link = parseMegaFileLink(url) ?: throw IOException("Enlace Mega de archivo no válido")
        val keyBytes = megaBase64UrlDecode(link.key)
        if (keyBytes.size < 32) throw IOException("Clave Mega incompleta")
        val keyInts = megaBytesToInts(keyBytes.copyOf(32))
        val aesKey = megaIntsToBytes(
            intArrayOf(
                keyInts[0] xor keyInts[4],
                keyInts[1] xor keyInts[5],
                keyInts[2] xor keyInts[6],
                keyInts[3] xor keyInts[7]
            )
        )
        val iv = megaIntsToBytes(intArrayOf(keyInts[4], keyInts[5], 0, 0))

        val requestBody = JSONArray().put(
            JSONObject()
                .put("a", "g")
                .put("g", 1)
                .put("p", link.id)
        ).toString()
        val response = postMegaApi(requestBody)
        val first = JSONArray(response).opt(0)
        if (first is Number) throw IOException(megaApiErrorMessage(first.toInt()))
        val obj = first as? JSONObject ?: throw IOException("Respuesta Mega inválida")
        val apiError = obj.optInt("e", 0)
        if (apiError != 0) throw IOException(megaApiErrorMessage(apiError))
        val downloadUrl = obj.optString("g")
        val size = obj.optLong("s", -1L)
        if (downloadUrl.isBlank() || size <= 0L) throw IOException("Mega no devolvió URL o tamaño")
        val title = decryptMegaAttributes(obj.optString("at"), aesKey).ifBlank { "Mega_${link.id}" }
        return MegaDownloadInfo(title, size, downloadUrl, aesKey, iv)
    }

    private fun postMegaApi(body: String, publicFolderId: String? = null): String {
        val folderQuery = publicFolderId
            ?.takeIf { it.isNotBlank() }
            ?.let { "&n=${java.net.URLEncoder.encode(it, "UTF-8")}" }
            .orEmpty()
        val connection = (URL("https://g.api.mega.co.nz/cs?id=${System.currentTimeMillis()}$folderQuery").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("User-Agent", getMegaUserAgent())
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        connection.outputStream.use { output -> output.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) throw IOException("Mega HTTP $code")
        return response
    }

    private fun megaDownloadStatusMessage(info: MegaDownloadInfo, downloaded: Long, paused: Boolean): String {
        val percent = if (info.sizeBytes > 0) {
            ((downloaded * 100L) / info.sizeBytes).coerceIn(0L, 100L)
        } else {
            0L
        }
        val state = if (paused) "Pausado" else "Descargando"
        return "Peso: ${formatFileSize(info.sizeBytes)}\n$state $percent% (${formatFileSize(downloaded)})"
    }

    private fun downloadAndDecryptMegaFile(
        info: MegaDownloadInfo,
        target: File,
        cancelled: java.util.concurrent.atomic.AtomicBoolean,
        paused: java.util.concurrent.atomic.AtomicBoolean,
        onProgress: (Long) -> Unit
    ): File {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, "${target.name}.part")
        if (temp.exists()) temp.delete()
        val connection = (URL(info.downloadUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            setRequestProperty("User-Agent", getMegaUserAgent())
        }
        val code = connection.responseCode
        if (code !in 200..299) {
            connection.disconnect()
            if (code == 509) {
                throw IOException("MEGA_509:Mega limitó temporalmente la transferencia para esta IP/cuenta")
            }
            throw IOException("Mega HTTP $code")
        }

        val cipher = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(info.aesKey, "AES"), IvParameterSpec(info.iv))
        }
        var downloaded = 0L
        try {
            connection.inputStream.use { input ->
                temp.outputStream().use { output ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        if (cancelled.get()) throw IOException("Descarga cancelada")
                        while (paused.get()) {
                            if (cancelled.get()) throw IOException("Descarga cancelada")
                            Thread.sleep(250L)
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        val decoded = cipher.update(buffer, 0, read)
                        if (decoded != null && decoded.isNotEmpty()) output.write(decoded)
                        downloaded += read
                        onProgress(downloaded)
                    }
                    val tail = cipher.doFinal()
                    if (tail != null && tail.isNotEmpty()) output.write(tail)
                }
            }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            return target
        } catch (error: Throwable) {
            temp.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }

    private fun megaDownloadTargetFile(title: String): File {
        val safeName = title
            .replace(Regex("""[\\/:*?"<>|]+"""), "_")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .ifBlank { "mega-video" }
        return File(File(appDownloadRootDir(), "mega").apply { mkdirs() }, safeName)
    }

    private fun createMegaDownloadDialogChrome(
        initialTitle: String,
        onClose: () -> Unit
    ): MegaDownloadDialogChrome {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(12), dp(8))
        }
        val title = TextView(this).apply {
            text = initialTitle
            setTextColor(Color.BLACK)
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 2
        }
        val close = TextView(this).apply {
            text = "x"
            contentDescription = "Cancelar descarga"
            setTextColor(Color.BLACK)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setOnClickListener { onClose() }
        }
        row.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
        return MegaDownloadDialogChrome(row, title)
    }

    private fun confirmMegaDownloadCancellation(
        cancelled: java.util.concurrent.atomic.AtomicBoolean,
        dialog: android.app.AlertDialog
    ) {
        if (cancelled.get()) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Cancelar descarga")
            .setMessage("¿Estás seguro de que quieres cancelar la descarga de Mega?\n\nSe perderá el progreso actual.")
            .setPositiveButton("Sí, cancelar") { _, _ ->
                cancelled.set(true)
                if (dialog.isShowing) {
                    dialog.setMessage("Cancelando descarga...")
                    handler.postDelayed({ 
                        if (dialog.isShowing) dialog.dismiss()
                    }, 500)
                }
            }
            .setNegativeButton("No, continuar", null)
            .show()
    }

    private fun megaBase64UrlDecode(value: String): ByteArray {
        val padded = value.replace('-', '+').replace('_', '/').let { base ->
            base + "=".repeat((4 - base.length % 4) % 4)
        }
        return Base64.decode(padded, Base64.DEFAULT)
    }

    private fun megaBase64UrlEncode(value: ByteArray): String {
        return Base64.encodeToString(value, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    private fun decryptMegaFolderNodeKeyCandidates(rawKey: String, folderAesKey: ByteArray): List<ByteArray> {
        val cipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(folderAesKey.copyOf(16), "AES"))
        }
        return rawKey.split('/')
            .mapNotNull { part ->
                val encoded = part.substringAfter(':', part).substringBefore('/')
                    .substringBefore('?')
                    .trim()
                if (encoded.isBlank()) return@mapNotNull null
                runCatching {
                    val encrypted = megaBase64UrlDecode(encoded)
                    if (encrypted.isNotEmpty() && encrypted.size % 16 == 0) {
                        cipher.doFinal(encrypted)
                    } else {
                        encrypted
                    }
                }.getOrNull()
            }
            .filter { it.size >= 16 }
    }

    private fun megaFileAttributeAesKey(fileKeyBytes: ByteArray): ByteArray {
        val keyInts = megaBytesToInts(fileKeyBytes.copyOf(32))
        return megaIntsToBytes(
            intArrayOf(
                keyInts[0] xor keyInts[4],
                keyInts[1] xor keyInts[5],
                keyInts[2] xor keyInts[6],
                keyInts[3] xor keyInts[7]
            )
        )
    }

    private fun megaBytesToInts(bytes: ByteArray): IntArray {
        val result = IntArray(bytes.size / 4)
        for (i in result.indices) {
            val offset = i * 4
            result[i] = ((bytes[offset].toInt() and 0xFF) shl 24) or
                ((bytes[offset + 1].toInt() and 0xFF) shl 16) or
                ((bytes[offset + 2].toInt() and 0xFF) shl 8) or
                (bytes[offset + 3].toInt() and 0xFF)
        }
        return result
    }

    private fun megaIntsToBytes(values: IntArray): ByteArray {
        val bytes = ByteArray(values.size * 4)
        values.forEachIndexed { index, value ->
            val offset = index * 4
            bytes[offset] = (value ushr 24).toByte()
            bytes[offset + 1] = (value ushr 16).toByte()
            bytes[offset + 2] = (value ushr 8).toByte()
            bytes[offset + 3] = value.toByte()
        }
        return bytes
    }

    private fun decryptMegaAttributes(attribute: String, aesKey: ByteArray): String {
        if (attribute.isBlank()) return ""
        return try {
            val cipher = Cipher.getInstance("AES/CBC/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, SecretKeySpec(aesKey, "AES"), IvParameterSpec(ByteArray(16)))
            }
            val text = String(cipher.doFinal(megaBase64UrlDecode(attribute)), Charsets.UTF_8)
                .trim('\u0000', ' ', '\n', '\r', '\t')
            val jsonStart = text.indexOf("MEGA")
            if (jsonStart < 0) return ""
            JSONObject(text.substring(jsonStart + 4).trim('\u0000')).optString("n")
        } catch (error: Throwable) {
            Log.w(LOG_TAG, "No se pudieron descifrar atributos Mega", error)
            ""
        }
    }

    private fun megaApiErrorMessage(code: Int): String {
        return when (code) {
            -14 -> "La clave del enlace Mega no is válida"
            -16, -17, -18, -24 -> "Mega indica límite temporal de transferencia. Espera o usa una cuenta/app oficial."
            -11 -> "No tienes acceso a este enlace Mega"
            -9 -> "El enlace Mega ya no existe"
            else -> "Mega API error $code"
        }
    }

    private fun showMegaDownloadError(error: Throwable) {
        val message = error.message.orEmpty().ifBlank { "Error desconocido" }
        
        // SIEMPRE ofrecer reintentar y abrir en navegador
        android.app.AlertDialog.Builder(this)
            .setTitle("Error Mega")
            .setMessage(message)
            .setPositiveButton("Reintentar") { _, _ ->
                lastMegaUrl?.let { megaUrl ->
                    handler.postDelayed({
                        startMegaDownloadAndPlay(megaUrl)
                    }, 500)
                }
            }
            .setNeutralButton("Navegador") { _, _ ->
                lastMegaUrl?.let { megaUrl ->
                    openUrlInDefaultBrowser(megaUrl)
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun configureMegaBrowserButton(
        dialog: android.app.AlertDialog,
        info: MegaDownloadInfo,
        megaUrl: String
    ) {
        val button = dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL) ?: return
        if (!shouldOfferMegaBrowser(info.title)) {
            button.visibility = View.GONE
            button.setOnClickListener(null)
            return
        }
        button.visibility = View.VISIBLE
        button.text = "Navegador"
        button.setOnClickListener { openUrlInDefaultBrowser(megaUrl) }
    }

    private fun shouldOfferMegaBrowser(title: String): Boolean {
        // SIEMPRE mostrar botón de navegador
        return true
    }

    private fun openUrlInDefaultBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalizeMegaPlaybackUrl(url))).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
            }
            startActivity(intent)
        } catch (_: Throwable) {
            showToast("No se pudo abrir el navegador")
        }
    }

    private fun openMegaExternally(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalizeMegaPlaybackUrl(url))))
        } catch (_: Throwable) {
            showToast("No se pudo abrir Mega")
        }
    }

    private fun openMegaEpisode(url: String) {
        if (isDirectPlayableVideoUrl(url)) {
            showDirectVlcPlayer("Series", url)
            return
        }
        if (url.startsWith("https://mega.nz") || url.startsWith("mega://")) {
            Log.d(LOG_TAG, "Descargando enlace Mega para reproducir con VLC")
            startMegaDownloadAndPlay(url)
        } else if (url.contains("ouo.io", ignoreCase = true) || 
                   url.contains("ouo.press", ignoreCase = true)) {
            // ouo.io usa WebView oculto para resolución automática
            Log.d(LOG_TAG, "Resolviendo ouo con WebView oculto: $url")
            openMegaEpisodeViaWebView(url, showWebView = false)
        } else if (url.contains("shon.xyz", ignoreCase = true)) {
            // shon.xyz suele dejar la página en blanco si se carga con bloqueo agresivo.
            // Primero probamos la extracción HTTP y, si no aparece Mega, abrimos WebView visible.
            Log.d(LOG_TAG, "Resolviendo shon.xyz: $url")
            android.widget.Toast.makeText(this, "Resolviendo shon.xyz...", android.widget.Toast.LENGTH_SHORT).show()
            Thread {
                val megaUrl = resolveShonXyzBypass(url)
                handler.post {
                    if (megaUrl != null) {
                        Log.d(LOG_TAG, "shon.xyz resuelto a Mega: $megaUrl")
                        openMegaEpisode(megaUrl)
                    } else {
                        Log.d(LOG_TAG, "shon.xyz requiere WebView visible: $url")
                        openMegaEpisodeViaWebView(url, showWebView = true)
                    }
                }
            }.start()
        } else {
            Log.d(LOG_TAG, "Resolviendo enlace intermedio: $url")
            android.widget.Toast.makeText(this, "Resolviendo enlace...", android.widget.Toast.LENGTH_SHORT).show()
            Thread {
                val megaUrl = followShortenerToMega(url, 12)
                handler.post {
                    if (megaUrl != null) {
                        Log.d(LOG_TAG, "Acortador resuelto a Mega (HTTP): $megaUrl")
                        openMegaEpisode(megaUrl)
                    } else {
                        Log.d(LOG_TAG, "HTTP falló al resolver: $url")
                        if (isKnownMegaShortener(url)) {
                            startActivity(Intent(this@MainActivity, ShortenerViewerActivity::class.java).apply {
                                putExtra(ShortenerViewerActivity.EXTRA_URL, url)
                                putExtra(ShortenerViewerActivity.EXTRA_SEASON, 1)
                                putExtra(ShortenerViewerActivity.EXTRA_EPISODE, 1)
                            })
                        } else {
                            android.widget.Toast.makeText(this@MainActivity, "No se pudo resolver el enlace", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }.start()
        }
    }

    private fun isKnownMegaShortener(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host.orEmpty().lowercase().removePrefix("www.") }
            .getOrDefault("")
        val hosts = setOf(
            "ouo.io", "ouo.press", "ouoio.com", "ouo.si",
            "shrinkme.io", "shorte.st", "adf.ly", "linkvertise.com",
            "exe.io", "bc.vc", "fc.lc", "cuty.io", "shrinkearn.com",
            "earnviral.com", "gplinks.co", "oke.io", "za.gl", "du-link.in",
            "link1s.com", "short.pe", "clk.sh", "tinyurl.com", "bit.ly",
            "t.co", "gg.gg", "is.gd", "rebrand.ly", "tiny.cc",
            "adshort.co", "cpmlink.net", "shon.xyz", "adbull.org"
        )
        return hosts.any { host == it || host.endsWith(".$it") }
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun openMegaEpisodeViaWebView(startUrl: String, showWebView: Boolean = false) {
        val wv = android.webkit.WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = COMPATIBLE_USER_AGENT
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }
            // Configuración adicional para mejor compatibilidad
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        }
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }

        var megaFound = false
        var webViewShown = false
        
        fun closeMegaResolverWebView() {
            try { rootView.removeView(wv) } catch (_: Throwable) {}
            try { wv.stopLoading() } catch (_: Throwable) {}
            try { wv.loadUrl("about:blank") } catch (_: Throwable) {}
            try { wv.destroy() } catch (_: Throwable) {}
        }
        
        wv.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onMegaUrl(megaUrl: String) {
                if (megaUrl.isBlank() || megaFound) return
                megaFound = true
                Log.d(LOG_TAG, "Mega URL via WebView JS: $megaUrl")
                handler.post {
                    closeMegaResolverWebView()
                    openMegaEpisode(megaUrl)
                }
            }

            @android.webkit.JavascriptInterface
            fun onIntermediateUrl(nextUrl: String) {
                if (nextUrl.isBlank() || megaFound || nextUrl == startUrl) return
                megaFound = true
                Log.d(LOG_TAG, "Mega intermediate URL via WebView JS: $nextUrl")
                handler.post {
                    closeMegaResolverWebView()
                    openMegaEpisode(nextUrl)
                }
            }
        }, "MegaBridge")

        wv.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldOverrideUrlLoading(view: android.webkit.WebView, request: android.webkit.WebResourceRequest): Boolean {
                val reqUrl = request.url.toString()
                if (reqUrl.startsWith("https://mega.nz") || reqUrl.startsWith("mega://")) {
                    if (!megaFound) {
                        megaFound = true
                        handler.post {
                            closeMegaResolverWebView()
                            openMegaEpisode(reqUrl)
                        }
                    }
                    return true
                }
                return false
            }
            
            override fun onPageStarted(view: android.webkit.WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Mostrar WebView cuando empiece a cargar si showWebView=true
                if (showWebView && !webViewShown && !megaFound) {
                    handler.post {
                        try {
                            if (wv.parent == null) {
                                rootView.addView(wv, FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                ))
                                webViewShown = true
                                Log.d(LOG_TAG, "WebView mostrado en pantalla")
                            }
                        } catch (e: Throwable) {
                            Log.e(LOG_TAG, "Error mostrando WebView: ${e.message}")
                        }
                    }
                }
            }
            
            override fun onPageFinished(view: android.webkit.WebView, pageUrl: String) {
                if (megaFound) return
                
                Log.d(LOG_TAG, "Página cargada: $pageUrl")
                
                // Buscar links mega.nz en la página (incluyendo los generados por JS)
                val js = """
                    (function() {
                        console.log('Buscando enlaces Mega...');
                        // Buscar en todos los links
                        var links = document.querySelectorAll('a[href]');
                        for (var i = 0; i < links.length; i++) {
                            var href = links[i].href || '';
                            if (href.includes('mega.nz') || href.startsWith('mega://')) {
                                console.log('Mega encontrado en link: ' + href);
                                window.MegaBridge.onMegaUrl(href);
                                return;
                            }
                        }
                        // Buscar en el texto de la página
                        var bodyText = document.body ? document.body.innerHTML : '';
                        bodyText = bodyText.replace(/\\\//g, '/').replace(/\\u002F/g, '/').replace(/\\u003A/g, ':').replace(/&amp;/g, '&');
                        try { bodyText = decodeURIComponent(bodyText); } catch(e) {}
                        var match = bodyText.match(/https?:\/\/mega\.nz\/(?:file|folder|#)[^\s"'<>&]+/);
                        if (match) { 
                            console.log('Mega encontrado en HTML: ' + match[0]);
                            window.MegaBridge.onMegaUrl(match[0]); 
                            return; 
                        }
                        // Buscar en onclick y data-attrs
                        var allEls = document.querySelectorAll('[onclick],[data-href],[data-url],[data-link]');
                        for (var j = 0; j < allEls.length; j++) {
                            var attr = (allEls[j].getAttribute('onclick') || '') + ' ' +
                                       (allEls[j].getAttribute('data-href') || '') + ' ' +
                                       (allEls[j].getAttribute('data-url') || '') + ' ' +
                                       (allEls[j].getAttribute('data-link') || '');
                            if (attr.includes('mega.nz')) {
                                var m = attr.match(/https:\/\/mega\.nz\/[^\s"'<>&]+/);
                                if (m) { 
                                    console.log('Mega encontrado en atributo: ' + m[0]);
                                    window.MegaBridge.onMegaUrl(m[0]); 
                                    return; 
                                }
                            }
                        }
                        
                        // Auto-click en botones útiles
                        function looksUseful(el) {
                            var text = ((el.innerText || el.textContent || '') + ' ' + (el.value || '') + ' ' + (el.id || '') + ' ' + (el.className || '')).toLowerCase();
                            if (/captcha|recaptcha|facebook|twitter|telegram|whatsapp|cookie|privacy|terms|ad|banner/.test(text)) return false;
                            return /continuar|continue|siguiente|next|skip|saltar|go|get.?link|obtener|descargar|download|generar|acceder|verify|verificar|free|gratis/.test(text);
                        }
                        
                        setTimeout(function() {
                            try {
                                var buttons = Array.prototype.slice.call(document.querySelectorAll('a[href],button,input[type="button"],input[type="submit"],.btn,[role="button"]'));
                                var clicked = 0;
                                for (var b = 0; b < buttons.length && clicked < 3; b++) {
                                    var el = buttons[b];
                                    var href = el.href || el.getAttribute('data-href') || el.getAttribute('data-url') || '';
                                    if (href && (href.indexOf('mega.nz') >= 0 || href.indexOf('mega://') === 0)) {
                                        console.log('Click en botón con Mega: ' + href);
                                        window.MegaBridge.onMegaUrl(href);
                                        return;
                                    }
                                    if (looksUseful(el)) {
                                        console.log('Click automático en: ' + (el.innerText || el.textContent || el.id));
                                        el.removeAttribute && el.removeAttribute('target');
                                        el.click();
                                        clicked++;
                                    }
                                }
                            } catch(e) {
                                console.error('Error en auto-click: ' + e);
                            }
                        }, 1200);
                    })();
                """.trimIndent()
                view.evaluateJavascript(js, null)
            }
            
            override fun onReceivedSslError(view: android.webkit.WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                Log.w(LOG_TAG, "SSL error: ${error.primaryError}")
                handler.proceed()
            }
            
            override fun onReceivedError(view: android.webkit.WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame || megaFound) return
                Log.e(LOG_TAG, "WebView error ${error.errorCode}: ${error.description}")
                
                // Si falla, intentar recargar una vez
                handler.postDelayed({
                    if (!megaFound) {
                        Log.d(LOG_TAG, "Reintentando cargar: $startUrl")
                        view.loadUrl(startUrl)
                    }
                }, 2000L)
            }
        }
        
        // Agregar WebView al layout
        try {
            if (showWebView) {
                // Para shon.xyz: mostrar en pantalla completa
                rootView.addView(wv, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                webViewShown = true
                Log.d(LOG_TAG, "WebView visible agregado para: $startUrl")
            } else {
                // Para ouo.io: oculto en segundo plano
                rootView.addView(wv, FrameLayout.LayoutParams(2, 2).apply {
                    leftMargin = -20
                    topMargin = -20
                })
                Log.d(LOG_TAG, "WebView oculto agregado para: $startUrl")
            }
        } catch (e: Throwable) {
            Log.e(LOG_TAG, "Error agregando WebView: ${e.message}")
        }
        
        // Cargar URL
        wv.loadUrl(startUrl)
        Log.d(LOG_TAG, "Cargando URL en WebView: $startUrl")

        // Timeout de 30s para encontrar el enlace
        handler.postDelayed({
            if (!megaFound) {
                Log.w(LOG_TAG, "Timeout: no se encontró enlace Mega en 30s")
                handler.post {
                    closeMegaResolverWebView()
                    android.widget.Toast.makeText(this@MainActivity, "No se pudo resolver el acortador", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }, 30_000L)
    }

    private fun getOuoRecaptchaV3Token(): String {
        try {
            val k = "6Lcr1ncUAAAAAH3cghg6cOTPGARa8adOf-y9zv2x"
            val apiJs = fetchText("https://www.google.com/recaptcha/api.js?render=$k", "application/javascript", null)
            val vMatch = Regex("""releases/([^/]+)/""").find(apiJs)
            val v = vMatch?.groupValues?.get(1) ?: return ""
            
            val co = "aHR0cHM6Ly9vdW8ucHJlc3M6NDQz"
            val anchorUrl = "https://www.google.com/recaptcha/api2/anchor?ar=1&k=$k&co=$co&hl=en&v=$v&size=invisible&cb=ahgyd1gkfkhe"
            val anchorHtml = fetchText(anchorUrl, "text/html", null)
            val tokenMatch = Regex(""""recaptcha-token"\s*value="(.*?)"""").find(anchorHtml)
            val token = tokenMatch?.groupValues?.get(1) ?: return ""
            
            val postData = "v=$v&reason=q&c=$token&k=$k&co=$co"
            
            val conn = (java.net.URL("https://www.google.com/recaptcha/api2/reload?k=$k").openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            }
            conn.outputStream.write(postData.toByteArray())
            val reloadText = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            
            val answerMatch = Regex(""""rresp","(.*?)"""").find(reloadText)
            return answerMatch?.groupValues?.get(1) ?: ""
        } catch (_: Exception) {
            return ""
        }
    }

    private fun resolveOuoBypass(url: String): String? {
        try {
            val id = url.substringAfterLast("/")
            val currentUrl = "https://ouo.io/$id"
            var nextPostUrl = "https://ouo.io/go/$id"
            val ua = getMegaUserAgent()
            
            val cookies = mutableMapOf<String, String>()
            fun updateCookies(conn: java.net.HttpURLConnection) {
                conn.headerFields["Set-Cookie"]?.forEach { cookie ->
                    val parts = cookie.split(";", limit = 2)[0].split("=", limit = 2)
                    if (parts.size == 2) {
                        cookies[parts[0]] = parts[1]
                    }
                }
            }
            fun getCookieString() = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
            
            var conn = (java.net.URL(currentUrl).openConnection() as java.net.HttpURLConnection).apply {
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", ua)
            }
            if (conn.responseCode in 300..399) {
                val loc = conn.getHeaderField("Location")
                if (loc != null) return loc
            }
            updateCookies(conn)
            var html = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            
            for (i in 0..1) {
                val tokenMatch = Regex("""name="_token"\s+value="([^"]+)"""").find(html)
                val formToken = tokenMatch?.groupValues?.get(1) ?: ""
                val recaptchaToken = getOuoRecaptchaV3Token()
                
                val postData = "_token=$formToken&x-token=$recaptchaToken"
                
                conn = (java.net.URL(nextPostUrl).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    instanceFollowRedirects = false
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    setRequestProperty("User-Agent", ua)
                    val cookieStr = getCookieString()
                    if (cookieStr.isNotEmpty()) setRequestProperty("Cookie", cookieStr)
                }
                conn.outputStream.write(postData.toByteArray())
                if (conn.responseCode in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (loc != null) return loc
                }
                updateCookies(conn)
                html = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                
                nextPostUrl = "https://ouo.io/xreallcygo/$id"
            }
        } catch (_: Exception) {}
        return null
    }

    private fun resolveShonXyzBypass(url: String): String? {
        try {
            val ua = getMegaUserAgent()
            Log.d(LOG_TAG, "Attempting shon.xyz bypass for: $url")
            
            // Paso 1: Descargar HTML inicial del acortador con timeouts más largos
            var conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                instanceFollowRedirects = false  // No seguir redirecciones automáticamente
                connectTimeout = 20000  // 20 segundos (aumentado de 12s)
                readTimeout = 20000     // 20 segundos (aumentado de 12s)
                setRequestProperty("User-Agent", ua)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
                setRequestProperty("Referer", "https://megadescargas-new.blogspot.com/")
                setRequestProperty("Connection", "keep-alive")
            }
            
            // Manejar redirecciones manualmente
            var currentUrl = url
            var html = ""
            var redirectCount = 0
            val maxRedirects = 5
            
            while (redirectCount < maxRedirects) {
                val code = conn.responseCode
                Log.d(LOG_TAG, "shon.xyz HTTP $code for $currentUrl")
                
                when {
                    code in 300..399 -> {
                        val location = conn.getHeaderField("Location")
                        conn.disconnect()
                        if (location == null) break
                        
                        currentUrl = if (location.startsWith("http")) location
                                    else java.net.URL(java.net.URL(currentUrl), location).toString()
                        
                        Log.d(LOG_TAG, "shon.xyz redirect to: $currentUrl")
                        
                        // Si redirige directamente a mega.nz, retornar
                        if (currentUrl.contains("mega.nz", ignoreCase = true)) {
                            Log.d(LOG_TAG, "shon.xyz direct redirect to mega: $currentUrl")
                            return currentUrl
                        }
                        
                        // Preparar siguiente petición con timeouts largos
                        conn = (java.net.URL(currentUrl).openConnection() as java.net.HttpURLConnection).apply {
                            instanceFollowRedirects = false
                            connectTimeout = 20000  // 20 segundos
                            readTimeout = 20000     // 20 segundos
                            setRequestProperty("User-Agent", ua)
                            setRequestProperty("Accept", "text/html,*/*")
                            setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
                            setRequestProperty("Referer", url)
                            setRequestProperty("Connection", "keep-alive")
                        }
                        redirectCount++
                    }
                    code in 200..299 -> {
                        html = conn.inputStream.bufferedReader().use { it.readText() }
                        conn.disconnect()
                        break
                    }
                    else -> {
                        conn.disconnect()
                        Log.w(LOG_TAG, "shon.xyz unexpected HTTP $code")
                        return null
                    }
                }
            }
            
            if (html.isEmpty()) {
                Log.w(LOG_TAG, "shon.xyz no HTML received")
                return null
            }
            
            Log.d(LOG_TAG, "shon.xyz HTML size: ${html.length} bytes")
            
            // Paso 2: Buscar enlaces de mega.nz en el HTML
            val megaUrls = extractMegaUrlsFromText(html)
            if (megaUrls.isNotEmpty()) {
                Log.d(LOG_TAG, "shon.xyz bypass found mega URL in HTML: ${megaUrls.first()}")
                return megaUrls.first()
            }
            
            // Paso 3: Buscar enlaces en atributos href de <a>
            val hrefPattern = Regex("""<a[^>]+href=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
            hrefPattern.findAll(html).forEach { match ->
                val href = match.groupValues[1]
                if (href.contains("mega.nz", ignoreCase = true)) {
                    Log.d(LOG_TAG, "shon.xyz bypass found mega URL in href: $href")
                    return href
                }
            }
            
            // Paso 4: Buscar redirecciones en JavaScript
            val jsRedirectPatterns = listOf(
                Regex("""window\.location\.href\s*=\s*["']([^"']+)["']"""),
                Regex("""window\.location\s*=\s*["']([^"']+)["']"""),
                Regex("""location\.href\s*=\s*["']([^"']+)["']"""),
                Regex("""location\s*=\s*["']([^"']+)["']"""),
                Regex("""document\.location\s*=\s*["']([^"']+)["']"""),
                Regex("""window\.open\s*\(\s*["']([^"']+)["']""")
            )
            
            for (pattern in jsRedirectPatterns) {
                pattern.findAll(html).forEach { match ->
                    val redirectUrl = match.groupValues[1]
                    if (redirectUrl.contains("mega.nz", ignoreCase = true)) {
                        Log.d(LOG_TAG, "shon.xyz bypass found mega URL in JS: $redirectUrl")
                        return redirectUrl
                    }
                }
            }
            
            // Paso 5: Buscar meta refresh
            val metaRefresh = Regex("""<meta[^>]+http-equiv=["']refresh["'][^>]+content=["'][^"']*url=([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.get(1)
            if (metaRefresh != null && metaRefresh.contains("mega.nz", ignoreCase = true)) {
                Log.d(LOG_TAG, "shon.xyz bypass found mega URL in meta refresh: $metaRefresh")
                return metaRefresh
            }
            
            // Paso 6: Buscar en variables JavaScript (común en acortadores)
            val jsVarPatterns = listOf(
                Regex("""var\s+\w+\s*=\s*["']([^"']*mega\.nz[^"']*)["']""", RegexOption.IGNORE_CASE),
                Regex("""let\s+\w+\s*=\s*["']([^"']*mega\.nz[^"']*)["']""", RegexOption.IGNORE_CASE),
                Regex("""const\s+\w+\s*=\s*["']([^"']*mega\.nz[^"']*)["']""", RegexOption.IGNORE_CASE)
            )
            
            for (pattern in jsVarPatterns) {
                val match = pattern.find(html)
                if (match != null) {
                    val megaUrl = match.groupValues[1]
                    Log.d(LOG_TAG, "shon.xyz bypass found mega URL in JS var: $megaUrl")
                    return megaUrl
                }
            }
            
            Log.w(LOG_TAG, "shon.xyz bypass failed: no mega URL found in HTML")
            
        } catch (e: java.net.SocketTimeoutException) {
            Log.e(LOG_TAG, "shon.xyz timeout: ${e.message}")
            // Retornar null para que se muestre el mensaje de error apropiado
        } catch (e: Exception) {
            Log.e(LOG_TAG, "shon.xyz bypass error: ${e.message}", e)
        }
        return null
    }

    private fun resolveGenericShortenerBypass(url: String): String? {
        try {
            val ua = getMegaUserAgent()
            
            // Descargar HTML del acortador
            val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty("User-Agent", ua)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
            }
            
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            
            // Buscar enlaces de mega.nz en el HTML
            val megaUrls = extractMegaUrlsFromText(html)
            if (megaUrls.isNotEmpty()) {
                Log.d(LOG_TAG, "Generic shortener bypass found mega URL: ${megaUrls.first()}")
                return megaUrls.first()
            }
            
        } catch (e: Exception) {
            Log.w(LOG_TAG, "Generic shortener bypass error: ${e.message}")
        }
        return null
    }

    private fun followShortenerToMega(url: String, maxHops: Int): String? {
        var current = url
        val ua = getMegaUserAgent()
        repeat(maxHops) {
            if (current.startsWith("https://mega.nz") || current.startsWith("mega://")) return current
            
            // Bypass automático para ouo.io (ya no se usa, se maneja con WebView)
            if (current.contains("ouo.io") || current.contains("ouo.press")) {
                val bypass = resolveOuoBypass(current)
                if (bypass != null) {
                    current = bypass
                    return@repeat
                }
            }
            
            // shon.xyz ya no usa bypass HTTP, se maneja con WebView
            
            // Bypass automático para otros acortadores conocidos
            val shortenerHosts = listOf(
                "adshort.co", "cpmlink.net", "shrinkme.io", "adf.ly", 
                "bc.vc", "cuty.io", "exe.io", "gplinks.co", "oke.io",
                "za.gl", "link1s.com", "short.pe", "clk.sh", "adbull.org"
            )
            if (shortenerHosts.any { current.contains(it, ignoreCase = true) }) {
                val bypass = resolveGenericShortenerBypass(current)
                if (bypass != null) {
                    Log.d(LOG_TAG, "Generic shortener bypass successful: $bypass")
                    return bypass
                }
            }
            
            try {
                val conn = (java.net.URL(current).openConnection() as java.net.HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 15000  // Aumentado de 10s a 15s para tinyurl
                    readTimeout = 15000
                    setRequestProperty("User-Agent", ua)
                    setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.9")
                    setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
                    // Cabeceras adicionales para tinyurl y otros acortadores
                    setRequestProperty("Accept-Encoding", "gzip, deflate")
                    setRequestProperty("Connection", "keep-alive")
                    setRequestProperty("Upgrade-Insecure-Requests", "1")
                }
                val code = conn.responseCode
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                when {
                    code in 300..399 && location != null -> {
                        current = if (location.startsWith("http")) location
                                  else java.net.URL(java.net.URL(current), location).toString()
                        Log.d(LOG_TAG, "Shortener redirect: $current")
                    }
                    code in 200..299 -> {
                        // Para tinyurl y similares, intentar con followRedirects = true
                        val conn2 = (java.net.URL(current).openConnection() as java.net.HttpURLConnection).apply {
                            instanceFollowRedirects = true  // Seguir redirecciones automáticamente
                            connectTimeout = 15000
                            readTimeout = 15000
                            setRequestProperty("User-Agent", ua)
                            setRequestProperty("Accept", "text/html,*/*")
                            setRequestProperty("Accept-Encoding", "gzip, deflate")
                            setRequestProperty("Connection", "keep-alive")
                        }
                        val finalUrl = conn2.url.toString()
                        // Si la URL final es diferente y es mega.nz, devolverla
                        if (finalUrl != current && (finalUrl.startsWith("https://mega.nz") || finalUrl.startsWith("mega://"))) {
                            conn2.disconnect()
                            Log.d(LOG_TAG, "Shortener resolved to: $finalUrl")
                            return finalUrl
                        }
                        val body = conn2.inputStream.bufferedReader().use { it.readText() }
                        conn2.disconnect()
                        extractMegaUrlsFromText(body).firstOrNull()?.let { 
                            Log.d(LOG_TAG, "Mega URL found in body: $it")
                            return it 
                        }
                        // Si no encontramos mega.nz, intentar extraer meta refresh
                        val metaRefresh = Regex("""<meta[^>]+http-equiv=["']refresh["'][^>]+content=["'][^"']*url=([^"']+)["']""", RegexOption.IGNORE_CASE)
                            .find(body)?.groupValues?.get(1)
                        if (metaRefresh != null) {
                            current = if (metaRefresh.startsWith("http")) metaRefresh
                                     else java.net.URL(java.net.URL(current), metaRefresh).toString()
                            Log.d(LOG_TAG, "Meta refresh found: $current")
                            return@repeat
                        }
                        return null
                    }
                    else -> {
                        Log.w(LOG_TAG, "Shortener HTTP $code for $current")
                        return null
                    }
                }
            } catch (e: Exception) { 
                Log.w(LOG_TAG, "Shortener error for $current: ${e.message}")
                return null 
            }
        }
        return if (current.startsWith("https://mega.nz") || current.startsWith("mega://")) current else null
    }

    // ------------------------------------------------------------------------------
    // PROGRESO DE REPRODUCCIÓN
    // ------------------------------------------------------------------------------

    private var currentPlayingItemId: String? = null

    private inner class VideoProgressBridge {
        @android.webkit.JavascriptInterface
        fun saveProgress(position: Double) {
            val itemId = currentPlayingItemId ?: return
            val item = continueWatchingItems.find { it.id == itemId } ?: return
            item.lastWatchedPosition = position.toLong()
            handler.post {
                saveContinueWatching()
            }
        }

        @android.webkit.JavascriptInterface
        fun getLastPosition(): Double {
            val itemId = currentPlayingItemId ?: return 0.0
            val item = continueWatchingItems.find { it.id == itemId } ?: return 0.0
            return item.lastWatchedPosition.toDouble()
        }

        @android.webkit.JavascriptInterface
        fun onDecodeError(errorCode: Int) {
            Log.e(LOG_TAG, "PIPELINE_ERROR_DECODE desde torrent local (código $errorCode)")
            handler.post {
                if (currentScreen != Screen.PLAYER) return@post
                // Mostrar overlay de error nativo encima del WebView
                val overlay = torrentOverlayView ?: return@post
                overlay.removeAllViews()
                overlay.tag = null
                overlay.setBackgroundColor(Color.BLACK)
                overlay.visibility = View.VISIBLE

                val container = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(40), 0, dp(40), 0)
                }
                val icon = TextView(this@MainActivity).apply {
                    text = "!"
                    textSize = 40f
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, dp(16))
                }
                val title = TextView(this@MainActivity).apply {
                    text = "Error de decodificación"
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, dp(12))
                }
                val detail = TextView(this@MainActivity).apply {
                    text = when (errorCode) {
                        3 -> "El codec o contenedor no está soportado por WebView.\n\nCausas comunes:\n• H.265/HEVC\n• Contenedor MKV o AVI\n• Audio AC3/DTS\n\nPuedes probar VLC interno sin salir de DownTV."
                        4 -> "Formato de video no soportado por WebView.\n\nPuedes probar VLC interno sin salir de DownTV."
                        else -> "No se puede reproducir este archivo en WebView (código $errorCode).\n\nPuedes probar VLC interno o elegir otro torrent."
                    }
                    setTextColor(Color.WHITE)
                    textSize = 13f
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    setLineSpacing(dp(4).toFloat(), 1f)
                }
                container.addView(icon, LinearLayout.LayoutParams(-2, -2))
                container.addView(title, LinearLayout.LayoutParams(-1, -2))
                container.addView(detail, LinearLayout.LayoutParams(-1, -2))

                currentTorrentVideoUrl?.let { videoUrl ->
                    val vlcButton = TextView(this@MainActivity).apply {
                        text = "Reproducir con VLC"
                        setTextColor(Color.WHITE)
                        textSize = 14f
                        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                        gravity = Gravity.CENTER
                        setPadding(dp(18), 0, dp(18), 0)
                        background = GradientDrawable().apply {
                            setColor(Color.WHITE)
                            cornerRadius = dp(8).toFloat()
                        }
                        setOnClickListener {
                            torrentProgressOverlayEnabled = false
                            overlay.visibility = View.GONE
                            showEmbeddedVlcTorrentPlayer(videoUrl)
                        }
                    }
                    val buttonParams = LinearLayout.LayoutParams(-2, dp(44)).apply {
                        topMargin = dp(22)
                    }
                    container.addView(vlcButton, buttonParams)
                }

                overlay.addView(container, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            }
        }
    }

    private fun injectVideoProgressTracker(view: WebView) {
        val script = """
            (() => {
                if (window.__kotaProgressTrackerInstalled) return;
                window.__kotaProgressTrackerInstalled = true;

                let lastSavedPosition = 0;
                let hasResumed = false;

                function saveProgress(video) {
                    if (!video || !video.currentTime || video.currentTime < 1) return;
                    const pos = Math.floor(video.currentTime);
                    // Solo guardar cada 5 segundos para no saturar
                    if (Math.abs(pos - lastSavedPosition) >= 5) {
                        lastSavedPosition = pos;
                        try {
                            window.KotaProgressBridge.saveProgress(pos);
                        } catch(e) {}
                    }
                }

                function resumeProgress(video) {
                    if (hasResumed || !video) return;
                    try {
                        const lastPos = window.KotaProgressBridge.getLastPosition();
                        if (lastPos > 10) {
                            video.currentTime = lastPos;
                            hasResumed = true;
                        }
                    } catch(e) {}
                }

                function trackVideo(video) {
                    if (!video || video.__kotaProgressTracked) return;
                    video.__kotaProgressTracked = true;

                    // Reanudar cuando el video esté listo
                    video.addEventListener('loadedmetadata', () => resumeProgress(video));
                    video.addEventListener('canplay', () => resumeProgress(video));

                    // Guardar progreso periódicamente
                    video.addEventListener('timeupdate', () => saveProgress(video));
                    video.addEventListener('pause', () => saveProgress(video));
                    video.addEventListener('ended', () => saveProgress(video));
                }

                function trackAllVideos() {
                    document.querySelectorAll('video').forEach(trackVideo);
                }

                // Interceptar createElement para pillar nuevos videos
                const _origCreate = document.createElement.bind(document);
                if (!document.__kotaProgressCreatePatched) {
                    document.__kotaProgressCreatePatched = true;
                    const _existing = document.createElement;
                    document.createElement = function(tag) {
                        const el = _existing.call(document, tag);
                        if (tag && tag.toLowerCase() === 'video') {
                            setTimeout(() => trackVideo(el), 0);
                        }
                        return el;
                    };
                }

                trackAllVideos();
                [500, 1500, 3000, 5000].forEach(d => setTimeout(trackAllVideos, d));

                const observer = new MutationObserver(trackAllVideos);
                observer.observe(document.documentElement, { childList: true, subtree: true });
                setTimeout(() => observer.disconnect(), 20000);
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }
}
