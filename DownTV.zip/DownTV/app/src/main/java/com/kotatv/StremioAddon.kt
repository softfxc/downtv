package com.kotatv

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

// Estructuras de datos para Stremio Addons
data class StremioStream(
    @SerializedName("name") val name: String?,
    @SerializedName("title") val title: String?,
    @SerializedName("infoHash") val infoHash: String?,
    @SerializedName("fileIdx") val fileIdx: Int?,
    @SerializedName("url") val url: String?,
    @SerializedName("behaviorHints") val behaviorHints: BehaviorHints?
)

data class BehaviorHints(
    @SerializedName("bingeGroup") val bingeGroup: String?,
    @SerializedName("notWebReady") val notWebReady: Boolean?
)

data class StremioResponse(
    @SerializedName("streams") val streams: List<StremioStream>?
)

/**
 * Cliente para addons de Stremio (Torrentio, MediaFusion, etc.)
 */
class StremioAddonClient(private val baseUrl: String) {
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    
    private val gson = Gson()
    
    /**
     * Obtiene streams de un addon de Stremio
     * @param type "movie" o "series"
     * @param imdbId ID de IMDb (con prefijo tt)
     * @param season Temporada (para series)
     * @param episode Episodio (para series)
     * @return Lista de streams disponibles
     */
    fun getStreams(
        type: String,
        imdbId: String,
        season: Int? = null,
        episode: Int? = null
    ): List<StremioStream> {
        try {
            val id = if (type == "series" && season != null && episode != null) {
                "$imdbId:$season:$episode"
            } else {
                imdbId
            }
            
            val url = "$baseUrl/stream/$type/$id.json"
            
            android.util.Log.d("StremioAddon", "Fetching: $url")
            
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "KotaTV/1.0")
                .build()
            
            val response = client.newCall(request).execute()
            
            if (!response.isSuccessful) {
                android.util.Log.e("StremioAddon", "HTTP ${response.code}")
                return emptyList()
            }
            
            val body = response.body?.string() ?: return emptyList()
            val stremioResponse = gson.fromJson(body, StremioResponse::class.java)
            
            val streams = stremioResponse.streams ?: emptyList()
            android.util.Log.d("StremioAddon", "Found ${streams.size} streams")
            
            return streams
            
        } catch (e: Exception) {
            android.util.Log.e("StremioAddon", "Error: ${e.message}", e)
            return emptyList()
        }
    }
}

/**
 * Configuraciones de addons populares
 */
object StremioAddons {
    
    /**
     * Torrentio - El addon más popular de Stremio
     * Configuración por defecto sin debrid, con múltiples idiomas y sin límite de resultados
     */
    fun torrentio(): StremioAddonClient {
        // sort=qualitysize: primero los de mejor calidad/tamaño
        // language=spanish|english: incluir español e inglés para más resultados
        // debridoptions=nodownloadlinks: sin links de descarga directa
        return StremioAddonClient("https://torrentio.strem.fun/language=spanish|english|sort=qualitysize|debridoptions=nodownloadlinks")
    }
    
    /**
     * Obtiene streams de Torrentio
     */
    fun getStreamsFromTorrentio(
        type: String,
        imdbId: String,
        season: Int? = null,
        episode: Int? = null
    ): List<Pair<String, StremioStream>> {
        val results = mutableListOf<Pair<String, StremioStream>>()
        
        // Torrentio
        try {
            val torrentioStreams = torrentio().getStreams(type, imdbId, season, episode)
            android.util.Log.d("StremioAddons", "Torrentio: ${torrentioStreams.size} streams encontrados")
            torrentioStreams.forEach { stream ->
                results.add("Torrentio" to stream)
            }
        } catch (e: Exception) {
            android.util.Log.e("StremioAddons", "Torrentio error: ${e.message}", e)
        }
        
        return results
    }
}
