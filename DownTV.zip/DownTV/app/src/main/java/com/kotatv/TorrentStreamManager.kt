package com.kotatv

import android.content.Context
import android.util.Log
import org.libtorrent4j.AlertListener
import org.libtorrent4j.Priority
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentFlags
import org.libtorrent4j.TorrentInfo
import org.libtorrent4j.alerts.AddTorrentAlert
import org.libtorrent4j.alerts.Alert
import org.libtorrent4j.alerts.AlertType
import org.libtorrent4j.alerts.StateUpdateAlert
import org.libtorrent4j.alerts.TorrentErrorAlert
import org.libtorrent4j.swig.add_torrent_params
import org.libtorrent4j.swig.error_code
import org.libtorrent4j.swig.libtorrent
import org.libtorrent4j.swig.storage_mode_t
import org.libtorrent4j.swig.byte_vector
import org.chromium.net.CronetEngine
import org.chromium.net.CronetException
import org.chromium.net.UrlRequest
import org.chromium.net.UrlResponseInfo
import java.util.concurrent.CountDownLatch
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLEncoder
import java.net.SocketException
import java.net.URL
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.min

/**
 * Streams a selected torrent file through a loopback HTTP server that WebView can play.
 */
class TorrentStreamManager(private val context: Context) {

    @Volatile private var sessionManager: SessionManager? = null
    @Volatile private var torrentHandle: TorrentHandle? = null
    @Volatile private var torrentInfo: TorrentInfo? = null
    @Volatile private var selectedFile: SelectedTorrentFile? = null
    @Volatile private var downloadDir: File? = null
    @Volatile private var streamingUrl: String? = null
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var serverThread: Thread? = null
    @Volatile private var isStreaming = false
    @Volatile private var latestStats = DownloadStats()
    @Volatile private var confirmedPrefixBytes = 0L
    private val torrentLock = Any()

    // Stats atÃ³micas actualizadas SOLO desde el alert listener (hilo de libtorrent).
    // Nunca llamamos TorrentHandle.status() desde hilos externos â€” eso causa SIGBUS.
    private val atomicTotalWantedDone = AtomicLong(0L)
    private val atomicDownloadRate    = AtomicLong(0L)
    private val atomicNumSeeds        = AtomicLong(0L)
    private val atomicNumPeers        = AtomicLong(0L)
    private val streamingHandleConfigured = AtomicBoolean(false)

    private data class SelectedTorrentFile(
        val index: Int,
        val displayName: String,
        val relativePath: String,
        val file: File,
        val size: Long,
        val firstPiece: Int,
        val lastPiece: Int,
        val requireWebViewCompatible: Boolean
    )

    private data class ByteRange(val start: Long, val end: Long)

    companion object {
        private const val TAG = "TorrentStream"
        private const val MAGNET_TIMEOUT_SECONDS = 240  // MÃ¡s margen para metadata sin falsos timeout
        private const val PLAYBACK_TIMEOUT_SECONDS = 240L  // Fallback antiguo; VLC arranca sin esperar este timeout
        private const val DATA_WAIT_TIMEOUT_MS = 180_000L  // No cortar VLC demasiado pronto si el torrent tarda
        private const val SOCKET_TIMEOUT_MS = 30_000
        private const val READ_BUFFER_BYTES = 64 * 1024
        private const val DATA_PRESENCE_CHUNK_BYTES = 64 * 1024
        private const val DATA_PRESENCE_SCAN_AHEAD_BYTES = 4L * 1024L * 1024L
        private const val MIN_INITIAL_BUFFER_BYTES = 4L * 1024L * 1024L
        private const val MAX_INITIAL_BUFFER_BYTES = 32L * 1024L * 1024L
        private const val VLC_INITIAL_BUFFER_BYTES = 64L * 1024L * 1024L
        private const val TAIL_BUFFER_BYTES = 32L * 1024L * 1024L

        private val WEBVIEW_VIDEO_EXTENSIONS = setOf(
            "mp4", "m4v", "webm"
        )
        private val EXTERNAL_PLAYER_VIDEO_EXTENSIONS = WEBVIEW_VIDEO_EXTENSIONS + setOf(
            "mkv", "avi", "mov", "ts", "m2ts", "wmv", "flv"
        )
        
        // Trackers pÃºblicos para mejorar la conectividad
        private val PUBLIC_TRACKERS = listOf(
            "udp://tracker.opentrackr.org:1337/announce",
            "udp://open.stealth.si:80/announce",
            "udp://tracker.torrent.eu.org:451/announce",
            "udp://tracker.bittor.pw:1337/announce",
            "udp://public.popcorn-tracker.org:6969/announce",
            "udp://tracker.dler.org:6969/announce",
            "udp://exodus.desync.com:6969/announce",
            "udp://opentracker.i2p.rocks:6969/announce"
        )
    }

    private fun appendPublicTrackers(magnetUri: String): String {
        if (magnetUri.contains("&tr=", ignoreCase = true) || magnetUri.contains("?tr=", ignoreCase = true)) {
            return magnetUri
        }
        val encodedTrackers = PUBLIC_TRACKERS.joinToString(separator = "") { tracker ->
            "&tr=" + URLEncoder.encode(tracker, "UTF-8")
        }
        return magnetUri + encodedTrackers
    }

    fun startStreaming(
        magnetUri: String,
        fileIndex: Int? = null,
        requireWebViewCompatible: Boolean = true,
        callback: (Result<String>) -> Unit
    ) {
        if (isStreaming) stopStreaming()
        isStreaming = true
        atomicTotalWantedDone.set(0L)
        atomicDownloadRate.set(0L)
        atomicNumSeeds.set(0L)
        atomicNumPeers.set(0L)
        streamingHandleConfigured.set(false)

        Thread {
            val torrentError = AtomicReference<String?>()

            try {
                Log.d(TAG, "Starting torrent stream")
                val sourceUri = magnetUri.trim()
                val isMagnet = sourceUri.startsWith("magnet:", ignoreCase = true)
                Log.d(TAG, "Torrent source: ${sourceUri.take(120)}")

                // Los torrents quedan en descargas hasta que el usuario los borre desde Ajustes.
                val targetDir = torrentDownloadDir().apply {
                    mkdirs()
                }
                downloadDir = targetDir

                // Agregar trackers pÃºblicos bien codificados solo cuando el magnet no trae trackers.
                // En magnet URI, cada tracker debe ir URL-encoded; si se aÃ±ade como texto plano,
                // algunos parsers de libtorrent pueden ignorarlo o fallar de forma intermitente.
                val manager = SessionManager()
                sessionManager = manager
                manager.addListener(createAlertListener(torrentError))
                
                // ConfiguraciÃ³n de sesiÃ³n para mejor conectividad
                // La configuraciÃ³n se dejarÃ¡ por defecto para evitar errores de API
                
                manager.start()

                // Modo seguro: no arrancamos un poller de estado ni llamamos
                // postTorrentUpdates() desde hilos externos. En algunos Android/libtorrent4j
                // eso puede terminar en cierre nativo de la app justo tras "Conectando con seeders".

                val info = if (isMagnet) {
                    // Paso 1: resolver primero la metadata del magnet SIN llamar a handle.torrentFile().
                    // SessionManager.fetchMagnet() usa saveResumeData(SAVE_INFO_DICT), que evita esa
                    // llamada peligrosa en algunos Android/libtorrent4j.
                    val enhancedMagnet = appendPublicTrackers(sourceUri)
                    Log.d(TAG, "Fetching magnet metadata without TorrentHandle.torrentFile()...")
                    val metadataDir = File(context.cacheDir, "DownTV/magnet-meta").apply { mkdirs() }
                    val torrentBytes = manager.fetchMagnet(
                        enhancedMagnet,
                        MAGNET_TIMEOUT_SECONDS,
                        metadataDir
                    )

                    if (!isStreaming) return@Thread
                    if (torrentBytes == null || torrentBytes.isEmpty()) {
                        Log.w(TAG, "No se pudo obtener metadata del magnet - posible falta de seeders")
                        throw IllegalStateException("No se pudo obtener la metadata del magnet a tiempo. Reintenta o prueba otro torrent.")
                    }

                    try {
                        TorrentInfo(torrentBytes)
                    } catch (e: Throwable) {
                        Log.e(TAG, "Error decoding fetched torrent metadata", e)
                        throw IllegalStateException("Se recibiÃ³ metadata del magnet, pero no se pudo interpretar el .torrent: ${e.message}")
                    }
                } else {
                    Log.d(TAG, "Downloading .torrent metadata")
                    val torrentBytes = downloadTorrentBytes(sourceUri)
                    if (!isStreaming) return@Thread
                    try {
                        TorrentInfo(torrentBytes)
                    } catch (e: Throwable) {
                        Log.e(TAG, "Error decoding .torrent metadata", e)
                        throw IllegalStateException("No se pudo interpretar el .torrent: ${e.message}")
                    }
                }

                if (!info.isValid()) {
                    throw IllegalStateException("La metadata del torrent no es valida")
                }
                torrentInfo = info

                val selected = selectTorrentFile(info, fileIndex, targetDir, requireWebViewCompatible)
                selectedFile = selected
                confirmedPrefixBytes = 0L

                Log.d(TAG, "Torrent metadata loaded: ${info.name()}")
                Log.d(TAG, "Selected file [${selected.index}]: ${selected.relativePath}")
                Log.d(TAG, "Selected size: ${selected.size / 1024L / 1024L} MB")

                // Paso 2: aÃ±adir el torrent real en MODO SPARSE, ya con TorrentInfo resuelto.
                // AsÃ­ evitamos preasignar archivos enormes y mantenemos la ruta interna privada.
                Log.d(TAG, "Adding resolved torrent with sparse mode (no pre-allocation)...")
                val params = if (isMagnet) {
                    val ec = error_code()
                    val parsed = libtorrent.parse_magnet_uri(appendPublicTrackers(sourceUri), ec)
                    if (ec.value() != 0) {
                        throw IllegalStateException("Magnet URI invÃ¡lido: ${ec.message()}")
                    }
                    parsed
                } else {
                    add_torrent_params()
                }
                params.set_ti(info.swig())
                params.setSave_path(targetDir.absolutePath)
                params.setStorage_mode(storage_mode_t.storage_mode_sparse)
                params.setFlags(params.getFlags().or_(TorrentFlags.SEQUENTIAL_DOWNLOAD))
                params.set_file_priorities(toPriorityVector(buildFilePriorities(info, selected.index)))
                params.set_piece_priorities(buildPiecePriorities(info, selected))
                params.setUpload_limit(0)
                params.setDownload_limit(0)

                manager.swig().async_add_torrent(params)
                Log.d(TAG, "Torrent queued with sparse mode after metadata fetch")

                // Modo seguro: no tocamos TorrentHandle para setSequentialRange/resume/status/torrentFile.
                // Cualquier llamada directa a TorrentHandle puede terminar en cierre nativo en algunos Android.

                // Antes esperÃ¡bamos decenas de MB iniciales/finales antes de entregar la URL a VLC.
                // Eso hacÃ­a que la app pareciese quedarse en "Conectando con seeders" y podÃ­a terminar
                // en falso timeout aunque el torrent sÃ­ estuviese descargando. Ahora arrancamos el servidor
                // local inmediatamente y dejamos que VLC haga buffering mientras nuestro HTTP server espera
                // los datos pieza a pieza.
                ensureSparsePlaceholderFile(selected)
                val url = startLocalServer(selected)
                if (!isStreaming) return@Thread

                callback(Result.success(url))
            } catch (error: Throwable) {
                if (isStreaming) {
                    Log.e(TAG, "Error starting torrent stream", error)
                    callback(Result.failure(error))
                    stopStreaming()
                }
            }
        }.apply {
            name = "KotaTorrentStarter"
            start()
        }
    }

    private fun downloadTorrentBytes(sourceUri: String): ByteArray {
        if (sourceUri.startsWith("file://", ignoreCase = true)) {
            val file = File(java.net.URI(sourceUri))
            if (!file.exists() || file.length() < 32L) throw IOException(".torrent local vacio o invalido")
            return file.readBytes()
        }
        if (!sourceUri.startsWith("http://", ignoreCase = true) &&
            !sourceUri.startsWith("https://", ignoreCase = true)
        ) {
            val file = File(sourceUri)
            if (file.exists() && file.length() >= 32L) return file.readBytes()
        }

        val candidates = torrentSourceCandidates(sourceUri)
        var lastError: Throwable? = null

        for (candidate in candidates) {
            try {
                return downloadTorrentBytesWithCronet(candidate, enableQuic = false)
            } catch (error: Throwable) {
                lastError = error
                Log.w(TAG, "Cronet no pudo descargar .torrent desde $candidate: ${error.message}")
            }
        }

        for (candidate in candidates) {
            try {
                return downloadTorrentBytesWithCronet(candidate, enableQuic = true)
            } catch (error: Throwable) {
                lastError = error
                Log.w(TAG, "Cronet/QUIC no pudo descargar .torrent desde $candidate: ${error.message}")
            }
        }

        for (candidate in candidates) {
            try {
                return downloadTorrentBytesWithHttp(candidate)
            } catch (error: Throwable) {
                lastError = error
                Log.w(TAG, "HTTP no pudo descargar .torrent desde $candidate: ${error.message}")
            }
        }

        throw IOException("No se pudo descargar el .torrent: ${lastError?.message ?: "error desconocido"}", lastError)
    }

    private fun torrentSourceCandidates(sourceUri: String): List<String> {
        val clean = sourceUri.trim()
        val candidates = linkedSetOf(clean)
        if (clean.startsWith("https://grantorrent.wtf", ignoreCase = true)) {
            candidates += clean.replaceFirst("https://", "http://", ignoreCase = true)
            if (!clean.contains("?")) candidates += "$clean?downtv=1"
        }
        return candidates.toList()
    }

    private fun downloadTorrentBytesWithHttp(sourceUri: String): ByteArray {
        val connection = (URL(sourceUri).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            )
            setRequestProperty("Accept", "application/x-bittorrent,application/octet-stream,*/*")
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
            setRequestProperty("Referer", sourceUri.substringBeforeLast('/', "https://grantorrent.wtf") + "/")
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
        connection.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code al descargar .torrent")
        if (bytes.size < 32) throw IllegalStateException(".torrent vacío o inválido")
        return bytes
    }

    private fun downloadTorrentBytesWithCronet(sourceUri: String, enableQuic: Boolean): ByteArray {
        val engine = CronetEngine.Builder(context.applicationContext)
            .enableHttp2(true)
            .enableQuic(enableQuic)
            .enableBrotli(true)
            .build()
        val executor = Executors.newSingleThreadExecutor()
        val latch = CountDownLatch(1)
        val body = ByteArrayOutputStream()
        val errorRef = AtomicReference<Throwable?>(null)
        val statusRef = AtomicReference<Int?>(null)

        val callback = object : UrlRequest.Callback() {
            override fun onRedirectReceived(request: UrlRequest, info: UrlResponseInfo, newLocationUrl: String) {
                request.followRedirect()
            }

            override fun onResponseStarted(request: UrlRequest, info: UrlResponseInfo) {
                statusRef.set(info.httpStatusCode)
                request.read(ByteBuffer.allocateDirect(64 * 1024))
            }

            override fun onReadCompleted(request: UrlRequest, info: UrlResponseInfo, byteBuffer: ByteBuffer) {
                byteBuffer.flip()
                val chunk = ByteArray(byteBuffer.remaining())
                byteBuffer.get(chunk)
                body.write(chunk)
                byteBuffer.clear()
                request.read(byteBuffer)
            }

            override fun onSucceeded(request: UrlRequest, info: UrlResponseInfo) {
                statusRef.set(info.httpStatusCode)
                latch.countDown()
            }

            override fun onFailed(request: UrlRequest, info: UrlResponseInfo?, error: CronetException) {
                errorRef.set(error)
                latch.countDown()
            }
        }

        try {
            engine.newUrlRequestBuilder(sourceUri, callback, executor)
                .addHeader(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; SAMSUNG SM-A165F) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) SamsungBrowser/27.0 Chrome/125.0.0.0 Mobile Safari/537.36"
                )
                .addHeader("Accept", "application/x-bittorrent,application/octet-stream,*/*")
                .addHeader("Accept-Language", "es-ES,es;q=0.9")
                .addHeader("Referer", sourceUri.substringBeforeLast('/', "https://grantorrent.wtf") + "/")
                .build()
                .start()

            if (!latch.await(35, TimeUnit.SECONDS)) {
                throw IOException("Timeout Cronet al descargar .torrent")
            }
            errorRef.get()?.let { throw IOException("Cronet fallo al descargar .torrent: ${it.message}", it) }
            val code = statusRef.get() ?: 0
            val bytes = body.toByteArray()
            if (code !in 200..299) throw IllegalStateException("HTTP $code al descargar .torrent con Cronet")
            if (bytes.size < 32) throw IllegalStateException(".torrent vacio o invalido")
            return bytes
        } finally {
            try { engine.shutdown() } catch (_: Throwable) {}
            executor.shutdownNow()
        }
    }

    fun stopStreaming() {
        Log.d(TAG, "Stopping torrent stream")
        isStreaming = false

        try {
            serverSocket?.close()
        } catch (_: Throwable) {
        }
        serverSocket = null
        serverThread?.interrupt()
        serverThread = null
        streamingUrl = null

        val manager = sessionManager

        synchronized(torrentLock) {
            torrentHandle = null
            torrentInfo = null
            selectedFile = null
            latestStats = DownloadStats()
            confirmedPrefixBytes = 0L
        }
        atomicTotalWantedDone.set(0L)
        atomicDownloadRate.set(0L)
        atomicNumSeeds.set(0L)
        atomicNumPeers.set(0L)
        streamingHandleConfigured.set(false)
        sessionManager = null

        try {
            manager?.stop()
        } catch (error: Throwable) {
            Log.e(TAG, "Error stopping torrent session", error)
        }

        downloadDir = null
    }

    fun getProgress(): Float {
        return latestStats.progress
    }

    fun getDownloadRate(): Int {
        return latestStats.downloadRate
    }
    
    fun getDownloadStats(): DownloadStats {
        return latestStats
    }
    
    data class DownloadStats(
        val progress: Float = 0f,
        val downloadRate: Int = 0,
        val totalWanted: Long = 0L,
        val totalWantedDone: Long = 0L,
        val eta: Int = -1,
        val numSeeds: Int = 0,
        val numPeers: Int = 0
    )

    private fun torrentDownloadDir(): File {
        // Guardar los torrents en almacenamiento INTERNO de la app.
        // En algunos Android/Samsung, libtorrent mantiene un fd abierto sobre
        // /storage/emulated/0/Android/data/... y vold interrumpe el proceso
        // cuando detecta el archivo grande/sparse. El logcat lo confirma:
        // "vold: Sending Interrupt to pid ... com.kotatv".
        return File(context.filesDir, "DownTV/torrents").apply { mkdirs() }
    }

    private fun createAlertListener(torrentError: AtomicReference<String?>): AlertListener {
        return object : AlertListener {
            override fun alert(alert: Alert<*>?) {
                try {
                    if (alert == null) return
                    if (!isStreaming) return

                    when (alert.type()) {
                    AlertType.ADD_TORRENT -> {
                        val handle = (alert as AddTorrentAlert).handle()
                        synchronized(torrentLock) {
                            torrentHandle = handle
                        }
                        Log.d(TAG, "Torrent added - safe mode, handle stored only")
                    }

                    AlertType.STATE_UPDATE -> {
                        // Modo seguro: ignoramos STATE_UPDATE para no consultar estados nativos.
                        // El progreso se estima por datos reales escritos en disco.
                    }

                    AlertType.PIECE_FINISHED -> {
                        // Modo seguro: no tocamos TorrentHandle desde alerts de piezas.
                    }

                    AlertType.METADATA_RECEIVED -> {
                        Log.d(TAG, "Torrent metadata received")
                    }

                    AlertType.TORRENT_ERROR -> {
                        val message = (alert as TorrentErrorAlert).error().getMessage()
                        torrentError.set(message)
                        Log.e(TAG, "Torrent error: $message")
                    }

                    AlertType.TORRENT_FINISHED -> {
                        Log.d(TAG, "Torrent download finished")
                    }

                    else -> Unit
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in alert listener", e)
                    torrentError.set("Error en alert listener: ${e.message}")
                }
            }

            override fun types(): IntArray? = null
        }
    }

    /**
     * Modo seguro: no modificamos TorrentHandle despuÃ©s de aÃ±adir el torrent.
     * Algunas llamadas nativas como setSequentialRange(), resume() o status()
     * pueden cerrar el proceso en determinados dispositivos.
     */
    private fun configureStreamingHandleIfReady() {
        // No-op deliberado.
    }

    private fun waitForPlayableBuffer(
        selected: SelectedTorrentFile,
        torrentError: AtomicReference<String?>
    ): String {
        val timeoutAt = System.nanoTime() + TimeUnit.SECONDS.toNanos(PLAYBACK_TIMEOUT_SECONDS)

        while (isStreaming && System.nanoTime() < timeoutAt) {
            torrentError.get()?.let { throw IllegalStateException(it) }
            val stats = refreshDownloadStats()

            Log.d(TAG, "Buffer check: done=${stats.totalWantedDone/1024/1024}MB disk=${downloadedBytesOnDisk(selected)/1024/1024}MB needed=${initialBufferBytes(selected)/1024/1024}MB tailReady=${if (needsTailMetadata(selected)) isTailBufferReady(selected) else true} fileExists=${selected.file.exists()} fileLen=${selected.file.length()/1024/1024}MB")

            if (isInitialBufferReady(selected, stats)) {
                val url = startLocalServer(selected)
                Log.d(TAG, "Torrent stream ready at $url")
                return url
            }

            Thread.sleep(500L)
        }

        Log.w(TAG, "Timeout esperando buffer del torrent despuÃ©s de ${PLAYBACK_TIMEOUT_SECONDS}s - posible falta de seeders")
                throw IllegalStateException("El torrent tardÃ³ demasiado en entregar datos reproducibles. Reintenta o espera unos minutos.")
    }

    private fun selectTorrentFile(
        info: TorrentInfo,
        requestedFileIndex: Int?,
        targetDir: File,
        requireWebViewCompatible: Boolean
    ): SelectedTorrentFile {
        val files = info.files()
        val count = files.numFiles()
        if (count <= 0) throw IllegalStateException("El torrent no contiene archivos")

        val requested = requestedFileIndex?.takeIf { it in 0 until count }
        if (requested != null && !isAllowedVideoFile(
                files.fileName(requested),
                files.filePath(requested),
                requireWebViewCompatible
            )
        ) {
            val requestedName = files.filePath(requested).ifBlank { files.fileName(requested) }
            val extension = fileExtension(requestedName).uppercase(Locale.US).ifBlank { "sin extension" }
            val message = if (requireWebViewCompatible) {
                "El archivo seleccionado es $extension y no es compatible con el reproductor interno. Abre este torrent con un reproductor externo o elige un MP4, M4V o WEBM."
            } else {
                "El archivo seleccionado es $extension y no parece ser un video reproducible."
            }
            throw IllegalStateException(message)
        }

        val fallback = (0 until count)
            .filter {
                isAllowedVideoFile(
                    files.fileName(it),
                    files.filePath(it),
                    requireWebViewCompatible
                )
            }
            .maxByOrNull { files.fileSize(it) }
            ?: throw IllegalStateException(
                if (requireWebViewCompatible) {
                    "No se encontro un archivo MP4, M4V o WEBM compatible en el torrent"
                } else {
                    "No se encontro un archivo de video reconocible en el torrent"
                }
            )

        val index = requested ?: fallback
        val relativePath = files.filePath(index).ifBlank { files.fileName(index) }
        val displayName = files.fileName(index).ifBlank { relativePath.substringAfterLast('/') }
        val outputFile = resolveTorrentOutputFile(targetDir, relativePath)
        val size = files.fileSize(index)
        if (size <= 0L) throw IllegalStateException("El archivo seleccionado esta vacio")

        return SelectedTorrentFile(
            index = index,
            displayName = displayName,
            relativePath = relativePath,
            file = outputFile,
            size = size,
            firstPiece = files.pieceIndexAtFile(index),
            lastPiece = files.lastPieceIndexAtFile(index),
            requireWebViewCompatible = requireWebViewCompatible
        )
    }

    private fun buildFilePriorities(info: TorrentInfo, selectedIndex: Int): Array<Priority> {
        val count = info.files().numFiles()
        return Array(count) { index ->
            if (index == selectedIndex) Priority.TOP_PRIORITY else Priority.IGNORE
        }
    }

    private fun addTorrentForStreaming(
        manager: SessionManager,
        info: TorrentInfo,
        targetDir: File,
        selected: SelectedTorrentFile
    ) {
        val params = add_torrent_params()
        params.set_ti(info.swig())
        params.setSave_path(targetDir.absolutePath)
        
        // MODO SPARSE: No pre-asignar el archivo completo en disco.
        // Pre-allocation de archivos grandes (ej. 1.5GB) causa que el lmkd
        // (Low Memory Killer) mate la app por presiÃ³n de memoria.
        params.setStorage_mode(storage_mode_t.storage_mode_sparse)

        // ConfiguraciÃ³n optimizada para streaming
        params.setFlags(params.getFlags().or_(TorrentFlags.SEQUENTIAL_DOWNLOAD))
        params.set_file_priorities(toPriorityVector(buildFilePriorities(info, selected.index)))
        params.set_piece_priorities(buildPiecePriorities(info, selected))
        
        // ConfiguraciÃ³n de red para mejor conectividad
        params.setUpload_limit(0) // Sin lÃ­mite de upload
        params.setDownload_limit(0) // Sin lÃ­mite de download
        
        manager.swig().async_add_torrent(params)
        Log.d(TAG, "Torrent queued with optimized streaming configuration")
    }

    private fun buildPiecePriorities(info: TorrentInfo, selected: SelectedTorrentFile): byte_vector {
        val vector = byte_vector()
        val firstBufferLastPiece = initialBufferLastPiece(info, selected)
        val tailBufferFirstPiece = tailBufferFirstPiece(info, selected)

        for (piece in 0 until info.numPieces()) {
            val priority = when {
                piece < selected.firstPiece || piece > selected.lastPiece -> Priority.IGNORE
                // Para streaming real hacen falta dos zonas crÃ­ticas:
                // 1) El principio del archivo, donde suele estar la cabecera.
                // 2) El final del archivo, porque muchos MP4/MOV guardan ahÃ­ el Ã­ndice/moov.
                // Si VLC pide el final y no estÃ¡ descargado, se queda indefinidamente en Buffering.
                piece <= firstBufferLastPiece -> Priority.TOP_PRIORITY
                piece >= tailBufferFirstPiece -> Priority.TOP_PRIORITY
                else -> Priority.DEFAULT
            }
            vector.add(priority.swig())
        }

        Log.d(
            TAG,
            "Prioritized start pieces ${selected.firstPiece}..$firstBufferLastPiece and tail pieces $tailBufferFirstPiece..${selected.lastPiece}"
        )
        return vector
    }

    private fun toPriorityVector(priorities: Array<Priority>): byte_vector {
        val vector = byte_vector()
        priorities.forEach { priority ->
            vector.add(priority.swig())
        }
        return vector
    }

    private fun initialBufferLastPiece(info: TorrentInfo, selected: SelectedTorrentFile): Int {
        val pieceLength = max(1L, info.pieceLength().toLong())
        val piecesNeeded = ((initialBufferBytes(selected) + pieceLength - 1L) / pieceLength)
            .coerceAtLeast(1L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
        return min(selected.lastPiece, selected.firstPiece + piecesNeeded)
    }

    private fun tailBufferFirstPiece(info: TorrentInfo, selected: SelectedTorrentFile): Int {
        val pieceLength = max(1L, info.pieceLength().toLong())
        val piecesNeeded = ((tailBufferBytes(selected) + pieceLength - 1L) / pieceLength)
            .coerceAtLeast(1L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()
        return max(selected.firstPiece, selected.lastPiece - piecesNeeded + 1)
    }

    private fun resolveTorrentOutputFile(baseDir: File, relativePath: String): File {
        val normalizedPath = relativePath.replace('\\', '/').trimStart('/')
        val base = baseDir.canonicalFile
        val candidate = File(base, normalizedPath).canonicalFile
        val basePath = base.path + File.separator

        return if (candidate.path == base.path || candidate.path.startsWith(basePath)) {
            candidate
        } else {
            File(base, normalizedPath.substringAfterLast('/')).canonicalFile
        }
    }

    private fun isInitialBufferReady(
        selected: SelectedTorrentFile,
        stats: DownloadStats
    ): Boolean {
        val neededStartBytes = initialBufferBytes(selected)

        // MÃ©todo 1: Verificar stats de libtorrent (totalWantedDone)
        val statsStartReady = stats.totalWantedDone >= neededStartBytes

        // MÃ©todo 2 (fallback): Verificar datos reales en disco.
        // Si totalWantedDone es 0 pero hay datos reales escritos, los stats estÃ¡n desactualizados.
        val diskBytes = downloadedBytesOnDisk(selected)
        val diskStartReady = diskBytes >= neededStartBytes

        val startReady = statsStartReady || diskStartReady
        if (!startReady) return false

        // Para MP4/M4V/MOV, VLC suele pedir el final del archivo al principio para leer el Ã­ndice/moov.
        // Si el final no estÃ¡ todavÃ­a, el reproductor se queda en "Buffering desde torrent..." aunque ya
        // haya datos descargados al inicio. Por eso esperamos un pequeÃ±o buffer final antes de entregar URL.
        if (needsTailMetadata(selected) && !isTailBufferReady(selected)) {
            Log.d(TAG, "Start buffer ready, waiting for MP4/MOV tail metadata buffer")
            return false
        }

        if (diskStartReady && !statsStartReady) {
            Log.d(TAG, "Buffer ready via disk check: ${diskBytes/1024/1024}MB (stats were stale at ${stats.totalWantedDone/1024/1024}MB)")
        }
        return true
    }

    private fun initialBufferBytes(selected: SelectedTorrentFile): Long {
        val maxInitial = if (selected.requireWebViewCompatible) {
            MAX_INITIAL_BUFFER_BYTES
        } else {
            VLC_INITIAL_BUFFER_BYTES
        }
        return min(
            selected.size,
            min(max(selected.size / 50L, MIN_INITIAL_BUFFER_BYTES), maxInitial)
        )
    }

    private fun tailBufferBytes(selected: SelectedTorrentFile): Long {
        return min(selected.size, TAIL_BUFFER_BYTES)
    }

    private fun needsTailMetadata(selected: SelectedTorrentFile): Boolean {
        return fileExtension(selected.displayName.ifBlank { selected.relativePath }) in setOf("mp4", "m4v", "mov")
    }

    private fun isTailBufferReady(selected: SelectedTorrentFile): Boolean {
        val tailBytes = tailBufferBytes(selected)
        if (tailBytes <= 0L || selected.size <= tailBytes) return true
        val tailStart = (selected.size - tailBytes).coerceAtLeast(0L)
        val lastChunkStart = (selected.size - DATA_PRESENCE_CHUNK_BYTES).coerceAtLeast(tailStart)
        return hasDataAtOffset(selected, tailStart) && hasDataAtOffset(selected, lastChunkStart)
    }

    private fun ensureSparsePlaceholderFile(selected: SelectedTorrentFile) {
        try {
            selected.file.parentFile?.mkdirs()
            RandomAccessFile(selected.file, "rw").use { file ->
                if (file.length() < selected.size) {
                    file.setLength(selected.size)
                }
            }
        } catch (error: Throwable) {
            Log.w(TAG, "No se pudo crear placeholder sparse para VLC: ${error.message}")
        }
    }

    private fun startLocalServer(selected: SelectedTorrentFile): String {
        streamingUrl?.let { return it }

        val socket = ServerSocket(0, 24, InetAddress.getByName("127.0.0.1"))
        serverSocket = socket

        val url = "http://127.0.0.1:${socket.localPort}/"
        streamingUrl = url

        serverThread = Thread {
            while (isStreaming && !socket.isClosed) {
                try {
                    val client = socket.accept()
                    Thread {
                        handleHttpClient(client, selected)
                    }.apply {
                        name = "KotaTorrentHttpClient"
                        start()
                    }
                } catch (error: SocketException) {
                    if (isStreaming) Log.w(TAG, "Torrent server socket closed", error)
                } catch (error: Throwable) {
                    if (isStreaming) Log.w(TAG, "Torrent server error", error)
                }
            }
        }.apply {
            name = "KotaTorrentHttpServer"
            start()
        }

        return url
    }

    private fun handleHttpClient(socket: Socket, selected: SelectedTorrentFile) {
        try {
            socket.use { client ->
                client.soTimeout = SOCKET_TIMEOUT_MS

                val reader = client.getInputStream().bufferedReader(StandardCharsets.ISO_8859_1)
                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(' ')
                val method = parts.getOrNull(0)?.uppercase(Locale.US) ?: "GET"
                val path = normalizeHttpPath(parts.getOrNull(1))
                var rangeHeader: String? = null

                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    val separator = line.indexOf(':')
                    if (separator <= 0) continue

                    val name = line.substring(0, separator).trim()
                    if (name.equals("Range", ignoreCase = true)) {
                        rangeHeader = line.substring(separator + 1).trim()
                    }
                }

                val output = BufferedOutputStream(client.getOutputStream())
                when {
                    method !in setOf("GET", "HEAD") -> sendEmpty(output, 405, "Method Not Allowed")
                    path == "/" || path == "/index.html" -> sendPlayerPage(output, method == "HEAD", selected)
                    path == "/video" -> sendVideo(output, method == "HEAD", rangeHeader, selected)
                    else -> sendEmpty(output, 404, "Not Found")
                }
                output.flush()
            }
        } catch (error: Throwable) {
            if (isStreaming) Log.w(TAG, "HTTP client error", error)
        }
    }

    private fun normalizeHttpPath(requestTarget: String?): String {
        val target = requestTarget?.trim().orEmpty()
        if (target.isBlank()) return "/"
        val path = if (target.startsWith("http://", ignoreCase = true) ||
            target.startsWith("https://", ignoreCase = true)
        ) {
            try {
                java.net.URI(target).rawPath.orEmpty()
            } catch (_: Throwable) {
                target.substringAfter("://").substringAfter('/', "")
            }
        } else {
            target
        }
        val cleanPath = path.substringBefore('?').ifBlank { "/" }
        return if (cleanPath.startsWith('/')) cleanPath else "/$cleanPath"
    }

    private fun sendPlayerPage(
        output: BufferedOutputStream,
        headOnly: Boolean,
        selected: SelectedTorrentFile
    ) {
        val safeTitle = escapeHtml(selected.displayName)
        val body = """
            <!doctype html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>$safeTitle</title>
                <style>
                    html, body { margin: 0; width: 100%; height: 100%; background: #000; overflow: hidden; }
                    video { width: 100%; height: 100%; background: #000; object-fit: contain; }
                    #error-msg {
                        display: none;
                        position: fixed; inset: 0;
                        background: #02030A;
                        color: #F1F5F9;
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        padding: 24px;
                        box-sizing: border-box;
                    }
                    #error-msg .icon { font-size: 48px; margin-bottom: 16px; }
                    #error-msg .title { font-size: 18px; font-weight: 600; color: #F87171; margin-bottom: 10px; }
                    #error-msg .detail { font-size: 13px; color: #94A3B8; line-height: 1.6; max-width: 360px; }
                </style>
            </head>
            <body>
                <video id="player" controls autoplay playsinline preload="auto" src="/video"></video>
                <div id="error-msg">
                    <div class="icon">!</div>
                    <div class="title">Error de decodificación</div>
                    <div class="detail" id="error-detail">
                        El dispositivo no puede reproducir este archivo.<br><br>
                        Posibles causas:<br>
                        • Codec no soportado (H.265/HEVC, AV1)<br>
                        • Contenedor incompatible (MKV, AVI)<br>
                        • Archivo dañado o incompleto<br><br>
                        Prueba con otro torrent en formato MP4/H.264.
                    </div>
                </div>
                <script>
                    const player = document.getElementById('player');
                    const errorMsg = document.getElementById('error-msg');
                    const errorDetail = document.getElementById('error-detail');

                    player.focus();
                    player.play().catch(function() {});

                    player.addEventListener('error', function() {
                        const err = player.error;
                        let detail = 'El dispositivo no puede reproducir este archivo.';
                        if (err) {
                            if (err.code === 3) {
                                detail = 'Error de decodificación (PIPELINE_ERROR_DECODE).<br><br>' +
                                    'El codec o contenedor no está soportado por este dispositivo.<br><br>' +
                                    'Causas comunes:<br>' +
                                    '• Codec H.265/HEVC (no soportado en WebView)<br>' +
                                    '• Contenedor MKV o AVI<br>' +
                                    '• Codec de audio AC3/DTS<br><br>' +
                                    'Elige un torrent MP4 con H.264 y AAC.';
                            } else if (err.code === 4) {
                                detail = 'Formato de video no soportado (MEDIA_ERR_SRC_NOT_SUPPORTED).<br><br>' +
                                    'El archivo no puede reproducirse en este dispositivo.<br><br>' +
                                    'Elige un torrent MP4 con H.264.';
                            } else {
                                detail = 'Error de reproducción (código ' + err.code + ').<br>' +
                                    (err.message ? err.message : '') + '<br><br>' +
                                    'Prueba con otro torrent en formato MP4/H.264.';
                            }
                        }
                        errorDetail.innerHTML = detail;
                        player.style.display = 'none';
                        errorMsg.style.display = 'flex';
                        // Notificar a la app nativa
                        try { window.KotaProgressBridge.onDecodeError(err ? err.code : -1); } catch(e) {}
                    });
                </script>
            </body>
            </html>
        """.trimIndent().toByteArray(StandardCharsets.UTF_8)

        writeHeaders(
            output = output,
            statusCode = 200,
            reason = "OK",
            headers = mapOf(
                "Content-Type" to "text/html; charset=utf-8",
                "Content-Length" to body.size.toString(),
                "Cache-Control" to "no-store",
                "Connection" to "close"
            )
        )

        if (!headOnly) output.write(body)
    }

    private fun sendVideo(
        output: BufferedOutputStream,
        headOnly: Boolean,
        rangeHeader: String?,
        selected: SelectedTorrentFile
    ) {
        val range = parseRange(rangeHeader, selected.size)
        if (range == null) {
            writeHeaders(
                output = output,
                statusCode = 416,
                reason = "Range Not Satisfiable",
                headers = mapOf(
                    "Content-Range" to "bytes */${selected.size}",
                    "Content-Length" to "0",
                    "Connection" to "close"
                )
            )
            return
        }

        val partial = rangeHeader != null
        val contentLength = range.end - range.start + 1L
        val headers = linkedMapOf(
            "Content-Type" to mimeTypeFor(selected.displayName),
            "Accept-Ranges" to "bytes",
            "Content-Length" to contentLength.toString(),
            "Cache-Control" to "no-store",
            "Connection" to "close"
        )
        if (partial) headers["Content-Range"] = "bytes ${range.start}-${range.end}/${selected.size}"

        writeHeaders(
            output = output,
            statusCode = if (partial) 206 else 200,
            reason = if (partial) "Partial Content" else "OK",
            headers = headers
        )

        if (!headOnly) streamVideoRange(output, selected, range)
    }

    private fun streamVideoRange(
        output: BufferedOutputStream,
        selected: SelectedTorrentFile,
        range: ByteRange
    ) {
        try {
            RandomAccessFile(selected.file, "r").use { file ->
                val buffer = ByteArray(READ_BUFFER_BYTES)
                var position = range.start

                while (isStreaming && position <= range.end) {
                    if (!waitForDataAt(selected, position)) {
                        // Timeout esperando datos â€” cerrar limpiamente sin crash
                        Log.w(TAG, "Timeout esperando datos en offset $position, cerrando stream")
                        return
                    }

                    file.seek(position)
                    val maxBytes = min(buffer.size.toLong(), range.end - position + 1L).toInt()
                    val read = file.read(buffer, 0, maxBytes)
                    if (read <= 0) {
                        Thread.sleep(250L)
                        continue
                    }

                    output.write(buffer, 0, read)
                    output.flush()
                    position += read.toLong()
                }
            }
        } catch (error: SocketException) {
            // El cliente cerrÃ³ la conexiÃ³n (seek, pausa, etc.) â€” es normal, no es un error
            Log.d(TAG, "Cliente cerrÃ³ la conexiÃ³n HTTP (normal al buscar/pausar)")
        } catch (error: java.io.IOException) {
            // Pipe rota u otro error de I/O del cliente â€” tambiÃ©n normal
            Log.d(TAG, "I/O error en stream HTTP (cliente desconectado): ${error.message}")
        }
    }

    private fun waitForDataAt(selected: SelectedTorrentFile, offset: Long): Boolean {
        val boundedOffset = offset.coerceIn(0L, selected.size - 1L)
        val timeoutAt = System.currentTimeMillis() + DATA_WAIT_TIMEOUT_MS

        while (isStreaming && System.currentTimeMillis() < timeoutAt) {
            // MÃ©todo 1: Confiar en totalWantedDone de libtorrent
            if (atomicTotalWantedDone.get() > boundedOffset) return true
            
            // MÃ©todo 2 (fallback): Verificar datos reales en disco
            if (hasDataAtOffset(selected, boundedOffset)) return true
            
            Thread.sleep(250L)
        }

        return false
    }

    /**
     * Comprueba si el archivo tiene datos reales (no ceros) en el offset dado.
     * Esto es mÃ¡s fiable que confiar solo en las estadÃ­sticas de libtorrent,
     * que pueden estar desactualizadas o ser 0 al inicio de la sesiÃ³n.
     */
    private fun hasDataAtOffset(selected: SelectedTorrentFile, offset: Long): Boolean {
        if (!selected.file.exists()) return false
        val fileLength = selected.file.length()
        if (fileLength <= offset) return false

        return try {
            val checkSize = min(DATA_PRESENCE_CHUNK_BYTES.toLong(), fileLength - offset).toInt()
            if (checkSize <= 0) return false
            val buffer = ByteArray(checkSize)
            RandomAccessFile(selected.file, "r").use { file ->
                file.seek(offset)
                val read = file.read(buffer, 0, checkSize)
                read > 0 && containsNonZeroByte(buffer, read)
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun refreshDownloadStats(): DownloadStats {
        val stats = readDownloadStats()
        latestStats = stats
        return stats
    }

    private fun readDownloadStats(): DownloadStats {
        return try {
            val selected = selectedFile ?: return latestStats

            // Leer stats de los atÃ³micos â€” actualizados por el alert listener en el hilo
            // de libtorrent. NUNCA llamamos TorrentHandle.status() desde aquÃ­.
            val statusDone = atomicTotalWantedDone.get().coerceIn(0L, selected.size)
            val statusRate = atomicDownloadRate.get().toInt().coerceAtLeast(0)
            val numSeeds   = atomicNumSeeds.get().toInt().coerceAtLeast(0)
            val numPeers   = atomicNumPeers.get().toInt().coerceAtLeast(0)

            // En modo seguro no consultamos estados nativos. Tomamos el mÃ¡ximo entre
            // lo Ãºltimo recibido por alert y los datos reales no-cero escritos al inicio del archivo.
            val downloadedBytes = max(statusDone, downloadedBytesOnDisk(selected)).coerceIn(0L, selected.size)

            val remainingBytes = selected.size - downloadedBytes
            val eta = if (statusRate > 0 && remainingBytes > 0L) {
                (remainingBytes / statusRate).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            } else {
                -1
            }

            DownloadStats(
                progress = if (selected.size > 0L) downloadedBytes.toFloat() / selected.size.toFloat() else 0f,
                downloadRate = statusRate,
                totalWanted = selected.size,
                totalWantedDone = downloadedBytes,
                eta = eta,
                numSeeds = numSeeds,
                numPeers = numPeers
            )
        } catch (_: Throwable) {
            latestStats
        }
    }

    private fun downloadedBytesOnDisk(selected: SelectedTorrentFile): Long {
        return try {
            estimateDownloadedPrefixBytes(selected)
        } catch (_: Throwable) {
            0L
        }
    }

    private fun estimateDownloadedPrefixBytes(selected: SelectedTorrentFile): Long {
        if (!selected.file.exists()) {
            confirmedPrefixBytes = 0L
            return 0L
        }

        val fileLength = selected.file.length().coerceIn(0L, selected.size)
        if (fileLength <= 0L) {
            confirmedPrefixBytes = 0L
            return 0L
        }

        var position = confirmedPrefixBytes.coerceIn(0L, fileLength)
        val scanLimit = min(fileLength, position + DATA_PRESENCE_SCAN_AHEAD_BYTES)

        RandomAccessFile(selected.file, "r").use { file ->
            val buffer = ByteArray(DATA_PRESENCE_CHUNK_BYTES)
            while (position < scanLimit) {
                val bytesToRead = min(buffer.size.toLong(), scanLimit - position).toInt()
                file.seek(position)
                val read = file.read(buffer, 0, bytesToRead)
                if (read <= 0 || !containsNonZeroByte(buffer, read)) break
                position += read.toLong()
            }
        }

        confirmedPrefixBytes = max(confirmedPrefixBytes, position).coerceIn(0L, selected.size)
        return confirmedPrefixBytes
    }

    private fun hasPlayableHeader(selected: SelectedTorrentFile): Boolean {
        return try {
            if (!selected.file.exists() || selected.file.length() < 16L) return false

            val header = ByteArray(16)
            val read = RandomAccessFile(selected.file, "r").use { it.read(header) }
            if (read < 12) return false

            when (fileExtension(selected.displayName.ifBlank { selected.relativePath })) {
                "mp4", "m4v" -> String(header, 4, 4, StandardCharsets.ISO_8859_1) == "ftyp"
                "webm" -> read >= 4 &&
                    header[0] == 0x1A.toByte() &&
                    header[1] == 0x45.toByte() &&
                    header[2] == 0xDF.toByte() &&
                    header[3] == 0xA3.toByte()
                else -> false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun containsNonZeroByte(buffer: ByteArray, length: Int): Boolean {
        for (index in 0 until length) {
            if (buffer[index].toInt() != 0) return true
        }
        return false
    }

    private fun downloadedBytesForSelected(
        selected: SelectedTorrentFile,
        stats: DownloadStats
    ): Long {
        // Usar el mÃ¡ximo entre los bytes reportados por libtorrent y los bytes reales en disco.
        // totalWantedDone puede ser 0 al inicio aunque ya haya datos escritos en disco.
        val statusBytes = if (stats.totalWanted > 0L) {
            stats.totalWantedDone.coerceIn(0L, selected.size)
        } else {
            0L
        }
        val diskBytes = downloadedBytesOnDisk(selected)
        return max(statusBytes, diskBytes)
    }

    private fun parseRange(rangeHeader: String?, size: Long): ByteRange? {
        if (size <= 0L) return null
        if (rangeHeader.isNullOrBlank()) return ByteRange(0L, size - 1L)
        if (!rangeHeader.startsWith("bytes=", ignoreCase = true)) return null

        val spec = rangeHeader.substringAfter('=').substringBefore(',').trim()
        if (spec.isBlank()) return null

        val start: Long
        val end: Long

        if (spec.startsWith("-")) {
            val suffixLength = spec.drop(1).toLongOrNull() ?: return null
            if (suffixLength <= 0L) return null
            start = max(0L, size - suffixLength)
            end = size - 1L
        } else {
            val parts = spec.split('-', limit = 2)
            start = parts.getOrNull(0)?.toLongOrNull() ?: return null
            end = parts.getOrNull(1)?.takeIf { it.isNotBlank() }?.toLongOrNull() ?: (size - 1L)
        }

        if (start < 0L || start >= size || end < start) return null
        return ByteRange(start, min(end, size - 1L))
    }

    private fun sendEmpty(output: BufferedOutputStream, statusCode: Int, reason: String) {
        writeHeaders(
            output = output,
            statusCode = statusCode,
            reason = reason,
            headers = mapOf(
                "Content-Length" to "0",
                "Cache-Control" to "no-store",
                "Connection" to "close"
            )
        )
    }

    private fun writeHeaders(
        output: BufferedOutputStream,
        statusCode: Int,
        reason: String,
        headers: Map<String, String>
    ) {
        output.write("HTTP/1.1 $statusCode $reason\r\n".toByteArray(StandardCharsets.ISO_8859_1))
        headers.forEach { (name, value) ->
            output.write("$name: $value\r\n".toByteArray(StandardCharsets.ISO_8859_1))
        }
        output.write("\r\n".toByteArray(StandardCharsets.ISO_8859_1))
    }

    private fun mimeTypeFor(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase(Locale.US)) {
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "ts", "m2ts" -> "video/mp2t"
            "wmv" -> "video/x-ms-wmv"
            "flv" -> "video/x-flv"
            else -> "application/octet-stream"
        }
    }

    private fun escapeHtml(value: String): String {
        return value
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")
    }

    private fun isWebViewPlayableFile(fileName: String): Boolean {
        return fileExtension(fileName) in WEBVIEW_VIDEO_EXTENSIONS
    }

    private fun isAllowedVideoFile(
        fileName: String,
        filePath: String,
        requireWebViewCompatible: Boolean
    ): Boolean {
        val allowedExtensions = if (requireWebViewCompatible) {
            WEBVIEW_VIDEO_EXTENSIONS
        } else {
            EXTERNAL_PLAYER_VIDEO_EXTENSIONS
        }
        return fileExtension(fileName) in allowedExtensions || fileExtension(filePath) in allowedExtensions
    }

    private fun fileExtension(fileName: String): String {
        return fileName.substringAfterLast('.', "").lowercase(Locale.US)
    }
}
