package com.kotatv

import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/**
 * Gestor para el catálogo de series de Mega-Series con temporadas y episodios.
 */
data class MegaSeries(
    val id: String,
    val title: String,
    val posterUrl: String,
    val year: String,
    val rating: String,
    val description: String,
    val seasons: List<Season>,
    val url: String = "" // URL de la página de la serie
)

data class Season(
    val number: Int,
    val episodes: List<Episode>
)

data class Episode(
    val number: Int,
    val title: String,
    val shortenerLinks: List<String> // Enlaces a acortadores (ouo.io, etc.)
)

object MegaSeriesManager {
    private const val TAG = "MegaSeriesManager"
    private const val BASE_URL = "https://megadescargas-new.blogspot.com"
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    
    // Acortadores conocidos que se resolverán automáticamente
    val KNOWN_SHORTENERS = setOf(
        "ouo.io", "ouo.press", "shrinkme.io", "shorte.st", "adf.ly",
        "linkvertise.com", "exe.io", "bc.vc", "fc.lc", "cuty.io",
        "shrinkearn.com", "earnviral.com", "gplinks.co", "oke.io",
        "za.gl", "du-link.in", "link1s.com", "short.pe", "clk.sh",
        "adshort.co", "cpmlink.net", "shon.xyz", "adbull.org"
    )
    
    /**
     * Obtiene el catálogo de series desde Mega-Series.
     */
    fun fetchSeriesCatalog(): List<MegaSeries> {
        val catalogUrls = listOf(
            BASE_URL,
            "$BASE_URL/p/catalogo-de-series.html",
            "https://mega-descargas-serie.blogspot.com/p/catalogo-de-series.html"
        )
        val allSeries = mutableListOf<MegaSeries>()
        for (url in catalogUrls) {
            try {
                Log.d(TAG, "Fetching series catalog from: $url")
                val html = fetchHtml(url)
                Log.d(TAG, "HTML fetched, size: ${html.length} bytes")
                val series = parseSeriesCatalog(html)
                Log.d(TAG, "Parsed ${series.size} series from catalog URL $url")
                allSeries += series
                if (allSeries.size >= 80) break
            } catch (e: Exception) {
                Log.w(TAG, "Error fetching series catalog $url: ${e.message}")
            }
        }
        return allSeries.distinctBy { it.url }.take(160)
    }
    
    /**
     * Obtiene los detalles de una serie específica con todas sus temporadas y episodios.
     */
    fun fetchSeriesDetails(seriesUrl: String): MegaSeries? {
        val candidates = seriesDetailUrlCandidates(seriesUrl)
        var lastError: Exception? = null
        for (candidate in candidates) {
            try {
                Log.d(TAG, "Fetching series details from: $candidate")
                val html = fetchHtml(candidate)
                val parsed = parseSeriesDetails(html, candidate)
                if (parsed != null && parsed.seasons.isNotEmpty()) return parsed
                if (parsed != null) {
                    Log.w(TAG, "Series detail had no episodes: $candidate")
                }
            } catch (e: Exception) {
                lastError = e
                Log.w(TAG, "Error fetching series details candidate $candidate: ${e.message}")
            }
        }
        lastError?.let { Log.e(TAG, "Error fetching series details: $seriesUrl", it) }
        return null
    }

    private fun seriesDetailUrlCandidates(seriesUrl: String): List<String> {
        val clean = seriesUrl.trim().replace("http://", "https://", ignoreCase = true)
        val candidates = linkedSetOf(clean)
        candidates += clean.replace("megadescargas-new.blogspot.com", "mega-descargas-serie.blogspot.com")
        candidates += clean.replace("mega-descargas-serie.blogspot.com", "megadescargas-new.blogspot.com")
        candidates += clean.replace("megadescarga-gratis.blogspot.com", "megadescargas-new.blogspot.com")
        candidates += clean.replace("megadescargas-new.blogspot.com", "megadescarga-gratis.blogspot.com")
        return candidates.filter { it.startsWith("https://", ignoreCase = true) }.distinct()
    }
    
    private fun parseSeriesCatalog(html: String): List<MegaSeries> {
        val series = mutableListOf<MegaSeries>()
        
        try {
            Log.d(TAG, "Parsing series catalog, HTML length: ${html.length}")
            
            // Patrón 1: <a href="URL"><img src="POSTER" title="TITLE" /></a>
            val imgLinkPattern1 = Regex("""<a[^>]*href=["']([^"']+)["'][^>]*>[\s\S]*?<img[^>]*src=["']([^"']+)["'][^>]*title=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
            
            // Patrón 2: <img title="TITLE" src="POSTER" /> dentro de <a href="URL">
            val imgLinkPattern2 = Regex("""<a[^>]*href=["']([^"']+)["'][^>]*>[\s\S]*?<img[^>]*title=["']([^"']+)["'][^>]*src=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
            
            // Patrón 3: <a href="URL" title="TITLE"><img src="POSTER" /></a>
            val imgLinkPattern3 = Regex("""<a[^>]*href=["']([^"']+)["'][^>]*title=["']([^"']+)["'][^>]*>[\s\S]*?<img[^>]*src=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
            
            val seenTitles = mutableSetOf<String>()
            val seenUrls = mutableSetOf<String>()
            
            // Intentar con todos los patrones
            val allMatches = mutableListOf<Triple<String, String, String>>() // url, posterUrl, title
            
            // Patrón 1
            imgLinkPattern1.findAll(html).forEach { match ->
                val url = match.groupValues[1]
                val posterUrl = match.groupValues[2]
                val title = match.groupValues[3]
                allMatches.add(Triple(url, posterUrl, title))
            }
            
            // Patrón 2
            imgLinkPattern2.findAll(html).forEach { match ->
                val url = match.groupValues[1]
                val title = match.groupValues[2]
                val posterUrl = match.groupValues[3]
                allMatches.add(Triple(url, posterUrl, title))
            }
            
            // Patrón 3
            imgLinkPattern3.findAll(html).forEach { match ->
                val url = match.groupValues[1]
                val title = match.groupValues[2]
                val posterUrl = match.groupValues[3]
                allMatches.add(Triple(url, posterUrl, title))
            }

            val imageAnchorPattern = Regex(
                """<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?<img[^>]*>[\s\S]*?)</a>""",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            val srcPattern = Regex("""\b(?:src|data-src)=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            val titleAttrPattern = Regex("""\b(?:title|alt)=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            imageAnchorPattern.findAll(html).forEach { match ->
                val url = normalizeSeriesUrl(match.groupValues[1])
                val anchorHtml = match.groupValues[2]
                val posterUrl = srcPattern.find(anchorHtml)?.groupValues?.getOrNull(1).orEmpty()
                if (posterUrl.isBlank()) return@forEach
                val title = titleAttrPattern.find(anchorHtml)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.takeIf { it.isNotBlank() }
                    ?: titleFromSeriesUrl(url)
                allMatches.add(Triple(url, posterUrl, title))
            }
            
            Log.d(TAG, "Found ${allMatches.size} potential series entries")
            
            for ((url, posterUrl, rawTitle) in allMatches) {
                // Limpiar título
                val normalizedUrl = normalizeSeriesUrl(url)
                val rawCleanTitle = cleanHtml(rawTitle)
                val title = rawCleanTitle
                    .takeUnless { it.startsWith("http", ignoreCase = true) }
                    .orEmpty()
                    .ifBlank { titleFromSeriesUrl(normalizedUrl) }
                
                // Filtrar títulos vacíos o duplicados
                if (title.isBlank() || title.length < 3) continue
                if (!isCastellanoSeriesEntry(title, normalizedUrl)) continue
                if (title in seenTitles) continue
                if (normalizedUrl in seenUrls) continue
                
                // Filtrar imágenes que no son series (iconos, logos, etc.)
                if (posterUrl.contains("icon", ignoreCase = true) || 
                    posterUrl.contains("logo", ignoreCase = true) ||
                    posterUrl.contains("avatar", ignoreCase = true) ||
                    posterUrl.contains("button", ignoreCase = true)) {
                    continue
                }
                
                // Filtrar URLs que no son series (páginas de navegación, etc.)
                if (title.contains("Página", ignoreCase = true)) continue
                if (title.contains("Siguiente", ignoreCase = true)) continue
                if (title.contains("Anterior", ignoreCase = true)) continue
                if (title.contains("Home", ignoreCase = true)) continue
                
                // Filtrar URLs que no apuntan a posts de series
                if (!isSeriesPostUrl(normalizedUrl)) {
                    continue
                }
                
                // Mejorar calidad de imagen
                val improvedPosterUrl = posterUrl
                    .replace("/s72-c/", "/s800/")
                    .replace("/s113/", "/s800/")
                    .replace("/s200/", "/s800/")
                    .replace("/s320/", "/s800/")
                    .replace("/s400/", "/s800/")
                    .replace("/s640/", "/s800/")
                
                // Extraer año del título
                val yearPattern = Regex("""\b(19|20)\d{2}\b""")
                val year = yearPattern.find(title)?.value ?: ""
                
                seenTitles.add(title)
                seenUrls.add(normalizedUrl)
                
                series.add(MegaSeries(
                    id = normalizedUrl.hashCode().toString(),
                    title = title,
                    posterUrl = improvedPosterUrl,
                    year = year,
                    rating = "",
                    description = "",
                    seasons = emptyList(),
                    url = normalizedUrl
                ))
                
                Log.d(TAG, "Added series: $title -> $normalizedUrl")
            }
            
            Log.d(TAG, "Parsed ${series.size} series from catalog (found ${seenTitles.size} unique titles)")
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing series catalog: ${e.message}", e)
        }
        
        return series
    }
    
    private fun parseSeriesDetails(html: String, seriesUrl: String): MegaSeries? {
        try {
            // Extraer título de la serie
            val titlePattern = Regex("""<h[12][^>]*class=["'][^"']*(?:post-title|entry-title)[^"']*["'][^>]*>(.*?)</h[12]>""", RegexOption.DOT_MATCHES_ALL)
            val titleMatch = titlePattern.find(html)
            val ogTitle = Regex("""<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1)
                ?.let { cleanHtml(it) }
            val title = titleMatch?.groupValues?.get(1)?.let { cleanHtml(it) }
                ?: ogTitle
                ?: titleFromSeriesUrl(seriesUrl)
            
            // Extraer poster
            val ogImage = Regex("""<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1)
            val imgPattern = Regex("""<img[^>]*src=["']([^"']+)["'][^>]*>""")
            val imgMatch = imgPattern.find(html)
            val posterUrl = ogImage ?: imgMatch?.groupValues?.get(1) ?: ""
            
            // Extraer año
            val yearPattern = Regex("""\b(19|20)\d{2}\b""")
            val yearMatch = yearPattern.find(html)
            val year = yearMatch?.value ?: ""
            
            // Extraer descripción
            val descPattern = Regex("""<(?:div|p)[^>]*class=["'][^"']*(?:post-body|entry-content)[^"']*["'][^>]*>(.*?)</(?:div|p)>""", RegexOption.DOT_MATCHES_ALL)
            val descMatch = descPattern.find(html)
            val description = descMatch?.groupValues?.get(1)?.let { cleanHtml(it).take(300) } ?: ""
            
            // Parsear temporadas y episodios
            val seasons = parseSeasons(html)
            
            return MegaSeries(
                id = seriesUrl.hashCode().toString(),
                title = title,
                posterUrl = posterUrl,
                year = year,
                rating = "",
                description = description,
                seasons = seasons,
                url = seriesUrl
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing series details: ${e.message}", e)
            return null
        }
    }
    
    /**
     * Extrae el texto recortado de temporada y episodio del HTML.
     * Retorna el texto limpio que rodea al enlace del episodio.
     */
    fun extractEpisodeContext(html: String, episodeLink: String): String {
        try {
            val linkPos = html.indexOf(episodeLink)
            if (linkPos < 0) return ""
            
            // Buscar en 1000 caracteres antes y después del enlace
            val contextStart = maxOf(0, linkPos - 1000)
            val contextEnd = minOf(html.length, linkPos + 1000)
            val context = html.substring(contextStart, contextEnd)
            
            // Buscar patrones de temporada y episodio
            val seasonPattern = Regex("""(?:Temporada|Season|T\.?|Temp\.?)\s*(\d+)""", RegexOption.IGNORE_CASE)
            val episodePattern = Regex("""(?:Episodio|Capítulo|Cap\.?|Ep\.?|E|Episode|Chapter)\s*(\d+)""", RegexOption.IGNORE_CASE)
            val sEpisodePattern = Regex("""S(\d+)E(\d+)""", RegexOption.IGNORE_CASE)
            val formatPattern = Regex("""(\d+)[xX](\d+)""")
            
            var seasonNum = 0
            var episodeNum = 0
            
            // Intentar extraer temporada y episodio
            val sMatch = sEpisodePattern.find(context)
            val formatMatch = formatPattern.find(context)
            val seasonMatch = seasonPattern.find(context)
            val episodeMatch = episodePattern.find(context)
            
            when {
                sMatch != null -> {
                    seasonNum = sMatch.groupValues[1].toIntOrNull() ?: 0
                    episodeNum = sMatch.groupValues[2].toIntOrNull() ?: 0
                }
                formatMatch != null -> {
                    seasonNum = formatMatch.groupValues[1].toIntOrNull() ?: 0
                    episodeNum = formatMatch.groupValues[2].toIntOrNull() ?: 0
                }
                else -> {
                    seasonNum = seasonMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    episodeNum = episodeMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
                }
            }
            
            return if (seasonNum > 0 && episodeNum > 0) {
                "TEMPORADA $seasonNum Episodio $episodeNum:"
            } else if (episodeNum > 0) {
                "Episodio $episodeNum:"
            } else {
                ""
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting episode context: ${e.message}")
            return ""
        }
    }
    
    /**
     * Parsea las temporadas y episodios del HTML de una serie.
     * Busca patrones comunes como "Temporada 1", "Season 1", "T1", etc.
     */
    private fun parseSeasons(html: String): List<Season> {
        val seasons = mutableMapOf<Int, MutableList<Episode>>()
        
        try {
            Log.d(TAG, "Starting parseSeasons, HTML length: ${html.length}")
            
            // Buscar TODOS los enlaces en el HTML
            val allLinksPattern = Regex("""<a[^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""", RegexOption.IGNORE_CASE)
            val allLinks = allLinksPattern.findAll(html).toList()
            Log.d(TAG, "Found ${allLinks.size} total links in HTML")
            
            // Filtrar enlaces a acortadores, mega.nz, torrent, tinyurl, etc.
            val shortenerLinks = allLinks.filter { match ->
                val url = match.groupValues[1]
                val host = runCatching { URL(url).host.lowercase().removePrefix("www.") }.getOrDefault("")
                KNOWN_SHORTENERS.any { host == it || host.endsWith(".$it") } ||
                url.contains("mega.nz", ignoreCase = true) ||
                url.contains("torrent", ignoreCase = true) ||
                host == "tinyurl.com" ||
                host == "bit.ly" ||
                host == "t.co"
            }
            Log.d(TAG, "Found ${shortenerLinks.size} shortener/mega/torrent links")
            
            var currentSeason = 1
            
            // Buscar encabezados de temporada para establecer contexto
            val seasonHeaderPattern = Regex("""(?:Temporada|Season|T\.?|Temp\.?)\s*(\d+)""", RegexOption.IGNORE_CASE)
            
            for (match in shortenerLinks) {
                val url = match.groupValues[1]
                val linkText = cleanHtml(match.groupValues[2])
                
                // Buscar encabezado de temporada antes de este enlace
                val linkPos = html.indexOf(match.value)

                // Contexto local del enlace. Se calcula siempre porque también se usa
                // después para filtrar enlaces latinos, incluso cuando el episodio se
                // detecta directamente desde el texto del enlace.
                val contextStartAroundLink = maxOf(0, linkPos - 500)
                val contextEndAroundLink = minOf(html.length, linkPos + 500)
                val linkContext = if (linkPos >= 0) {
                    html.substring(contextStartAroundLink, contextEndAroundLink)
                } else {
                    ""
                }
                val localStart = if (linkPos >= 0) {
                    listOf(
                        html.lastIndexOf("<br", linkPos, ignoreCase = true),
                        html.lastIndexOf("<span", linkPos, ignoreCase = true),
                        html.lastIndexOf("</span", linkPos, ignoreCase = true),
                        html.lastIndexOf("<div", linkPos, ignoreCase = true)
                    ).filter { it >= 0 }.maxOrNull() ?: contextStartAroundLink
                } else {
                    0
                }
                val localEnd = if (linkPos >= 0) {
                    listOf(
                        html.indexOf("<br", linkPos + match.value.length, ignoreCase = true),
                        html.indexOf("</span", linkPos + match.value.length, ignoreCase = true),
                        html.indexOf("</div", linkPos + match.value.length, ignoreCase = true)
                    ).filter { it >= 0 }.minOrNull() ?: contextEndAroundLink
                } else {
                    0
                }
                val localContext = if (linkPos >= 0 && localEnd > localStart) {
                    cleanHtml(html.substring(localStart.coerceAtLeast(0), localEnd.coerceAtMost(html.length)))
                } else {
                    linkText
                }

                if (linkPos > 0) {
                    // Buscar en los 3000 caracteres anteriores (aumentado de 2000)
                    val contextStart = maxOf(0, linkPos - 3000)
                    val context = html.substring(contextStart, linkPos)
                    
                    // Buscar el último encabezado de temporada en el contexto
                    val seasonMatches = seasonHeaderPattern.findAll(context).toList()
                    if (seasonMatches.isNotEmpty()) {
                        val lastSeasonMatch = seasonMatches.last()
                        val seasonNum = lastSeasonMatch.groupValues[1].toIntOrNull()
                        if (seasonNum != null && seasonNum > 0) {
                            currentSeason = seasonNum
                        }
                    }
                }
                
                // Extraer número de episodio del texto del enlace
                var episodeNumber = 0
                var seasonFromLink = currentSeason
                
                // PRIORIDAD 1: Formato SxxExx (S01E01, S1E1, etc.) en el TEXTO DEL ENLACE - MÁS CONFIABLE
                val sEpisodePattern = Regex("""S0*(\d+)E0*(\d+)""", RegexOption.IGNORE_CASE)
                val sEpisodeMatch = sEpisodePattern.find(linkText)
                
                // PRIORIDAD 2: Formato 1x01, 01x01, etc. en el TEXTO DEL ENLACE - MÁS CONFIABLE
                val formatPattern = Regex("""0*(\d+)[xX]0*(\d+)""", RegexOption.IGNORE_CASE)
                val formatMatch = formatPattern.find(linkText)
                
                // SI ENCONTRAMOS S10E01 o 10x01 en el TEXTO DEL ENLACE, usar ESA temporada SIEMPRE
                if (sEpisodeMatch != null) {
                    seasonFromLink = sEpisodeMatch.groupValues[1].toIntOrNull() ?: currentSeason
                    episodeNumber = sEpisodeMatch.groupValues[2].toIntOrNull() ?: 0
                    Log.d(TAG, "✓ PRIORITY: Found S${seasonFromLink}E${episodeNumber} in link text: $linkText")
                } else if (formatMatch != null) {
                    seasonFromLink = formatMatch.groupValues[1].toIntOrNull() ?: currentSeason
                    episodeNumber = formatMatch.groupValues[2].toIntOrNull() ?: 0
                    Log.d(TAG, "✓ PRIORITY: Found ${seasonFromLink}x${episodeNumber} in link text: $linkText")
                } else {
                    // Solo si NO hay formato en el texto, buscar en contexto
                    
                    // PRIORIDAD 3: "Episodio X", "Capítulo X", "Ep X", etc.
                    val episodeNumPattern = Regex("""(?:Episodio|Capítulo|Cap\.?|Ep\.?|E|Episode|Chapter)\s*0*(\d+)""", RegexOption.IGNORE_CASE)
                    val episodeNumMatch = episodeNumPattern.find(linkText)
                    
                    // Patrón 4: Solo números si el contexto indica episodio
                    val justNumberPattern = Regex("""\b0*(\d{1,3})\b""")
                    
                    // Patrón 5: Buscar en el contexto HTML alrededor del enlace
                    val contextPattern = Regex("""(?:Episodio|Capítulo|Cap\.?|Ep\.?|E|Episode|Chapter)\s*0*(\d+)""", RegexOption.IGNORE_CASE)
                    val localEpisodeNumMatch = episodeNumPattern.find(localContext)
                    val localSEpisodeMatch = sEpisodePattern.find(localContext)
                    val localFormatMatch = formatPattern.find(localContext)
                    val contextMatch = contextPattern.find(linkContext)
                    val contextSEpisodeMatch = sEpisodePattern.find(linkContext)
                    val contextFormatMatch = formatPattern.find(linkContext)
                    
                    when {
                        localSEpisodeMatch != null -> {
                            // IMPORTANTE: Si encontramos SxxExx en contexto local, USAR ESA TEMPORADA
                            seasonFromLink = localSEpisodeMatch.groupValues[1].toIntOrNull() ?: currentSeason
                            episodeNumber = localSEpisodeMatch.groupValues[2].toIntOrNull() ?: 0
                            Log.d(TAG, "Found S${seasonFromLink}E${episodeNumber} from local context: $linkText")
                        }
                        localFormatMatch != null -> {
                            // IMPORTANTE: Si encontramos XxYY en contexto local, USAR ESA TEMPORADA
                            seasonFromLink = localFormatMatch.groupValues[1].toIntOrNull() ?: currentSeason
                            episodeNumber = localFormatMatch.groupValues[2].toIntOrNull() ?: 0
                            Log.d(TAG, "Found ${seasonFromLink}x${episodeNumber} from local context: $linkText")
                        }
                        localEpisodeNumMatch != null -> {
                            episodeNumber = localEpisodeNumMatch.groupValues[1].toIntOrNull() ?: 0
                            Log.d(TAG, "Found episode $episodeNumber from local context: $linkText")
                        }
                        contextSEpisodeMatch != null -> {
                            // IMPORTANTE: Si encontramos SxxExx en contexto amplio, USAR ESA TEMPORADA
                            seasonFromLink = contextSEpisodeMatch.groupValues[1].toIntOrNull() ?: currentSeason
                            episodeNumber = contextSEpisodeMatch.groupValues[2].toIntOrNull() ?: 0
                            Log.d(TAG, "Found S${seasonFromLink}E${episodeNumber} from context: $linkText")
                        }
                        contextFormatMatch != null -> {
                            // IMPORTANTE: Si encontramos XxYY en contexto amplio, USAR ESA TEMPORADA
                            seasonFromLink = contextFormatMatch.groupValues[1].toIntOrNull() ?: currentSeason
                            episodeNumber = contextFormatMatch.groupValues[2].toIntOrNull() ?: 0
                            Log.d(TAG, "Found ${seasonFromLink}x${episodeNumber} from context: $linkText")
                        }
                        contextMatch != null -> {
                            episodeNumber = contextMatch.groupValues[1].toIntOrNull() ?: 0
                            Log.d(TAG, "Found episode $episodeNumber from context: $linkText")
                        }
                        episodeNumMatch != null -> {
                            episodeNumber = episodeNumMatch.groupValues[1].toIntOrNull() ?: 0
                            Log.d(TAG, "Found episode $episodeNumber from text: $linkText")
                        }
                        else -> {
                            // Intentar extraer número si el texto parece ser de episodio
                            val lowerText = linkText.lowercase()
                            if (lowerText.contains("episodio") || lowerText.contains("capitulo") || 
                                lowerText.contains("cap") || lowerText.contains("ep") ||
                                lowerText.contains("episode") || lowerText.contains("chapter") ||
                                lowerText.matches(Regex("""^\d{1,3}$"""))) {
                                val numMatch = justNumberPattern.find(linkText)
                                episodeNumber = numMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
                                if (episodeNumber > 0) {
                                    Log.d(TAG, "Extracted episode $episodeNumber from context: $linkText")
                                }
                            }
                        }
                    }
                }
                
                // Si encontramos un número de episodio válido, agregarlo
                if (episodeNumber > 0) {
                    // FILTRAR EPISODIOS LATINOS
                    val lowerText = linkText.lowercase() + " " + localContext.lowercase()
                    val isLatino = lowerText.contains("latino") || 
                                   lowerText.contains("latina") || 
                                   lowerText.contains("audio latino") ||
                                   lowerText.contains("lat") && (lowerText.contains("audio") || lowerText.contains("dub"))
                    
                    if (isLatino) {
                        Log.d(TAG, "Skipped LATINO episode S${seasonFromLink}E${episodeNumber}: $linkText")
                        continue
                    }
                    
                    val episode = Episode(
                        number = episodeNumber,
                        title = linkText.ifBlank { "Episodio $episodeNumber" },
                        shortenerLinks = listOf(url)
                    )
                    
                    seasons.getOrPut(seasonFromLink) { mutableListOf() }.add(episode)
                    Log.d(TAG, "Added S${seasonFromLink}E${episodeNumber}: $linkText -> $url")
                } else {
                    Log.d(TAG, "Skipped link (no episode number): $linkText -> $url")
                }
            }
            
            // Si no encontramos episodios estructurados, intentar un enfoque más agresivo
            if (seasons.isEmpty()) {
                Log.d(TAG, "No episodes found with structured approach, trying aggressive parsing")
                
                // Buscar cualquier enlace que tenga números y parezca ser un episodio
                var episodeCounter = 1
                for (match in shortenerLinks) {
                    val url = match.groupValues[1]
                    val linkText = cleanHtml(match.groupValues[2])
                    
                    // Buscar cualquier número en el texto
                    val numbers = Regex("""\d+""").findAll(linkText).map { it.value.toInt() }.toList()
                    
                    if (numbers.isNotEmpty()) {
                        // Asumir que el primer número pequeño (< 100) es el episodio
                        val episodeNum = numbers.firstOrNull { it in 1..99 } ?: episodeCounter
                        
                        seasons.getOrPut(1) { mutableListOf() }.add(
                            Episode(episodeNum, linkText.ifBlank { "Episodio $episodeNum" }, listOf(url))
                        )
                        Log.d(TAG, "Aggressively added episode $episodeNum: $linkText")
                        episodeCounter++
                    } else {
                        // Si no hay números, usar contador secuencial
                        seasons.getOrPut(1) { mutableListOf() }.add(
                            Episode(episodeCounter, linkText.ifBlank { "Episodio $episodeCounter" }, listOf(url))
                        )
                        Log.d(TAG, "Added episode $episodeCounter by sequence: $linkText")
                        episodeCounter++
                    }
                }
            }
            
            // Consolidar episodios duplicados (múltiples enlaces para el mismo episodio)
            val consolidatedSeasons = seasons.map { (seasonNum, episodes) ->
                val episodeMap = mutableMapOf<Int, MutableList<String>>()
                val episodeTitles = mutableMapOf<Int, String>()
                
                for (episode in episodes) {
                    episodeMap.getOrPut(episode.number) { mutableListOf() }
                        .addAll(episode.shortenerLinks)
                    
                    // Guardar el título más descriptivo
                    // PRIORIDAD: Títulos con formato SxxExx o XxYY son más confiables
                    val currentTitle = episodeTitles[episode.number] ?: ""
                    val newTitle = episode.title
                    
                    val currentHasFormat = currentTitle.matches(Regex(""".*[Ss]\d+[Ee]\d+.*""")) || 
                                          currentTitle.matches(Regex("""\d+[xX]\d+"""))
                    val newHasFormat = newTitle.matches(Regex(""".*[Ss]\d+[Ee]\d+.*""")) || 
                                      newTitle.matches(Regex("""\d+[xX]\d+"""))
                    
                    when {
                        // Si el nuevo tiene formato y el actual no, usar el nuevo
                        newHasFormat && !currentHasFormat -> episodeTitles[episode.number] = newTitle
                        // Si ambos tienen formato o ninguno tiene, usar el más largo
                        newHasFormat == currentHasFormat && newTitle.length > currentTitle.length -> 
                            episodeTitles[episode.number] = newTitle
                        // Si el actual tiene formato y el nuevo no, mantener el actual
                        currentHasFormat && !newHasFormat -> {} // No hacer nada
                        // Si no hay título actual, usar el nuevo
                        currentTitle.isEmpty() -> episodeTitles[episode.number] = newTitle
                    }
                }
                
                val consolidatedEpisodes = episodeMap.map { (num, links) ->
                    Episode(
                        number = num,
                        title = episodeTitles[num] ?: "Episodio $num",
                        shortenerLinks = links.distinct()
                    )
                }.sortedBy { it.number }
                
                Season(number = seasonNum, episodes = consolidatedEpisodes)
            }.sortedBy { it.number }
            
            val totalEpisodes = consolidatedSeasons.sumOf { it.episodes.size }
            val totalLinks = consolidatedSeasons.sumOf { season -> 
                season.episodes.sumOf { it.shortenerLinks.size } 
            }
            Log.d(TAG, "Parsed ${consolidatedSeasons.size} seasons with $totalEpisodes episodes ($totalLinks total links)")
            
            // Log detallado de cada temporada
            consolidatedSeasons.forEach { season ->
                Log.d(TAG, "Season ${season.number}: ${season.episodes.size} episodes")
                season.episodes.take(3).forEach { ep ->
                    Log.d(TAG, "  - E${ep.number}: ${ep.title} (${ep.shortenerLinks.size} links)")
                }
                if (season.episodes.size > 3) {
                    Log.d(TAG, "  ... and ${season.episodes.size - 3} more episodes")
                }
            }
            
            return consolidatedSeasons
            
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing seasons: ${e.message}", e)
            return emptyList()
        }
    }
    
    /**
     * Limpia el HTML de etiquetas y entidades.
     */
    private fun normalizeSeriesUrl(url: String): String =
        url.trim()
            .replace("hhttps://", "https://")
            .replace("http://", "https://", ignoreCase = true)
            .replace("&amp;", "&")

    private fun isSeriesPostUrl(url: String): Boolean {
        return try {
            val parsed = URL(url)
            val host = parsed.host.lowercase().removePrefix("www.")
            val path = parsed.path.orEmpty()
            host.endsWith(".blogspot.com") &&
                path.endsWith(".html", ignoreCase = true) &&
                !path.startsWith("/p/", ignoreCase = true) &&
                !path.startsWith("/search", ignoreCase = true) &&
                !path.startsWith("/feeds", ignoreCase = true)
        } catch (_: Throwable) {
            false
        }
    }

    private fun isCastellanoSeriesEntry(title: String, url: String): Boolean {
        val normalized = languageComparable("$title $url")
        val latinoHints = listOf(
            "latino",
            "latina",
            "espanol latino",
            "audio latino",
            "es 419",
            "es mx",
            "es ar",
            "es co",
            "es cl",
            "es pe",
            "es ve"
        )
        if (latinoHints.any { normalized.contains(it) }) return false

        val spainHints = listOf(
            "castellano",
            "espanol de espana",
            "espana",
            "spanish spain",
            "castilian",
            "es es"
        )
        return spainHints.any { normalized.contains(it) }
    }

    private fun languageComparable(value: String): String =
        value.lowercase()
            .replace("á", "a")
            .replace("é", "e")
            .replace("í", "i")
            .replace("ó", "o")
            .replace("ú", "u")
            .replace("ü", "u")
            .replace("ñ", "n")
            .replace(Regex("""[^a-z0-9]+"""), " ")
            .trim()

    private fun titleFromSeriesUrl(url: String): String {
        val slug = try {
            URL(url).path.trim('/').substringAfterLast('/').substringBeforeLast(".html")
        } catch (_: Throwable) {
            url.substringAfterLast('/').substringBefore('?')
        }
        var clean = try {
            URLDecoder.decode(slug, "UTF-8")
        } catch (_: Throwable) {
            slug
        }
            .replace(Regex("""[-_]+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        listOf("serie completa", "latino", "castellano", "espanol", "español").forEach { suffix ->
            clean = clean.replace(Regex("""\b${Regex.escape(suffix)}\b""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }
        return clean.split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word -> word.lowercase().replaceFirstChar { first -> first.titlecase() } }
    }

    private fun cleanHtml(html: String): String {
        val stripped = html
            .replace(Regex("""<[^>]+>"""), "") // Eliminar etiquetas HTML
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("""\s+"""), " ") // Normalizar espacios
            .trim()
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            android.text.Html.fromHtml(stripped, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            @Suppress("DEPRECATION")
            android.text.Html.fromHtml(stripped).toString()
        }.replace(Regex("""\s+"""), " ").trim()
    }
    
    private fun fetchHtml(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
        }
        
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        
        if (code !in 200..299) {
            throw Exception("HTTP $code")
        }
        
        return body
    }
}
