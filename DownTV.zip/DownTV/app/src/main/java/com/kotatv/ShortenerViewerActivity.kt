package com.kotatv

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/**
 * Visor especializado para acortadores de enlaces con bloqueo agresivo de ads.
 * Muestra solo el contenido relevante en un cuadrado 1:1.
 */
class ShortenerViewerActivity : ComponentActivity() {
    
    private lateinit var rootView: FrameLayout
    private var webView: WebView? = null
    private var progressBar: ProgressBar? = null
    private var statusText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    
    private var targetUrl: String = ""
    private var seasonNumber: Int = 0
    private var episodeNumber: Int = 0
    
    companion object {
        private const val TAG = "ShortenerViewer"
        const val EXTRA_URL = "url"
        const val EXTRA_SEASON = "season"
        const val EXTRA_EPISODE = "episode"

        private val CORE_SHORTENER_DOMAINS = setOf(
            "ouo.io", "ouo.press", "ouoio.com", "ouo.si",
            "adshort.co", "cpmlink.net",
            "shrinkme.io", "shorte.st", "adf.ly", "linkvertise.com",
            "exe.io", "bc.vc", "fc.lc", "cuty.io", "shrinkearn.com",
            "earnviral.com", "gplinks.co", "oke.io", "za.gl", "du-link.in",
            "link1s.com", "short.pe", "clk.sh", "tinyurl.com", "bit.ly",
            "t.co", "gg.gg", "is.gd", "rebrand.ly", "tiny.cc",
            "shon.xyz", "adbull.org"
        )
        
        // Lista exhaustiva de dominios de publicidad y rastreadores
        private val SUPPORT_RESOURCE_DOMAINS = setOf(
            "challenges.cloudflare.com", "cloudflare.com", "google.com", "gstatic.com",
            "recaptcha.net", "hcaptcha.com", "jsdelivr.net", "unpkg.com",
            "cdnjs.cloudflare.com", "cloudflareinsights.com", "bootstrapcdn.com",
            "jquery.com", "googleapis.com"
        )

        private val AD_DOMAINS = setOf(
            // Redes publicitarias principales
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "googletagmanager.com", "adservice.google.com",
            
            // Redes de anuncios comunes
            "adsterra.com", "exoclick.com", "popads.net", "popcash.net",
            "propellerads.com", "mgid.com", "taboola.com", "outbrain.com",
            "revcontent.com", "contentad.net", "adnium.com", "hilltopads.com",
            "trafficjunky.com", "juicyads.com", "plugrush.com", "clickadu.com",
            "adcash.com", "zeropark.com", "pushground.com", "richpush.co",
            "evadav.com", "adpushup.com", "monetag.com", "trafficstars.com",
            "ad-maven.com", "ad-maven.co", "yllix.com", "onclickalgo.com",
            "onclickperformance.com", "popmonetizer.com", "adnami.io",
            "highperformanceformat.com", "highperformancecpm.com",
            "profitableratecpm.com", "smartlink.name", "histats.com",
            
            // Rastreadores y analytics
            "hotjar.com", "clarity.ms", "facebook.net", "connect.facebook.net",
            "analytics.tiktok.com", "onesignal.com",
            
            // CDNs de anuncios
            "cdn4ads.com", "synedawtit.com", "sfbyctnfokzd.com", "rxqtuwahzmb.com",
            "fuckingfast.co", "oclasrv.com", "galaksion.com",
            
            // Más redes
            "adnxs.com", "rubiconproject.com", "openx.net", "spotxchange.com",
            "springserve.com", "adform.net", "smartadserver.com", "pubmatic.com",
            "appnexus.com", "lkqd.net", "lijit.com", "sovrn.com", "sharethrough.com",
            "triplelift.com", "criteo.com", "criteo.net", "amazon-adsystem.com",
            "media.net", "vidazoo.com", "undertone.com", "yieldmo.com",
            
            // Apuestas y casinos (común en acortadores)
            "1xbet.com", "1xbet.mobi", "1xbet.tv", "xbet.com",

            // Tiendas/landing pages ajenas que suelen aparecer como publicidad en shon.xyz
            "aliexpress.com", "aliexpress.us", "aliexpress.ru", "alicdn.com",
            "alibaba.com", "temu.com", "shein.com", "wish.com", "banggood.com",
            "dhgate.com", "gearbest.com", "joom.com", "miravia.es",
            
            // Minería de criptomonedas
            "coinzilla.io", "a-ads.com", "adbtc.top", "cpx.to", "cryptominer.com"
        )
        
        private val AD_URL_PATTERNS = listOf(
            "/ads/", "/adserver", "/advert", "/banner", "/prebid", "/vast", "/vpaid",
            "/popunder", "/popup", "runpop", "zoneid=", "/push/", "/notification",
            "/tracker", "/tracking", "/analytics", "/metrics", "/telemetry",
            "/collector", "/fingerprint", "gclid=", "fbclid=", "msclkid=",
            "aff_id=", "affiliate=", "adtag=", "adunit=", "/ima/", "/adsense/",
            "/pagead/", "/adx/", "prebid.js", "/preroll", "/midroll", "/postroll",
            "/vast.xml", "ad_type=", "ad_unit=", "adzone=", "adslot=",
            
            // Específicos de acortadores
            "/go.php", "/go?", "/click?", "/redirect?", "/r.php", "/out.php",
            "/aff.php", "/track.php", "/count.php", "/stat.php"
        )
    }

    private data class ShortenerInspection(
        val megaUrl: String? = null,
        val nextUrl: String? = null,
        val cloudflareChallenge: Boolean = false
    )

    private data class ShortenerHtmlResponse(
        val url: String,
        val html: String,
        val redirectUrl: String? = null
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.keepScreenOn = true
        
        targetUrl = intent.getStringExtra(EXTRA_URL) ?: ""
        seasonNumber = intent.getIntExtra(EXTRA_SEASON, 0)
        episodeNumber = intent.getIntExtra(EXTRA_EPISODE, 0)
        
        if (targetUrl.isEmpty()) {
            finish()
            return
        }
        
        setupUI()
        loadUrlAfterHtmlInspection(targetUrl)
        
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView?.canGoBack() == true) {
                    webView?.goBack()
                } else {
                    finish()
                }
            }
        })
    }
    
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupUI() {
        rootView = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        setContentView(rootView)

        val sbHeight = statusBarHeight()
        val navBarHeight = navigationBarHeight()
        
        // Título con temporada y episodio
        val titleText = TextView(this).apply {
            text = "Temporada $seasonNumber Episodio $episodeNumber"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFF1A1A1A.toInt())
        }

        // Opción visible para que el usuario pueda abrir el acortador original
        // en su navegador predeterminado, sin sacar el WebView del cuadro amarillo.
        val openShortenerButton = Button(this).apply {
            text = "Abrir acortador en navegador"
            textSize = 12f
            isAllCaps = false
            setOnClickListener { openOriginalShortenerInDefaultBrowser() }
        }
        
        // Contenedor con borde amarillo oscuro para el WebView
        val webViewContainer = FrameLayout(this).apply {
            setBackgroundColor(0xFFB8860B.toInt()) // Dark yellow/goldenrod border
            setPadding(dp(4), dp(4), dp(4), dp(4)) // 4dp border width
        }
        
        // WebView en formato cuadrado 1:1
        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_NO_CACHE
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                // User-Agent más realista para evitar detección de WebView
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                
                // Deshabilitar características que pueden mostrar ads
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
                allowFileAccess = false
                allowContentAccess = false
                
                // Habilitar zoom siempre
                builtInZoomControls = true
                displayZoomControls = false
                setSupportZoom(true)
                
                // Configuraciones adicionales para parecer un navegador real
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                
                // Habilitar características modernas
                setGeolocationEnabled(false)
                databaseEnabled = true
                domStorageEnabled = true
            }
            
            setBackgroundColor(Color.WHITE)
            
            webViewClient = createWebViewClient()
            webChromeClient = createWebChromeClient()
        }
        
        // Barra de progreso
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
        }
        
        // Texto de estado
        statusText = TextView(this).apply {
            text = "Cargando..."
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(0xFF1A1A1A.toInt())
        }
        
        // Layout
        rootView.addView(titleText, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            topMargin = sbHeight
        })

        rootView.addView(openShortenerButton, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            dp(38),
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply {
            topMargin = sbHeight + dp(52)
        })
        
        // Calcular tamaño cuadrado 1:1 basado en la dimensión más pequeña de la pantalla
        // Esto asegura que el cuadrado se mantenga 1:1 incluso en orientación horizontal
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val titleHeight = dp(96) + sbHeight // Título + botón para abrir el acortador en navegador
        val statusHeight = dp(44) + navBarHeight // Aproximado para barra de progreso y estado + barra de navegación
        val availableHeight = screenHeight - titleHeight - statusHeight
        
        // Usar la dimensión más pequeña para garantizar que el cuadrado quepa en pantalla
        val maxSquareSize = minOf(screenWidth, availableHeight)
        val squareSize = (maxSquareSize * 0.90).toInt() // 90% de la dimensión disponible
        
        // Agregar WebView dentro del contenedor con borde
        webViewContainer.addView(webView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        
        rootView.addView(webViewContainer, FrameLayout.LayoutParams(
            squareSize,
            squareSize,
            Gravity.CENTER
        ))
        
        rootView.addView(progressBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            dp(4),
            Gravity.BOTTOM
        ).apply {
            bottomMargin = dp(40) + navBarHeight
        })
        
        rootView.addView(statusText, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ).apply {
            bottomMargin = navBarHeight
        })
    }
    
    private fun createWebViewClient(): WebViewClient {
        return object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                val host = request.url.host?.lowercase() ?: ""

                val isMegaResource = url.contains("mega.nz", ignoreCase = true) ||
                    url.contains("mega.co.nz", ignoreCase = true)

                // Mantener bloqueada la publicidad, pero sin romper los recursos necesarios
                // del propio acortador, Cloudflare, reCAPTCHA/hCaptcha y CDNs habituales.
                if (isCoreShortenerHost(host) || isMegaResource || isAllowedShortenerSupportHost(host)) {
                    return null
                }

                if (isAdRequest(host, url)) {
                    Log.d(TAG, "Blocked ad/resource request: $url")
                    return emptyResponse()
                }

                // En acortadores modernos, bloquear todos los recursos externos deja muchas
                // páginas en blanco. Permitimos el frame principal y bloqueamos el resto.
                if (request.isForMainFrame && isAllowedShortenerNavigationHost(host, url)) {
                    return null
                }

                Log.d(TAG, "Blocked non-essential shortener resource: $url")
                return emptyResponse()
            }
            
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                val host = request.url.host?.lowercase() ?: ""
                
                // Si es un enlace a Mega, abrirlo
                val directMegaUrl = megaUrlFromNavigation(url)
                if (directMegaUrl != null) {
                    openMegaLink(directMegaUrl)
                    return true
                }
                
                // Bloquear esquemas peligrosos
                val scheme = request.url.scheme?.lowercase() ?: ""
                if (scheme !in setOf("http", "https", "about", "data")) {
                    Log.d(TAG, "Blocked scheme: $scheme")
                    return true
                }

                // Permitir primero la navegación dentro del propio acortador. Muchos
                // acortadores usan rutas tipo /go, /redirect o /out como pasos reales.
                if (isCoreShortenerHost(host)) {
                    return false
                }

                if (request.isForMainFrame && isAllowedShortenerNavigationHost(host, url)) {
                    Log.d(TAG, "Allowing shortener navigation: $url")
                    return false
                }

                // Bloquear dominios de publicidad después de salvar los pasos legítimos.
                if (isAdRequest(host, url)) {
                    Log.d(TAG, "Blocked navigation to ad domain: $host")
                    return true
                }

                if (request.isForMainFrame) {
                    Log.d(TAG, "Blocked shortener popup/navigation: $url")
                    return true
                }
                
                return false
            }
            
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                progressBar?.visibility = View.VISIBLE
                statusText?.text = "Cargando..."
            }
            
            override fun onPageFinished(view: WebView, url: String) {
                progressBar?.visibility = View.GONE
                statusText?.text = "Temporada $seasonNumber Episodio $episodeNumber"
                
                // Inyectar JavaScript para bloquear popups y limpiar la página
                injectAdBlockerScript(view)
                
                // Inyectar script específico para simular comportamiento humano
                injectHumanBehaviorScript(view)
            }
            
            override fun onReceivedSslError(
                view: WebView,
                handler: SslErrorHandler,
                error: SslError
            ) {
                handler.proceed()
            }
            
            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    statusText?.text = "Error al cargar"
                }
            }
        }
    }

    private fun isCoreShortenerHost(host: String): Boolean {
        val clean = host.lowercase().removePrefix("www.")
        return CORE_SHORTENER_DOMAINS.any { clean == it || clean.endsWith(".$it") }
    }

    private fun megaUrlFromNavigation(url: String): String? {
        if (url.contains("mega.nz", ignoreCase = true) || url.contains("mega.co.nz", ignoreCase = true)) {
            return extractMegaUrl(url) ?: url
        }
        val decoded = runCatching { URLDecoder.decode(url, "UTF-8") }.getOrDefault(url)
        return extractMegaUrl(decoded)
    }

    private fun loadUrlAfterHtmlInspection(url: String) {
        statusText?.text = "Leyendo HTML del acortador..."
        Thread {
            val inspection = runCatching { inspectShortenerHtml(url) }
                .onFailure { 
                    Log.w(TAG, "Shortener HTML inspection failed: ${it.message}")
                    it.printStackTrace()
                }
                .getOrDefault(ShortenerInspection())
            handler.post {
                if (webView == null) return@post
                when {
                    inspection.megaUrl != null -> {
                        statusText?.text = "✓ Enlace de Mega encontrado"
                        Log.d(TAG, "Opening Mega link from inspection: ${inspection.megaUrl}")
                        openMegaLink(inspection.megaUrl)
                    }
                    else -> {
                        // NO SE ENCONTRÓ MEGA, cargar en WebView con bloqueo agresivo
                        statusText?.text = "Cargando acortador..."
                        Log.d(TAG, "No Mega found in HTML, loading in WebView: $url")
                        loadUrl(url)
                    }
                }
            }
        }.start()
    }

    private fun inspectShortenerHtml(url: String): ShortenerInspection {
        var currentUrl = url
        var hops = 0
        val seenUrls = mutableSetOf<String>()
        
        while (hops < 10) {  // Aumentado a 10 intentos
            hops++
            if (currentUrl in seenUrls) {
                Log.d(TAG, "Circular redirect detected, stopping inspection")
                break
            }
            seenUrls.add(currentUrl)
            
            Log.d(TAG, "Inspecting shortener HTML (hop $hops): $currentUrl")
            val response = downloadShortenerHtml(currentUrl)
            val redirect = response.redirectUrl
            if (!redirect.isNullOrBlank()) {
                Log.d(TAG, "Found HTTP redirect: $redirect")
                val directMega = megaUrlFromNavigation(redirect)
                if (directMega != null) {
                    Log.d(TAG, "✓ Mega URL found in redirect: $directMega")
                    return ShortenerInspection(megaUrl = directMega)
                }
                if (isSafeNavigationUrl(redirect)) {
                    currentUrl = redirect
                    continue
                }
                Log.d(TAG, "Blocked unsafe redirect from shortener HTML: $redirect")
                return ShortenerInspection()
            }

            val html = response.html
            if (html.isBlank()) {
                Log.d(TAG, "Empty HTML response")
                return ShortenerInspection()
            }
            
            Log.d(TAG, "HTML size: ${html.length} bytes")
            
            val normalizedHtml = html
                .replace("\\/", "/")
                .replace("&amp;", "&")
                .replace("&#39;", "'")
                .replace("&quot;", "\"")
                .replace("\\u002F", "/")
                .replace("\\x2F", "/")
                .replace("\\\\", "")

            // ESPECÍFICO PARA OUO.IO: Buscar en el formulario de redirección
            if (currentUrl.contains("ouo.io", ignoreCase = true) || 
                currentUrl.contains("ouo.press", ignoreCase = true) ||
                currentUrl.contains("ouoio.com", ignoreCase = true) ||
                currentUrl.contains("ouo.si", ignoreCase = true)) {
                Log.d(TAG, "Detected ouo.io shortener, searching for form redirect...")
                
                // OUO.IO REQUIERE INTERACCIÓN HUMANA - NO PODEMOS EXTRAER EL ENLACE
                // Buscar en formularios con action
                val formPattern = Regex("""<form[^>]+action\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
                val formMatch = formPattern.find(normalizedHtml)
                if (formMatch != null) {
                    val formUrl = formMatch.groupValues[1]
                    Log.d(TAG, "✓ Found Mega URL in ouo.io form action: $formUrl")
                    return ShortenerInspection(megaUrl = formUrl)
                }
                
                // Buscar en el botón de "Get Link" o similar
                val buttonPattern = Regex("""(?:data-target|data-url|data-href|href)\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
                val buttonMatch = buttonPattern.find(normalizedHtml)
                if (buttonMatch != null) {
                    val buttonUrl = buttonMatch.groupValues[1]
                    Log.d(TAG, "✓ Found Mega URL in ouo.io button: $buttonUrl")
                    return ShortenerInspection(megaUrl = buttonUrl)
                }
                
                // Buscar en scripts de ouo.io
                val ouoScriptPattern = Regex("""['"]?(https?://(?:www\.)?mega(?:\.co)?\.nz/[^"'\s<>\\)}\]]+)['"]?""", RegexOption.IGNORE_CASE)
                val ouoScriptMatch = ouoScriptPattern.find(normalizedHtml)
                if (ouoScriptMatch != null) {
                    val scriptUrl = ouoScriptMatch.groupValues[1]
                        .trimEnd('\\', ';', ')', ']', '}', '"', '\'', ',', '.')
                    if (scriptUrl.contains("mega", ignoreCase = true) && scriptUrl.contains("nz", ignoreCase = true)) {
                        Log.d(TAG, "✓ Found Mega URL in ouo.io script: $scriptUrl")
                        return ShortenerInspection(megaUrl = scriptUrl)
                    }
                }
                
                // Si no encontramos nada, ouo.io necesita WebView con interacción
                Log.d(TAG, "⚠ ouo.io: No Mega URL found in HTML, requires WebView interaction")
            }
            
            // ESPECÍFICO PARA SHON.XYZ: Buscar en inputs hidden y scripts
            if (currentUrl.contains("shon.xyz", ignoreCase = true)) {
                Log.d(TAG, "Detected shon.xyz shortener, searching for hidden inputs...")
                
                // Buscar CUALQUIER mención de mega.nz en el HTML (más agresivo)
                val anyMegaPattern = Regex("""(https?://(?:www\.)?mega(?:\.co)?\.nz/[^\s"'<>)}\]\\]+)""", RegexOption.IGNORE_CASE)
                val allMegaMatches = anyMegaPattern.findAll(normalizedHtml).toList()
                if (allMegaMatches.isNotEmpty()) {
                    // Tomar el primer enlace válido
                    for (match in allMegaMatches) {
                        val megaUrl = match.groupValues[1]
                            .trimEnd('\\', ';', ')', ']', '}', '"', '\'', ',', '.')
                            .replace("\\/", "/")
                        if (megaUrl.startsWith("http") && megaUrl.contains("/file/") || megaUrl.contains("/folder/") || megaUrl.contains("/#")) {
                            Log.d(TAG, "✓ Found Mega URL in shon.xyz HTML: $megaUrl")
                            return ShortenerInspection(megaUrl = megaUrl)
                        }
                    }
                }
                
                // Buscar en inputs hidden
                val inputPattern = Regex("""<input[^>]+value\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
                val inputMatch = inputPattern.find(normalizedHtml)
                if (inputMatch != null) {
                    val inputUrl = inputMatch.groupValues[1]
                    Log.d(TAG, "✓ Found Mega URL in shon.xyz hidden input: $inputUrl")
                    return ShortenerInspection(megaUrl = inputUrl)
                }
                
                // Buscar en variables JavaScript específicas de shon.xyz
                val shonJsPattern = Regex("""(?:var|let|const)\s+(?:url|link|target|destination|finalUrl|redirectUrl)\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
                val shonJsMatch = shonJsPattern.find(normalizedHtml)
                if (shonJsMatch != null) {
                    val jsUrl = shonJsMatch.groupValues[1]
                    Log.d(TAG, "✓ Found Mega URL in shon.xyz JS variable: $jsUrl")
                    return ShortenerInspection(megaUrl = jsUrl)
                }
                
                // Buscar en window.location o document.location
                val locationPattern = Regex("""(?:window|document)\.location(?:\.href)?\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
                val locationMatch = locationPattern.find(normalizedHtml)
                if (locationMatch != null) {
                    val locUrl = locationMatch.groupValues[1]
                    Log.d(TAG, "✓ Found Mega URL in shon.xyz location: $locUrl")
                    return ShortenerInspection(megaUrl = locUrl)
                }
                
                Log.d(TAG, "⚠ shon.xyz: No Mega URL found in HTML, will load WebView")
            }

            // Buscar enlaces de Mega con TODOS los patrones posibles
            val megaUrl = extractMegaUrl(normalizedHtml)
            if (megaUrl != null) {
                Log.d(TAG, "✓✓ Mega URL found in HTML: $megaUrl")
                return ShortenerInspection(megaUrl = megaUrl)
            }

            // Buscar en atributos data-* y otros lugares donde pueden estar ocultos
            val dataUrlPattern = Regex("""data-(?:url|href|target|link)=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            val dataUrlMatch = dataUrlPattern.find(normalizedHtml)
            if (dataUrlMatch != null) {
                val dataUrl = dataUrlMatch.groupValues[1]
                Log.d(TAG, "Found data-url attribute: $dataUrl")
                val dataMega = extractMegaUrl(dataUrl)
                if (dataMega != null) {
                    Log.d(TAG, "✓ Mega URL found in data-url: $dataMega")
                    return ShortenerInspection(megaUrl = dataMega)
                }
            }
            
            // Buscar en variables JavaScript (más patrones)
            val jsVarPattern = Regex("""(?:var|let|const)\s+\w+\s*=\s*["']([^"']*mega[^"']*)["']""", RegexOption.IGNORE_CASE)
            val jsVarMatch = jsVarPattern.find(normalizedHtml)
            if (jsVarMatch != null) {
                val jsUrl = jsVarMatch.groupValues[1]
                Log.d(TAG, "Found JS variable with mega: $jsUrl")
                val jsMega = extractMegaUrl(jsUrl)
                if (jsMega != null) {
                    Log.d(TAG, "✓ Mega URL found in JS variable: $jsMega")
                    return ShortenerInspection(megaUrl = jsMega)
                }
            }

            val nextUrl = extractSafeRedirect(normalizedHtml, currentUrl)
            if (nextUrl != null && nextUrl != currentUrl) {
                Log.d(TAG, "Found meta/JS redirect: $nextUrl")
                currentUrl = nextUrl
                continue
            }
            
            Log.d(TAG, "No Mega URL or redirect found in HTML")
            return ShortenerInspection(nextUrl = null, cloudflareChallenge = false)
        }
        Log.d(TAG, "Max hops reached without finding Mega URL")
        return ShortenerInspection()
    }

    private fun downloadShortenerHtml(url: String): ShortenerHtmlResponse {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            instanceFollowRedirects = false
            // User-Agent más realista para evitar detección
            setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
            setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
            setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("Upgrade-Insecure-Requests", "1")
            setRequestProperty("Sec-Fetch-Dest", "document")
            setRequestProperty("Sec-Fetch-Mode", "navigate")
            setRequestProperty("Sec-Fetch-Site", "none")
            setRequestProperty("Sec-Fetch-User", "?1")
            setRequestProperty("Cache-Control", "max-age=0")
        }
        return try {
            val code = conn.responseCode
            if (code in 300..399) {
                val redirect = conn.getHeaderField("Location")?.let { resolveHtmlUrl(url, it) }
                ShortenerHtmlResponse(url = url, html = "", redirectUrl = redirect)
            } else {
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                ShortenerHtmlResponse(url = url, html = stream?.bufferedReader()?.use { it.readText() }.orEmpty())
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun extractMegaUrl(html: String): String? {
        // Buscar enlaces de Mega con múltiples patrones
        val patterns = listOf(
            // Patrones estándar de Mega (más específicos primero)
            Regex("""(https?://(?:www\.)?mega(?:\.co)?\.nz/(?:file|folder)/[A-Za-z0-9_-]+(?:#[A-Za-z0-9_-]+(?:/(?:file|folder)/[A-Za-z0-9_-]+)*)?)""", RegexOption.IGNORE_CASE),
            Regex("""(https?://(?:www\.)?mega(?:\.co)?\.nz/[#!][A-Za-z0-9_!-]+)""", RegexOption.IGNORE_CASE),
            Regex("""(mega://[A-Za-z0-9_#!/-]+)""", RegexOption.IGNORE_CASE),
            
            // Patrones más generales
            Regex("""(https?://(?:www\.)?mega(?:\.co)?\.nz/[^\s"'<>\\)}\]]+)""", RegexOption.IGNORE_CASE),
            
            // Patrones específicos para ouo.io - buscar en variables JavaScript
            Regex("""['"]?(https?://(?:www\.)?mega(?:\.co)?\.nz/[^"'\s<>\\)}\]]+)['"]?""", RegexOption.IGNORE_CASE),
            
            // Buscar en atributos href codificados
            Regex("""href\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE),
            
            // Buscar en valores de input hidden (común en shon.xyz)
            Regex("""<input[^>]+value\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE),
            
            // Buscar en data attributes
            Regex("""data-[^=]*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE),
            
            // Buscar en window.location o document.location
            Regex("""(?:window|document)\.location(?:\.href)?\s*=\s*['"]([^'"]*mega[^'"]*nz[^'"]*)['"]""", RegexOption.IGNORE_CASE)
        )
        
        for (pattern in patterns) {
            val match = pattern.find(html)
            if (match != null) {
                val url = match.groupValues.getOrNull(1) ?: match.value
                val cleaned = url
                    .trimEnd('\\', ';', ')', ']', '}', '"', '\'', ',', '.', '?', '&')
                    .replace("\\/", "/")
                    .replace("\\u002F", "/")
                    .replace("\\x2F", "/")
                    .replace("\\\\", "")
                    .trim()
                
                // Validar que sea una URL de Mega válida
                if (cleaned.contains("mega", ignoreCase = true) && 
                    cleaned.contains("nz", ignoreCase = true) &&
                    (cleaned.startsWith("http://") || cleaned.startsWith("https://") || cleaned.startsWith("mega://"))) {
                    
                    // Validar que tenga un formato válido de Mega
                    val hasFolderOrFile = cleaned.contains("/file/", ignoreCase = true) || 
                                          cleaned.contains("/folder/", ignoreCase = true) ||
                                          cleaned.contains("/#", ignoreCase = false) ||
                                          cleaned.contains("/!", ignoreCase = false)
                    
                    if (hasFolderOrFile) {
                        Log.d(TAG, "Valid Mega URL found in HTML: $cleaned")
                        return cleaned
                    }
                }
            }
        }
        return null
    }

    private fun extractSafeRedirect(html: String, baseUrl: String): String? {
        val candidates = listOfNotNull(
            // Meta refresh
            Regex("""(?is)<meta[^>]+http-equiv=["']?refresh["']?[^>]+content=["'][^"']*url=([^"'>\s]+)""")
                .find(html)
                ?.groupValues
                ?.getOrNull(1),
            // window.location
            Regex("""(?is)(?:window\.)?location(?:\.href)?\s*=\s*["']([^"']+)["']""")
                .find(html)
                ?.groupValues
                ?.getOrNull(1),
            // Formularios de redirección automática
            Regex("""<form[^>]+action=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1),
            // Enlaces ocultos con data-url
            Regex("""data-url=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1),
            // Botones de continuar con onclick
            Regex("""onclick=["'](?:window\.)?location(?:\.href)?\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .find(html)
                ?.groupValues
                ?.getOrNull(1)
        )
        return candidates
            .mapNotNull { resolveHtmlUrl(baseUrl, it) }
            .firstOrNull { isSafeNavigationUrl(it) }
    }

    private fun resolveHtmlUrl(baseUrl: String, target: String): String? {
        val decoded = target
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&quot;", "\"")
            .trim()
        return runCatching { URL(URL(baseUrl), decoded).toString() }.getOrNull()
    }

    private fun isSafeNavigationUrl(url: String): Boolean {
        val parsed = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val scheme = parsed.scheme?.lowercase() ?: return false
        if (scheme !in setOf("http", "https")) return false
        val host = parsed.host?.lowercase().orEmpty()
        // Permitir navegación a acortadores conocidos o enlaces de Mega antes de
        // aplicar patrones genéricos como /go o /redirect.
        if (isCoreShortenerHost(host) ||
            url.contains("mega.nz", ignoreCase = true) ||
            url.contains("mega.co.nz", ignoreCase = true) ||
            isAllowedShortenerSupportHost(host)) return true
        if (isAdRequest(host, url)) return false
        return false
    }

    private fun isAllowedShortenerNavigationHost(host: String, url: String): Boolean {
        val cleanHost = host.lowercase().removePrefix("www.")
        if (isCoreShortenerHost(cleanHost)) return true
        if (url.contains("mega.nz", ignoreCase = true) || url.contains("mega.co.nz", ignoreCase = true)) return true
        return isAllowedShortenerSupportHost(cleanHost)
    }

    private fun isAllowedShortenerSupportHost(host: String): Boolean {
        val cleanHost = host.lowercase().removePrefix("www.")
        return SUPPORT_RESOURCE_DOMAINS.any { cleanHost == it || cleanHost.endsWith(".$it") }
    }

    private fun isAdRequest(host: String, url: String): Boolean {
        val cleanHost = host.lowercase().removePrefix("www.")
        return AD_DOMAINS.any { cleanHost == it || cleanHost.endsWith(".$it") || cleanHost.contains(it) } ||
            AD_URL_PATTERNS.any { url.contains(it, ignoreCase = true) }
    }
    
    private fun createWebChromeClient(): WebChromeClient {
        return object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar?.progress = newProgress
            }
            
            override fun onJsAlert(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                // Bloquear alerts de publicidad
                result.cancel()
                return true
            }
            
            override fun onJsConfirm(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                // Bloquear confirms de publicidad
                result.cancel()
                return true
            }

            override fun onJsBeforeUnload(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                result.confirm()
                return true
            }
            
            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                // Bloquear ventanas emergentes
                return false
            }
        }
    }
    
    private fun injectAdBlockerScript(view: WebView) {
        val script = """
            (function() {
                if (window.__downTvShortenerCleaned) return;
                window.__downTvShortenerCleaned = true;
                console.log('[DownTV] Shortener cleaner script injected');
                
                // Bloquear TODOS los popups y ventanas emergentes
                window.open = function() { console.log('[DownTV] Blocked window.open'); return null; };
                
                // Bloquear TODOS los alerts, confirms y prompts
                window.alert = function() { console.log('[DownTV] Blocked alert'); return; };
                window.confirm = function() { console.log('[DownTV] Blocked confirm'); return false; };
                window.prompt = function() { console.log('[DownTV] Blocked prompt'); return null; };

                const currentHost = window.location.hostname.toLowerCase().replace(/^www\./, '');
                const isOuo = currentHost.includes('ouo.io') || currentHost.includes('ouo.press') || 
                              currentHost.includes('ouoio.com') || currentHost.includes('ouo.si');
                const isShon = currentHost.includes('shon.xyz');
                
                console.log('[DownTV] Current host:', currentHost, 'isOuo:', isOuo, 'isShon:', isShon);

                // ELIMINAR MENSAJE DE EXTENSIÓN DE NAVEGADOR (OUO.IO)
                function removeExtensionWarning() {
                    const selectors = [
                        '[class*="extension"]', '[id*="extension"]',
                        '[class*="browser"]', '[id*="browser"]',
                        '[class*="warning"]', '[id*="warning"]',
                        '[class*="alert"]', '[id*="alert"]',
                        '[class*="notice"]', '[id*="notice"]',
                        '.modal', '.overlay', '[class*="popup"]', '[id*="popup"]'
                    ];
                    
                    selectors.forEach(function(sel) {
                        try {
                            document.querySelectorAll(sel).forEach(function(el) {
                                const text = (el.textContent || '').toLowerCase();
                                if (text.includes('extension') || text.includes('browser') || 
                                    text.includes('extensión') || text.includes('navegador') ||
                                    text.includes('install') || text.includes('instalar') ||
                                    text.includes('download') && text.includes('extension')) {
                                    console.log('[DownTV] Removing extension warning:', el);
                                    el.remove();
                                }
                            });
                        } catch(e) {}
                    });
                    
                    // Eliminar overlays oscuros
                    document.querySelectorAll('div').forEach(function(el) {
                        const style = window.getComputedStyle(el);
                        if (style.position === 'fixed' && 
                            (style.backgroundColor.includes('rgba') || style.opacity < 1) &&
                            (el.offsetWidth > window.innerWidth * 0.8 || el.offsetHeight > window.innerHeight * 0.8)) {
                            console.log('[DownTV] Removing overlay');
                            el.remove();
                        }
                    });
                }

                // BUSCAR Y NAVEGAR A MEGA AUTOMÁTICAMENTE
                function findAndNavigateToMega() {
                    // Buscar en el HTML completo
                    const html = document.documentElement.innerHTML;
                    const patterns = [
                        /https?:\/\/(?:www\.)?mega(?:\.co)?\.nz\/(?:file|folder)\/[A-Za-z0-9_-]+(?:#[A-Za-z0-9_-]+(?:\/(?:file|folder)\/[A-Za-z0-9_-]+)*)?/gi,
                        /https?:\/\/(?:www\.)?mega(?:\.co)?\.nz\/[#!][A-Za-z0-9_!-]+/gi,
                        /mega:\/\/[A-Za-z0-9_#!\/-]+/gi
                    ];
                    
                    for (let pattern of patterns) {
                        const matches = html.match(pattern);
                        if (matches && matches.length > 0) {
                            const megaUrl = matches[0]
                                .replace(/\\\//g, '/')
                                .replace(/\\\\/g, '')
                                .replace(/["']/g, '')
                                .trim();
                            
                            if (megaUrl.includes('/file/') || megaUrl.includes('/folder/') || 
                                megaUrl.includes('/#') || megaUrl.includes('/!')) {
                                console.log('[DownTV] Found Mega URL, navigating:', megaUrl);
                                window.location.href = megaUrl;
                                return true;
                            }
                        }
                    }
                    
                    // Buscar en inputs hidden
                    const inputs = document.querySelectorAll('input[type="hidden"]');
                    for (let input of inputs) {
                        const value = input.value || '';
                        if (value.includes('mega.nz') || value.includes('mega.co.nz')) {
                            console.log('[DownTV] Found Mega in hidden input:', value);
                            window.location.href = value;
                            return true;
                        }
                    }
                    
                    // Buscar en data attributes
                    const elements = document.querySelectorAll('[data-url], [data-href], [data-target], [data-link]');
                    for (let el of elements) {
                        const url = el.getAttribute('data-url') || el.getAttribute('data-href') || 
                                   el.getAttribute('data-target') || el.getAttribute('data-link') || '';
                        if (url.includes('mega.nz') || url.includes('mega.co.nz')) {
                            console.log('[DownTV] Found Mega in data attribute:', url);
                            window.location.href = url;
                            return true;
                        }
                    }
                    
                    return false;
                }

                // AUTO-CLICK EN BOTONES (OUO.IO Y SHON.XYZ)
                function autoClickButtons() {
                    // Eliminar warnings primero
                    removeExtensionWarning();
                    
                    // Buscar Mega primero
                    if (findAndNavigateToMega()) {
                        return true;
                    }
                    
                    // Buscar botones de continuar
                    const buttonSelectors = [
                        'button', 'input[type="submit"]', 'input[type="button"]',
                        'a.btn', 'a[role="button"]', '.button', '[class*="btn"]',
                        '#btn-main', '#invisibleCaptchaShortlink', '.get-link'
                    ];
                    
                    for (let selector of buttonSelectors) {
                        const buttons = document.querySelectorAll(selector);
                        for (let btn of buttons) {
                            const text = (btn.textContent || btn.value || btn.id || btn.className || '').toLowerCase();
                            const visible = btn.offsetParent !== null && 
                                          window.getComputedStyle(btn).display !== 'none' &&
                                          window.getComputedStyle(btn).visibility !== 'hidden';
                            
                            if (visible && (
                                text.includes('continue') || text.includes('continuar') ||
                                text.includes('get link') || text.includes('obtener') ||
                                text.includes('verify') || text.includes('verificar') ||
                                text.includes('im not') || text.includes('no soy') ||
                                text.includes('next') || text.includes('siguiente') ||
                                text.includes('submit') || text.includes('enviar') ||
                                text.includes('go') && text.length < 20
                            )) {
                                // En shon.xyz muchos botones aparentemente válidos abren primero
                                // publicidad/tiendas tipo AliExpress. Para evitarlo, solo hacemos
                                // click automático si el botón pertenece al propio dominio o apunta
                                // directamente a Mega. Si no, el usuario puede pulsar manualmente
                                // dentro del cuadrado amarillo.
                                const href = btn.href || btn.getAttribute('data-href') || btn.getAttribute('data-url') || '';
                                let safeAutoClick = true;
                                if (isShon && href) {
                                    try {
                                        const h = new URL(href, window.location.href).hostname.replace(/^www\./, '');
                                        safeAutoClick = h.includes('shon.xyz') || h.includes('mega.nz') || h.includes('mega.co.nz');
                                    } catch(e) {
                                        safeAutoClick = false;
                                    }
                                }
                                if (isShon && !href) {
                                    safeAutoClick = false;
                                }
                                if (!safeAutoClick) {
                                    console.log('[DownTV] Skipping unsafe shon.xyz auto-click:', text, href);
                                    continue;
                                }
                                console.log('[DownTV] Auto-clicking button:', text, btn);
                                try {
                                    btn.click();
                                    return true;
                                } catch(e) {
                                    console.log('[DownTV] Click failed:', e);
                                }
                            }
                        }
                    }
                    
                    // Para shon.xyz: buscar formularios y submitearlos
                    if (isShon) {
                        const forms = document.querySelectorAll('form');
                        for (let form of forms) {
                            const action = form.action || '';
                            if (action.includes('mega') || form.querySelector('input[value*="mega"]')) {
                                console.log('[DownTV] Submitting form with Mega link');
                                try {
                                    form.submit();
                                    return true;
                                } catch(e) {}
                            }
                        }
                    }
                    
                    return false;
                }

                // BLOQUEAR POPUPS EN CLICKS
                document.addEventListener('click', function(e) {
                    const target = e.target.closest('a, button, input[type="submit"]');
                    
                    if (target && target.tagName === 'A') {
                        const href = target.href || '';
                        
                        // Permitir Mega
                        if (href.includes('mega.nz') || href.includes('mega.co.nz')) {
                            console.log('[DownTV] Mega link clicked, allowing');
                            return;
                        }
                        
                        // Bloquear target="_blank" (popups)
                        if (target.target === '_blank') {
                            console.log('[DownTV] Blocked popup link');
                            e.preventDefault();
                            e.stopPropagation();
                            e.stopImmediatePropagation();
                            return false;
                        }
                        
                        // Bloquear dominios de publicidad
                        const adDomains = ['doubleclick', 'googlesyndication', 'adservice', 'exoclick', 
                                          'popads', 'popcash', 'propellerads', 'adsterra', 'mgid',
                                          'taboola', 'outbrain', 'revcontent', '1xbet'];
                        for (let domain of adDomains) {
                            if (href.includes(domain)) {
                                console.log('[DownTV] Blocked ad domain');
                                e.preventDefault();
                                e.stopPropagation();
                                e.stopImmediatePropagation();
                                return false;
                            }
                        }
                    }
                }, true);

                // EJECUTAR LIMPIEZA Y AUTO-CLICK
                removeExtensionWarning();
                
                // Intentar inmediatamente
                setTimeout(function() {
                    removeExtensionWarning();
                    autoClickButtons();
                }, 500);
                
                // Intentar cada 2 segundos durante 30 segundos
                let attempts = 0;
                const interval = setInterval(function() {
                    attempts++;
                    removeExtensionWarning();
                    
                    if (autoClickButtons() || attempts >= 15) {
                        clearInterval(interval);
                        console.log('[DownTV] Auto-click finished after', attempts, 'attempts');
                    }
                }, 2000);
                
                // Observer para detectar cambios en el DOM
                const observer = new MutationObserver(function(mutations) {
                    removeExtensionWarning();
                });
                
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
                
                console.log('[DownTV] Shortener cleaner script loaded');
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }
    
    private fun injectHumanBehaviorScript(view: WebView) {
        // Script para simular comportamiento humano y evitar detección
        val script = """
            (function() {
                if (window.__downTvHumanBehavior) return;
                window.__downTvHumanBehavior = true;
                
                // Simular movimientos de mouse aleatorios
                function simulateMouseMovement() {
                    const event = new MouseEvent('mousemove', {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        clientX: Math.random() * window.innerWidth,
                        clientY: Math.random() * window.innerHeight
                    });
                    document.dispatchEvent(event);
                }
                
                // Simular scroll aleatorio
                function simulateScroll() {
                    window.scrollTo({
                        top: Math.random() * (document.body.scrollHeight - window.innerHeight),
                        behavior: 'smooth'
                    });
                }
                
                // Ejecutar simulaciones aleatorias
                setInterval(simulateMouseMovement, 3000 + Math.random() * 2000);
                setInterval(simulateScroll, 5000 + Math.random() * 3000);
                
                // Ocultar que somos un WebView
                Object.defineProperty(navigator, 'webdriver', { get: () => false });
                Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
                Object.defineProperty(navigator, 'languages', { get: () => ['es-ES', 'es', 'en'] });
                
                console.log('[DownTV] Human behavior simulation active');
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }
    
    private fun openMegaLink(url: String) {
        showMegaOpenOptions(url)
    }

    private fun showMegaOpenOptions(url: String) {
        if (isFinishing || isDestroyed) return

        AlertDialog.Builder(this)
            .setTitle("Enlace de Mega encontrado")
            .setMessage("¿Dónde quieres abrir este enlace?")
            .setPositiveButton("Navegador") { _, _ ->
                openMegaInBrowser(url)
            }
            .setNegativeButton("En la app") { _, _ ->
                openMegaInApp(url)
            }
            .setNeutralButton("Cancelar", null)
            .show()
    }

    private fun openOriginalShortenerInDefaultBrowser() {
        val url = targetUrl.trim()
        if (url.isBlank()) {
            statusText?.text = "No hay URL de acortador"
            return
        }

        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
            }
            startActivity(browserIntent)
            statusText?.text = "Acortador abierto en navegador"
        } catch (e: Exception) {
            Log.e(TAG, "Error opening original shortener in browser: ${e.message}", e)
            statusText?.text = "No se pudo abrir el navegador"
        }
    }

    private fun openMegaInApp(url: String) {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("mega_url", url)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening Mega link in app: ${e.message}", e)
            statusText?.text = "Error al abrir enlace de Mega"
        }
    }

    private fun openMegaInBrowser(url: String) {
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(Intent.createChooser(browserIntent, "Abrir Mega con"))
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening Mega link in browser: ${e.message}", e)
            statusText?.text = "No se pudo abrir el navegador"
        }
    }
    
    private fun openTorrentLink(url: String) {
        try {
            // Aquí se integraría con TorrentStreamManager
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("torrent_url", url)
                putExtra("title", "Temporada $seasonNumber Episodio $episodeNumber")
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening torrent link: ${e.message}", e)
            statusText?.text = "Error al abrir torrent"
        }
    }
    
    private fun loadUrl(url: String) {
        Log.d(TAG, "Loading URL in WebView: $url")
        handler.post {
            webView?.loadUrl(url)
        }
    }
    
    private fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            ByteArrayInputStream("".toByteArray())
        )
    }
    
    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dp(24)
    }

    private fun navigationBarHeight(): Int {
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dp(48)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        webView?.destroy()
        webView = null
    }
}
