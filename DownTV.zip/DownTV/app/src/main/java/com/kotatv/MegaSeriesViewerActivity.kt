package com.kotatv

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.io.ByteArrayInputStream

class MegaSeriesViewerActivity : ComponentActivity() {

    private lateinit var rootView: FrameLayout
    private var webView: WebView? = null
    private var progressBar: ProgressBar? = null
    private var statusText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var targetUrl: String = ""
    private var seriesTitle: String = ""
    private var seasonNumber: Int = 0
    private var episodeNumber: Int = 0
    private var mode: String = MODE_SHORTENER

    companion object {
        private const val TAG = "MegaSeriesViewer"
        const val EXTRA_URL = "url"
        const val EXTRA_SERIES_TITLE = "series_title"
        const val EXTRA_SEASON = "season"
        const val EXTRA_EPISODE = "episode"
        const val EXTRA_MODE = "mode"
        const val MODE_SERIES_CATALOG = "series_catalog"
        const val MODE_SHORTENER = "shortener"

        private val BLOG_HOST_PARTS = listOf(
            "blogspot.com",
            "blogger.com"
        )

        private val SHORTENER_HOST_PARTS = listOf(
            "ouo.io", "ouo.press", "ouoio.com", "ouo.si",
            "shrinkme.io", "shorte.st", "adf.ly", "linkvertise.com",
            "exe.io", "bc.vc", "fc.lc", "cuty.io", "shrinkearn.com",
            "earnviral.com", "gplinks.co", "oke.io", "za.gl", "du-link.in",
            "link1s.com", "short.pe", "clk.sh", "tinyurl.com", "bit.ly",
            "t.co", "gg.gg", "is.gd", "rebrand.ly", "tiny.cc",
            "adshort.co", "cpmlink.net", "shon.xyz", "adbull.org"
        )

        private val AD_HOST_PARTS = listOf(
            "doubleclick", "googlesyndication", "googleadservices", "adservice",
            "adserver", "adsrvr", "taboola", "outbrain", "popads", "popcash",
            "popunder", "propellerads", "adsterra", "exoclick", "mgid",
            "onesignal", "tracker", "tracking", "analytics", "telemetry",
            "hotjar", "clarity.ms", "facebook.net", "connect.facebook.net",
            "hilltopads", "trafficjunky", "juicyads", "clickadu", "adcash",
            "monetag", "trafficstars", "oclasrv", "galaksion", "1xbet",
            "xbet.com", "adnxs", "rubiconproject", "openx.net", "criteo",
            "pubmatic", "appnexus", "springserve", "smartadserver"
        )

        private val AD_URL_PARTS = listOf(
            "/ads/", "/adserver", "/advert", "/banner", "/prebid", "/vast",
            "/vpaid", "/ima3", "/popunder", "/popup", "runpop", "zoneid=",
            "/push/", "/notification", "/tracker", "/tracking", "/analytics",
            "/metrics", "/telemetry", "/collector", "/fingerprint", "gclid=",
            "fbclid=", "msclkid=", "aff_id=", "affiliate=", "adtag=",
            "adunit=", "/pagead/", "/adx/", "prebid.js", "/preroll"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.keepScreenOn = true

        targetUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        seriesTitle = intent.getStringExtra(EXTRA_SERIES_TITLE).orEmpty()
        seasonNumber = intent.getIntExtra(EXTRA_SEASON, 0)
        episodeNumber = intent.getIntExtra(EXTRA_EPISODE, 0)
        mode = intent.getStringExtra(EXTRA_MODE)
            ?: if (isBlogUrl(targetUrl)) MODE_SERIES_CATALOG else MODE_SHORTENER

        if (targetUrl.isBlank()) {
            finish()
            return
        }

        setupUi()
        loadUrl(targetUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView?.canGoBack() == true) {
                    webView?.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupUi() {
        rootView = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(rootView)

        val sbHeight = statusBarHeight()
        val navBarHeight = navigationBarHeight()

        val titleText = TextView(this).apply {
            text = seriesTitle.ifBlank {
                if (mode == MODE_SERIES_CATALOG) "Series" else "Temporada $seasonNumber Episodio $episodeNumber"
            }
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(0xFF111111.toInt())
            maxLines = 2
        }

        val webFrame = FrameLayout(this).apply {
            setBackgroundColor(0xFFFFD100.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_NO_CACHE
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
                allowFileAccess = false
                allowContentAccess = false
                loadWithOverviewMode = true
                useWideViewPort = true
                // Habilitar zoom siempre
                builtInZoomControls = true
                displayZoomControls = false
                setSupportZoom(true)
            }
            addJavascriptInterface(MegaCatalogBridge(), "MegaCatalog")
            webViewClient = createWebViewClient()
            webChromeClient = createWebChromeClient()
        }

        webFrame.addView(webView, FrameLayout.LayoutParams(-1, -1))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
        }

        statusText = TextView(this).apply {
            text = if (mode == MODE_SERIES_CATALOG) "Cargando capítulos..." else "Cargando acortador..."
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(0xFF111111.toInt())
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val squareSize = minOf(screenWidth - dp(24), screenHeight - dp(132) - sbHeight - navBarHeight).coerceAtLeast(dp(260))

        rootView.addView(titleText, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply {
            topMargin = sbHeight
        })
        rootView.addView(webFrame, FrameLayout.LayoutParams(squareSize, squareSize, Gravity.CENTER))
        rootView.addView(progressBar, FrameLayout.LayoutParams(-1, dp(4), Gravity.BOTTOM).apply {
            bottomMargin = dp(36) + navBarHeight
        })
        rootView.addView(statusText, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            bottomMargin = navBarHeight
        })

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            webView?.let { setAcceptThirdPartyCookies(it, false) }
        }
    }

    private fun createWebViewClient(): WebViewClient {
        return object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                val host = request.url.host.orEmpty().lowercase()
                if (isBlockedRequest(host, url)) {
                    Log.d(TAG, "Blocked request: $url")
                    return emptyResponse()
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                val host = request.url.host.orEmpty().lowercase()
                val scheme = request.url.scheme.orEmpty().lowercase()

                if (scheme !in setOf("http", "https", "about", "data")) return true
                if (isMegaUrl(url)) {
                    openMegaLink(url)
                    return true
                }
                if (isShortenerUrl(url) && mode == MODE_SERIES_CATALOG) {
                    openShortener(url, 0, 0)
                    return true
                }
                if (isBlockedRequest(host, url)) return true
                if (request.isForMainFrame && mode == MODE_SERIES_CATALOG && !isAllowedSeriesHost(host)) {
                    Log.d(TAG, "Blocked catalog navigation: $url")
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                progressBar?.visibility = View.VISIBLE
                statusText?.text = if (mode == MODE_SERIES_CATALOG) "Abriendo catálogo web..." else "Cargando..."
                if (mode == MODE_SERIES_CATALOG) scheduleMegaCatalogCleaner(view)
            }

            override fun onPageCommitVisible(view: WebView, url: String) {
                if (mode == MODE_SERIES_CATALOG) scheduleMegaCatalogCleaner(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                progressBar?.visibility = View.GONE
                if (mode == MODE_SERIES_CATALOG) {
                    statusText?.text = "Toca una temporada o capítulo"
                    scheduleMegaCatalogCleaner(view)
                } else {
                    statusText?.text = "Temporada $seasonNumber Episodio $episodeNumber"
                    injectShortenerCleanerJs(view)
                }
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.proceed()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) statusText?.text = "No se pudo cargar la página"
            }
        }
    }

    private fun scheduleMegaCatalogCleaner(view: WebView) {
        listOf(900L, 2_500L, 5_000L, 9_000L).forEach { delayMs ->
            handler.postDelayed({
                if (webView === view && mode == MODE_SERIES_CATALOG) {
                    statusText?.text = "Toca una temporada o capítulo"
                    injectMegaCatalogCleanerJs(view)
                }
            }, delayMs)
        }
    }

    private fun createWebChromeClient(): WebChromeClient {
        return object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar?.progress = newProgress
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                result.cancel()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                result.cancel()
                return true
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean = false
        }
    }

    private inner class MegaCatalogBridge {
        @JavascriptInterface
        fun openEpisode(url: String, label: String, season: Int, episode: Int) {
            if (url.isBlank()) return
            handler.post {
                val safeSeason = season.takeIf { it > 0 } ?: seasonNumber
                val safeEpisode = episode.takeIf { it > 0 } ?: episodeNumber
                Log.d(TAG, "Episode link: S${safeSeason}E$safeEpisode $label -> $url")
                when {
                    isMegaUrl(url) -> openMegaLink(url)
                    isShortenerUrl(url) -> openShortener(url, safeSeason, safeEpisode)
                    else -> webView?.loadUrl(url)
                }
            }
        }
    }

    private fun injectMegaCatalogCleanerJs(view: WebView) {
        val script = """
            (function() {
                if (window.__downTvMegaCatalogRendered) return;
                window.__downTvMegaCatalogCleanerRuns = (window.__downTvMegaCatalogCleanerRuns || 0) + 1;
                window.open = function() { return null; };
                window.alert = function() {};
                window.confirm = function() { return false; };
                window.prompt = function() { return null; };
                var cleanAttempts = 0;

                function isAdUrl(url) {
                    url = (url || '').toLowerCase();
                    return /doubleclick|googlesyndication|adservice|adsterra|exoclick|popads|popcash|propellerads|mgid|taboola|outbrain|1xbet|tracking|analytics|banner|popup|popunder/.test(url);
                }

                function isShortener(url) {
                    var host = '';
                    try { host = new URL(url || '', location.href).hostname.toLowerCase().replace(/^www\./, ''); } catch(e) { return false; }
                    var domains = ['ouo.io','ouo.press','ouoio.com','ouo.si','shrinkme.io','shorte.st','adf.ly','linkvertise.com','exe.io','bc.vc','fc.lc','cuty.io','shrinkearn.com','earnviral.com','gplinks.co','oke.io','za.gl','du-link.in','link1s.com','short.pe','clk.sh','tinyurl.com','bit.ly','t.co','gg.gg','is.gd','rebrand.ly','tiny.cc','adshort.co','cpmlink.net','shon.xyz','adbull.org'];
                    return domains.some(function(domain) { return host === domain || host.endsWith('.' + domain); });
                }

                function isMega(url) {
                    url = (url || '').toLowerCase();
                    return url.indexOf('mega.nz') >= 0 || url.indexOf('mega.co.nz') >= 0;
                }

                function isBlogEpisodeUrl(url) {
                    url = (url || '').toLowerCase();
                    return /blogspot|blogger/.test(url) && /temporada|season|episodio|episode|capitulo|capítulo|cap-|ep-|s\s*\d{1,2}\s*e\s*\d{1,3}|\d{1,2}\s*x\s*\d{1,3}/.test(url);
                }

                function cleanText(text) {
                    return (text || '').replace(/\s+/g, ' ').trim();
                }

                function removeNoise(root) {
                    var selectors = [
                        'script', 'noscript', 'style:not([data-downtv])', 'iframe',
                        'header', 'footer', 'nav', 'aside', '.sidebar', '#sidebar',
                        '.comments', '#comments', '.comment', '.share', '.sharing',
                        '.post-footer', '.blog-pager', '.breadcrumbs', '.related-posts',
                        '[class*="ad"]', '[id*="ad"]', '[class*="popup"]', '[id*="popup"]',
                        '[class*="overlay"]', '[id*="overlay"]',
                        '#cookieChoiceInfo', '.cookie-choices-info', '[id*="cookie"]', '[class*="cookie"]'
                    ];
                    selectors.forEach(function(sel) {
                        try {
                            root.querySelectorAll(sel).forEach(function(el) {
                                var txt = (el.textContent || '').toLowerCase();
                                if (sel.indexOf('[class*="ad"]') >= 0 && /temporada|episodio|capitulo|capítulo|mega/.test(txt)) return;
                                el.remove();
                            });
                        } catch(e) {}
                    });
                    root.querySelectorAll('*').forEach(function(el) {
                        var txt = cleanText(el.textContent || '').toLowerCase();
                        if ((txt.indexOf('utiliza cookies') >= 0 || txt.indexOf('cookies de google') >= 0) &&
                            (txt.indexOf('entendido') >= 0 || txt.indexOf('más información') >= 0 || txt.indexOf('mas información') >= 0)) {
                            el.remove();
                        }
                    });
                }

                function removeCookieBanners() {
                    document.querySelectorAll('#cookieChoiceInfo,.cookie-choices-info,[id*="cookie"],[class*="cookie"]').forEach(function(el) {
                        el.remove();
                    });
                    document.querySelectorAll('body *').forEach(function(el) {
                        var txt = cleanText(el.textContent || '').toLowerCase();
                        if ((txt.indexOf('utiliza cookies') >= 0 || txt.indexOf('cookies de google') >= 0) &&
                            (txt.indexOf('entendido') >= 0 || txt.indexOf('más información') >= 0 || txt.indexOf('mas información') >= 0)) {
                            el.remove();
                        }
                    });
                }

                function normalizeForEpisode(text) {
                    text = cleanText(text || '');
                    try { text = text.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch(e) {}
                    return text.toLowerCase();
                }

                function parseEpisodeText(text) {
                    var normalized = normalizeForEpisode(text);
                    var match =
                        normalized.match(/\bs\s*0?(\d{1,2})\s*e\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\bt\s*0?(\d{1,2})\s*e\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\b0?(\d{1,2})\s*x\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\btemporada\s*0?(\d{1,2}).{0,90}?\b(?:episodio|episode|capitulo|chapter|cap|ep)\.?\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\bseason\s*0?(\d{1,2}).{0,90}?\b(?:episodio|episode|capitulo|chapter|cap|ep)\.?\s*0?(\d{1,3})\b/);
                    if (match) {
                        return {
                            season: parseInt(match[1], 10) || 0,
                            episode: parseInt(match[2], 10) || 0
                        };
                    }
                    var seasonMatch =
                        normalized.match(/\b(?:temporada|season|temp|t)\.?\s*0?(\d{1,2})\b/) ||
                        normalized.match(/\bs\s*0?(\d{1,2})\b/);
                    var episodeMatch =
                        normalized.match(/\b(?:episodio|episode|capitulo|chapter|cap|ep)\.?\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\be\s*0?(\d{1,3})\b/) ||
                        normalized.match(/\b(\d{1,2})\s*x\s*(\d{1,3})\b/);
                    var episodeNum = 0;
                    if (episodeMatch) {
                        episodeNum = parseInt(episodeMatch[episodeMatch.length === 3 ? 2 : 1], 10) || 0;
                    }
                    return {
                        season: seasonMatch ? (parseInt(seasonMatch[1], 10) || 0) : 0,
                        episode: episodeNum
                    };
                }

                function addLocalText(parts, text) {
                    text = cleanText(text || '');
                    if (!text) return;
                    var normalized = normalizeForEpisode(text);
                    var markers = normalized.match(/\b(?:episodio|episode|capitulo|chapter|cap|ep)\.?\s*\d{1,3}\b|\bs\s*\d{1,2}\s*e\s*\d{1,3}\b|\bt\s*\d{1,2}\s*e\s*\d{1,3}\b|\b\d{1,2}\s*x\s*\d{1,3}\b/g) || [];
                    if (text.length <= 360 || markers.length <= 2) parts.push(text.substring(0, 520));
                }

                function nearbyTextNodeText(anchor) {
                    var parts = [];
                    var prev = anchor.previousSibling;
                    for (var i = 0; prev && i < 6; i++, prev = prev.previousSibling) {
                        if (prev.nodeType === Node.TEXT_NODE) parts.unshift(prev.textContent || '');
                        else if (prev.nodeType === Node.ELEMENT_NODE) parts.unshift(prev.innerText || prev.textContent || '');
                    }
                    parts.push(anchor.innerText || anchor.textContent || '');
                    var next = anchor.nextSibling;
                    for (var j = 0; next && j < 2; j++, next = next.nextSibling) {
                        if (next.nodeType === Node.TEXT_NODE) parts.push(next.textContent || '');
                        else if (next.nodeType === Node.ELEMENT_NODE) parts.push(next.innerText || next.textContent || '');
                    }
                    return cleanText(parts.join(' '));
                }

                function localTextFor(anchor) {
                    var parts = [];
                    addLocalText(parts, anchor.getAttribute('aria-label'));
                    addLocalText(parts, anchor.getAttribute('title'));
                    addLocalText(parts, anchor.innerText || anchor.textContent || '');
                    addLocalText(parts, nearbyTextNodeText(anchor));
                    var holder = anchor.closest ? anchor.closest('li,tr,td,p,span,section,article,div') : null;
                    if (holder && holder !== document.body && holder !== document.documentElement) {
                        addLocalText(parts, holder.innerText || holder.textContent || '');
                    }
                    var prev = anchor.previousElementSibling;
                    for (var i = 0; prev && i < 2; i++, prev = prev.previousElementSibling) {
                        addLocalText(parts, prev.innerText || prev.textContent || '');
                    }
                    var parent = anchor.parentElement;
                    if (parent && parent !== holder && parent !== document.body) {
                        addLocalText(parts, parent.innerText || parent.textContent || '');
                    }
                    return parts.join(' ');
                }

                function languageTextFor(anchor) {
                    return [
                        anchor.getAttribute('aria-label') || '',
                        anchor.getAttribute('title') || '',
                        anchor.innerText || anchor.textContent || '',
                        nearbyTextNodeText(anchor),
                        localTextFor(anchor)
                    ].join(' ');
                }

                function isLatinoText(text) {
                    var normalized = normalizeForEpisode(text || '');
                    return /\b(latino|latina|latam|latin america|audio latino|es\s*419|es\s*mx|es\s*ar|es\s*cl|es\s*co|es\s*pe|es\s*ve)\b/.test(normalized);
                }

                function strictContextFor(anchor) {
                    var linkText = cleanText(anchor.innerText || anchor.textContent || '');
                    var nearbyText = nearbyTextNodeText(anchor);
                    var localText = localTextFor(anchor);
                    var parsed = parseEpisodeText(linkText);
                    if (!parsed.episode) {
                        parsed = parseEpisodeText(nearbyText);
                    }
                    if (!parsed.episode) {
                        parsed = parseEpisodeText(localText);
                    }
                    if (!parsed.season && parsed.episode) {
                        var localSeason = parseEpisodeText(nearbyText).season || parseEpisodeText(localText).season;
                        if (localSeason) parsed.season = localSeason;
                    }
                    if (!parsed.episode && /^\s*\d{1,3}\s*$/.test(linkText)) {
                        parsed.episode = parseInt(linkText, 10) || 0;
                    }
                    return { season: parsed.season || 0, episode: parsed.episode || 0, label: linkText.substring(0, 120) };
                }

                function contextFor(anchor) {
                    return strictContextFor(anchor);
                    var text = '';
                    var node = anchor;
                    for (var i = 0; node && i < 5; i++, node = node.parentElement) {
                        text += ' ' + (node.innerText || node.textContent || '');
                    }
                    var prev = anchor.previousElementSibling;
                    for (var j = 0; prev && j < 4; j++, prev = prev.previousElementSibling) {
                        text += ' ' + (prev.innerText || prev.textContent || '');
                    }
                    var linkText = anchor.innerText || anchor.textContent || '';
                    text = (linkText + ' ' + text).replace(/\s+/g, ' ');
                    var se = text.match(/s\s*(\d{1,2})\s*e\s*(\d{1,3})/i);
                    var sx = text.match(/(\d{1,2})\s*x\s*(\d{1,3})/i);
                    var season = 0;
                    var episode = 0;
                    if (se) {
                        season = parseInt(se[1], 10) || 0;
                        episode = parseInt(se[2], 10) || 0;
                    } else if (sx) {
                        season = parseInt(sx[1], 10) || 0;
                        episode = parseInt(sx[2], 10) || 0;
                    } else {
                        var sm = text.match(/(?:temporada|season|temp\.?)\s*(\d{1,2})/i) || text.match(/\bT\s*(\d{1,2})\b/i);
                        var em = text.match(/(?:episodio|episode|capitulo|capítulo|cap\.?|ep\.?)\s*(\d{1,3})/i) || text.match(/\bE\s*(\d{1,3})\b/i) || linkText.match(/\b(\d{1,3})\b/);
                        season = sm ? (parseInt(sm[1], 10) || 0) : 0;
                        episode = em ? (parseInt(em[1], 10) || 0) : 0;
                    }
                    return { season: season, episode: episode, label: linkText.substring(0, 120) };
                }

                function usefulLink(a) {
                    var href = a.href || '';
                    if (!href || isAdUrl(href)) return false;
                    // Series Mega a veces publica en la misma página el bloque Castellano y
                    // el bloque Latino. El usuario solo quiere Castellano: descartamos
                    // el enlace si el idioma latino aparece en el contexto local del enlace.
                    if (isLatinoText(languageTextFor(a))) return false;
                    var txt = cleanText((a.innerText || a.textContent || '') + ' ' + contextFor(a).label).toLowerCase();
                    return isShortener(href) ||
                        isMega(href) ||
                        isBlogEpisodeUrl(href) ||
                        /temporada|season|episodio|episode|capitulo|capítulo|cap\.|ep\.|mega|descargar|download|s\s*\d{1,2}\s*e\s*\d{1,3}|\d{1,2}\s*x\s*\d{1,3}/.test(txt);
                }

                function labelFor(a, ctx) {
                    var raw = cleanText(a.innerText || a.textContent || '');
                    var lower = raw.toLowerCase();
                    if (!raw || raw.length > 80 || /^(mega|descargar|download|link|enlace|ver|click aqui|clic aqui|aqui)$/i.test(raw)) {
                        raw = ctx.episode > 0 ? 'Capítulo ' + ctx.episode : 'Abrir enlace';
                    }
                    var prefix = '';
                    if (ctx.season > 0) prefix += 'T' + ctx.season + ' ';
                    if (ctx.episode > 0) prefix += 'E' + ctx.episode + ' ';
                    if (prefix && lower.indexOf(prefix.toLowerCase().trim()) < 0) raw = prefix + raw;
                    return raw;
                }

                function labelScore(label) {
                    var normalized = normalizeForEpisode(label);
                    var score = cleanText(label).length;
                    if (/^(t\d+\s*)?e\d+\s*(capitulo|episodio)?\s*\d*$/i.test(normalized)) score -= 80;
                    if (normalized.indexOf('abrir enlace') >= 0) score -= 80;
                    if (normalized.indexOf('descargar') >= 0 || normalized.indexOf('mega') >= 0) score -= 20;
                    return score;
                }

                function consolidateEpisodes(items) {
                    var byEpisode = {};
                    items.forEach(function(item) {
                        var key = item.season + '|' + item.episode;
                        var existing = byEpisode[key];
                        if (!existing) {
                            byEpisode[key] = item;
                            return;
                        }
                        if (labelScore(item.label) > labelScore(existing.label)) {
                            existing.label = item.label;
                        }
                        if ((!existing.direct && item.direct) || (existing.direct === item.direct && item.order < existing.order)) {
                            existing.href = item.href;
                            existing.direct = item.direct;
                            existing.order = Math.min(existing.order, item.order);
                        }
                    });
                    return Object.keys(byEpisode).map(function(key) { return byEpisode[key]; });
                }

                function collectEpisodeLinks() {
                    var items = [];
                    var seen = {};
                    var lastSeason = 0;
                    var nextEpisodeBySeason = {};
                    var maxEpisodeBySeason = {};
                    document.querySelectorAll('a[href]').forEach(function(a, index) {
                        a.removeAttribute('target');
                        var href = a.href || '';
                        if (!usefulLink(a)) return;
                        var ctx = contextFor(a);
                        if (ctx.season > 0) {
                            lastSeason = ctx.season;
                        } else {
                            ctx.season = lastSeason || 1;
                            // No subimos de temporada solo porque el contador vuelva a 1.
                            // En Series Mega eso suele indicar un bloque latino repetido,
                            // no una temporada nueva real.
                        }
                        if (!nextEpisodeBySeason[ctx.season]) nextEpisodeBySeason[ctx.season] = 1;
                        if (ctx.episode <= 0) ctx.episode = nextEpisodeBySeason[ctx.season];
                        nextEpisodeBySeason[ctx.season] = Math.max(nextEpisodeBySeason[ctx.season], ctx.episode + 1);
                        maxEpisodeBySeason[ctx.season] = Math.max(maxEpisodeBySeason[ctx.season] || 0, ctx.episode || 0);
                        var label = labelFor(a, ctx);
                        var key = href + '|' + ctx.season + '|' + ctx.episode;
                        if (seen[key]) return;
                        seen[key] = true;
                        items.push({
                            href: href,
                            label: label,
                            season: ctx.season || 0,
                            episode: ctx.episode || 0,
                            direct: isShortener(href) || isMega(href),
                            order: index
                        });
                    });
                    items = consolidateEpisodes(items);
                    items.sort(function(a, b) {
                        if (a.season !== b.season) return (a.season || 999) - (b.season || 999);
                        if (a.episode !== b.episode) return (a.episode || 9999) - (b.episode || 9999);
                        return a.order - b.order;
                    });
                    return items;
                }

                function addStyle() {
                    if (document.querySelector('style[data-downtv]')) return;
                    var style = document.createElement('style');
                    style.setAttribute('data-downtv', '1');
                    style.textContent =
                        'html,body{margin:0!important;padding:0!important;background:#fff!important;color:#111!important;font:16px/1.35 sans-serif!important;overflow:auto!important;}' +
                        'body{box-sizing:border-box;padding:12px!important;}' +
                        '#downtv-episodes-root{max-width:100%!important;margin:0!important;padding:0!important;}' +
                        '.downtv-summary{margin:0 0 12px!important;padding:10px 12px!important;border:1px solid #ffd100!important;background:#fff8c6!important;border-radius:6px!important;font-weight:800!important;color:#111!important;}' +
                        '.downtv-season{margin:14px 0 8px!important;padding:6px 0!important;border-bottom:2px solid #ffd100!important;color:#111!important;font-size:18px!important;font-weight:900!important;}' +
                        '.downtv-episode{display:block!important;box-sizing:border-box!important;width:100%!important;margin:7px 0!important;padding:11px 12px!important;border:1px solid #d0b000!important;border-radius:6px!important;background:#fff!important;color:#111!important;text-decoration:none!important;font-weight:800!important;}' +
                        '.downtv-empty{padding:14px!important;border:1px solid #d0b000!important;background:#fff8c6!important;border-radius:6px!important;color:#111!important;}' +
                        '#cookieChoiceInfo,.cookie-choices-info,[id*="cookie"],[class*="cookie"]{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;}' +
                        '*{max-width:100%!important;}';
                    document.head.appendChild(style);
                }

                function renderEpisodeOnly(items) {
                    if (window.__downTvMegaCatalogRendered) return;
                    window.__downTvMegaCatalogRendered = true;
                    addStyle();
                    document.body.innerHTML = '';
                    removeCookieBanners();
                    var root = document.createElement('main');
                    root.id = 'downtv-episodes-root';

                    var summary = document.createElement('div');
                    summary.className = 'downtv-summary';
                    summary.textContent = items.length > 0 ? (items.length + ' enlaces de capítulos detectados') : 'Capítulos';
                    root.appendChild(summary);

                    if (!items.length) {
                        var empty = document.createElement('div');
                        empty.className = 'downtv-empty';
                        empty.textContent = 'No se detectaron capítulos en esta página.';
                        root.appendChild(empty);
                    }

                    var currentSeason = null;
                    items.forEach(function(item) {
                        var seasonKey = item.season > 0 ? String(item.season) : 'links';
                        if (seasonKey !== currentSeason) {
                            currentSeason = seasonKey;
                            var h = document.createElement('div');
                            h.className = 'downtv-season';
                            h.textContent = item.season > 0 ? ('Temporada ' + item.season) : 'Enlaces';
                            root.appendChild(h);
                        }
                        var btn = document.createElement('a');
                        btn.className = 'downtv-episode';
                        btn.href = item.href;
                        btn.textContent = item.label;
                        btn.setAttribute('data-href', item.href);
                        btn.setAttribute('data-label', item.label);
                        btn.setAttribute('data-season', String(item.season || 0));
                        btn.setAttribute('data-episode', String(item.episode || 0));
                        btn.setAttribute('data-direct', item.direct ? '1' : '0');
                        root.appendChild(btn);
                    });
                    document.body.appendChild(root);
                    removeCookieBanners();
                    setInterval(removeCookieBanners, 500);
                    root.addEventListener('click', function(e) {
                        var a = e.target && e.target.closest ? e.target.closest('a[data-href]') : null;
                        if (!a) return;
                        var href = a.getAttribute('data-href') || '';
                        e.preventDefault();
                        e.stopPropagation();
                        if (a.getAttribute('data-direct') === '1') {
                            if (window.MegaCatalog && window.MegaCatalog.openEpisode) {
                                window.MegaCatalog.openEpisode(
                                    href,
                                    a.getAttribute('data-label') || '',
                                    parseInt(a.getAttribute('data-season') || '0', 10) || 0,
                                    parseInt(a.getAttribute('data-episode') || '0', 10) || 0
                                );
                            }
                        } else {
                            window.location.href = href;
                        }
                        return false;
                    }, true);
                }

                function cleanToEpisodes() {
                    if (!document.body) {
                        setTimeout(cleanToEpisodes, 500);
                        return;
                    }
                    cleanAttempts += 1;
                    removeNoise(document.body);
                    var items = collectEpisodeLinks();
                    if (items.length > 0 || cleanAttempts >= 10) {
                        renderEpisodeOnly(items);
                    } else {
                        setTimeout(cleanToEpisodes, 700);
                    }
                }

                cleanToEpisodes();
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun injectShortenerCleanerJs(view: WebView) {
        val script = """
            (function() {
                window.open = function() { return null; };
                window.alert = function() {};
                window.confirm = function() { return false; };
                window.prompt = function() { return null; };
                document.querySelectorAll('[target="_blank"]').forEach(function(el) { el.removeAttribute('target'); });
                document.querySelectorAll('iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="ad"],[class*="popup"],[id*="popup"],[class*="overlay"],[id*="overlay"]').forEach(function(el) { el.remove(); });
                document.querySelectorAll('a[href]').forEach(function(a) {
                    var href = a.href || '';
                    if (href.toLowerCase().indexOf('mega.nz') >= 0 && window.MegaCatalog) {
                        a.addEventListener('click', function(e) {
                            e.preventDefault();
                            window.MegaCatalog.openEpisode(href, a.innerText || '', 0, 0);
                        }, true);
                    }
                });
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun isAllowedSeriesHost(host: String): Boolean {
        if (host.isBlank()) return true
        return BLOG_HOST_PARTS.any { host.contains(it) } ||
            host == Uri.parse(targetUrl).host?.lowercase()
    }

    private fun isBlockedRequest(host: String, url: String): Boolean {
        val lower = url.lowercase()
        if (AD_HOST_PARTS.any { host.contains(it) }) return true
        if (AD_URL_PARTS.any { lower.contains(it) }) return true
        return false
    }

    private fun isBlogUrl(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host.orEmpty().lowercase() }.getOrDefault("")
        return BLOG_HOST_PARTS.any { host.contains(it) }
    }

    private fun isShortenerUrl(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host.orEmpty().lowercase() }.getOrDefault("")
        val cleanHost = host.removePrefix("www.")
        return SHORTENER_HOST_PARTS.any { cleanHost == it || cleanHost.endsWith(".$it") }
    }

    private fun isMegaUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("mega.nz") || lower.contains("mega.co.nz")
    }

    private fun openShortener(url: String, season: Int, episode: Int) {
        if (url.contains("shon.xyz", ignoreCase = true)) {
            // shon.xyz funciona mejor pasando por MainActivity: prueba bypass HTTP y,
            // si hace falta, abre un WebView visible sin el bloqueo agresivo del visor.
            startActivity(Intent(this, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                data = Uri.parse(url)
                putExtra("from_series", true)
            })
            return
        }

        startActivity(Intent(this, ShortenerViewerActivity::class.java).apply {
            putExtra(ShortenerViewerActivity.EXTRA_URL, url)
            putExtra(ShortenerViewerActivity.EXTRA_SEASON, season)
            putExtra(ShortenerViewerActivity.EXTRA_EPISODE, episode)
        })
    }

    private fun openMegaLink(url: String) {
        showMegaOpenOptions(url)
    }

    private fun showMegaOpenOptions(url: String) {
        if (isFinishing || isDestroyed) return

        AlertDialog.Builder(this)
            .setTitle("Enlace de Mega encontrado")
            .setMessage("¿Dónde quieres abrir este enlace?")
            .setPositiveButton("Navegador") { _, _ ->
                openMegaInBrowser(url)
            }
            .setNegativeButton("En la app") { _, _ ->
                openMegaInApp(url)
            }
            .setNeutralButton("Cancelar", null)
            .show()
    }

    private fun openMegaInApp(url: String) {
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                putExtra("mega_url", url)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening Mega link in app: ${e.message}", e)
            statusText?.text = "Error al abrir enlace de Mega"
        }
    }

    private fun openMegaInBrowser(url: String) {
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(Intent.createChooser(browserIntent, "Abrir Mega con"))
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening Mega link in browser: ${e.message}", e)
            statusText?.text = "No se pudo abrir el navegador"
        }
    }

    private fun loadUrl(url: String) {
        webView?.loadUrl(url)
    }

    private fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dp(24)
    }

    private fun navigationBarHeight(): Int {
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dp(48)
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
