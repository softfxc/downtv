plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kotatv"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.kotatv"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "2.0-release"
        
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.core:core-ktx:1.15.0")
    
    // OkHttp para requests HTTP
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    
    // Gson para parsear JSON de addons
    implementation("com.google.code.gson:gson:2.10.1")

    // Custom Tabs para abrir sitios con Cloudflare en Chrome del sistema
    implementation("androidx.browser:browser:1.8.0")
    
    // Cronet para sitios que rechazan la huella TLS de HttpURLConnection/OkHttp.
    implementation("org.chromium.net:cronet-embedded:143.7445.0")

    // libtorrent4j para reproducir torrents (versión 2.1.0-39 de Maven Central)
    implementation("org.libtorrent4j:libtorrent4j:2.1.0-39")
    implementation("org.libtorrent4j:libtorrent4j-android-arm:2.1.0-39")
    implementation("org.libtorrent4j:libtorrent4j-android-arm64:2.1.0-39")
    implementation("org.libtorrent4j:libtorrent4j-android-x86:2.1.0-39")
    implementation("org.libtorrent4j:libtorrent4j-android-x86_64:2.1.0-39")

    // libVLC embebido para reproducir formatos que Android WebView no decodifica
    implementation("org.videolan.android:libvlc-all:3.7.0")
}
